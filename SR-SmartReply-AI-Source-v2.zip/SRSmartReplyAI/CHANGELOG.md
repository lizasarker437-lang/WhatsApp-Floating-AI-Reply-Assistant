# Changelog

## [2.0.0] - 2026-11-17
### Added & Updated
- **In-App 3-Section Reply Tone Selector (`MainActivity`):** Moved the 3 reply tone sections (**Friendly • বন্ধুত্বপূর্ণ**, **Polite • ভদ্র ও আন্তরিক**, and **Professional • পেশাদার**) directly inside the main app dashboard with instant selection cards and active status badges.
- **Full Automatic Message Detection & Instant Auto-Reply (`WhatsAppAccessibilityService`):** Automatically detects new incoming WhatsApp messages on screen, reads the message context, generates a reply matching the pre-selected section inside the app, inserts it into WhatsApp, and automatically presses Send without showing a blocking popup panel.
- **Anti-Loop & Duplicate Reply Protection:** Verifies that the bottom-most message is an incoming message (`sender == "Incoming"`), tracks `contactTitle::messageText` signatures, and respects user manual typing.
- **Smart Conversational Intent Engine (`ReplyJsonParser`):** Added contextual Bangla, Banglish, and English intent replies for common messages (`Khaico ki`, `Ki koro`, `Kemon acho`, `Kothay`, `Salam`, `Hy/Hi`, etc.).
- Incremented `versionCode` to `2` and `versionName` to `2.0.0`.

## [1.0.0] - 2026-11-17
- Initial release of **SR SmartReply AI**.
