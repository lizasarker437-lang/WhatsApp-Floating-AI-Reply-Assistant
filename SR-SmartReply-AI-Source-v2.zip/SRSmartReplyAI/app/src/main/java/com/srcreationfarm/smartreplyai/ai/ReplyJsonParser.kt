package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import org.json.JSONObject

object ReplyJsonParser {

    fun parseGeminiResponse(rawText: String): ReplyOptions {
        val cleaned = rawText
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()

        val startIndex = cleaned.indexOf('{')
        val endIndex = cleaned.lastIndexOf('}')
        if (startIndex == -1 || endIndex == -1 || endIndex <= startIndex) {
            throw IllegalArgumentException("Invalid JSON boundaries in AI response")
        }

        val jsonStr = cleaned.substring(startIndex, endIndex + 1)
        val obj = JSONObject(jsonStr)

        val friendly = obj.optString("friendly", "").trim()
        val polite = obj.optString("polite", "").trim()
        val professional = obj.optString("professional", "").trim()

        if (friendly.isEmpty() && polite.isEmpty() && professional.isEmpty()) {
            throw IllegalArgumentException("Empty reply fields in JSON")
        }

        return ReplyOptions(
            friendly = friendly.ifEmpty { polite },
            polite = polite.ifEmpty { friendly },
            professional = professional.ifEmpty { polite }
        )
    }

    fun buildSmartFallbackReplies(messages: List<ChatMessage>): ReplyOptions {
        val lastIncoming = messages.lastOrNull { it.sender == "Incoming" }?.text
            ?: messages.lastOrNull()?.text
            ?: ""

        val hasBanglaScript = lastIncoming.any { it in '\u0980'..'\u09FF' }
        val lower = lastIncoming.lowercase().trim()

        // 1. Check specific common conversational intents in Bangla, Banglish & English
        if (lower.contains("salam") || lower.contains("assalamu") || lastIncoming.contains("সালাম") || lastIncoming.contains("আসসালামু")) {
            return if (hasBanglaScript) {
                ReplyOptions(
                    friendly = "ওয়ালাইকুম আসসালাম ভাই! কেমন আছেন?",
                    polite = "ওয়ালাইকুম আসসালাম ওয়া রাহমাতুল্লাহ। আপনি কেমন আছেন?",
                    professional = "ওয়ালাইকুম আসসালাম। আশা করি ভালো আছেন, কীভাবে সাহায্য করতে পারি?",
                    detectedLanguage = "Bangla",
                    isOfflineFallback = true
                )
            } else {
                ReplyOptions(
                    friendly = "Walaikum Assalam bhai! Kemon achen?",
                    polite = "Walaikum Assalam Wa Rahmatullah. Apni kemon achen?",
                    professional = "Walaikum Assalam. Asha kori bhalo achen.",
                    detectedLanguage = "Banglish",
                    isOfflineFallback = true
                )
            }
        }

        // Meal / Food inquiries ("khaico ki", "kheyeso", "khawa", "খাইছো", "খেয়েছো")
        if (lower.contains("khaic") || lower.contains("khais") || lower.contains("kheye") || lower.contains("khawa") ||
            lastIncoming.contains("খাইছ") || lastIncoming.contains("খেয়েছ") || lastIncoming.contains("খাওয়া")
        ) {
            return if (hasBanglaScript) {
                ReplyOptions(
                    friendly = "হ্যাঁ ভাই, আলহামদুলিল্লাহ খাওয়া শেষ। তুমি খাইছো?",
                    polite = "জি আলহামদুলিল্লাহ, আমার খাওয়া হয়েছে। আপনি খেয়েছেন?",
                    professional = "জি ধন্যবাদ, আমার খাওয়া সম্পন্ন হয়েছে। আশা করি আপনিও খেয়েছেন।",
                    detectedLanguage = "Bangla",
                    isOfflineFallback = true
                )
            } else {
                ReplyOptions(
                    friendly = "Haa bhai, Alhamdulillah khawa shesh! Tumi khaico?",
                    polite = "Ji Alhamdulillah, amar khawa hoyeche. Apni kheyechen?",
                    professional = "Ji dhonnobad, amar khawa shesh hoyeche. Apni kheyechen?",
                    detectedLanguage = "Banglish",
                    isOfflineFallback = true
                )
            }
        }

        // Activity inquiries ("ki koro", "ki korcho", "ki obostha", "কী করো", "কি করছো")
        if (lower.contains("ki koro") || lower.contains("ki korc") || lower.contains("ki obostha") || lower.contains("ki khobor") ||
            lastIncoming.contains("কি কর") || lastIncoming.contains("কী কর") || lastIncoming.contains("কী অবস্থা") || lastIncoming.contains("কি খবর")
        ) {
            return if (hasBanglaScript) {
                ReplyOptions(
                    friendly = "এইতো ভাই, একটু কাজ করছি। তোমার কী খবর বলো?",
                    polite = "জি, এইতো একটু কাজে ব্যস্ত আছি। আপনার কী খবর?",
                    professional = "ধন্যবাদ, বর্তমানে একটু কাজে ব্যস্ত আছি। কোনো জরুরি বিষয় থাকলে জানাতে পারেন।",
                    detectedLanguage = "Bangla",
                    isOfflineFallback = true
                )
            } else {
                ReplyOptions(
                    friendly = "Eito bhai, ektu kaj korchi. Tomar ki khobor bolo?",
                    polite = "Ji, eito ektu kaje basto achi. Apnar ki khobor?",
                    professional = "Dhonnobad, bortomane ektu kaje basto achi. Kono proyojon thakle bolte paren.",
                    detectedLanguage = "Banglish",
                    isOfflineFallback = true
                )
            }
        }

        // Location inquiries ("kothay", "koi", "বাসায়", "কোথায়", "কই")
        if (lower.contains("kothay") || lower.contains("koi ") || lower == "koi" || lower.contains("basay") ||
            lastIncoming.contains("কোথায়") || lastIncoming.contains("কই") || lastIncoming.contains("বাসায়")
        ) {
            return if (hasBanglaScript) {
                ReplyOptions(
                    friendly = "আমি এখন বাসাতেই আছি ভাই। তুমি কোথায়?",
                    polite = "জি, আমি এখন বাসায় আছি। আপনি কোথায় আছেন?",
                    professional = "জি, আমি বর্তমানে আমার নির্ধারিত স্থানেই আছি। প্রয়োজনে জানাতে পারেন।",
                    detectedLanguage = "Bangla",
                    isOfflineFallback = true
                )
            } else {
                ReplyOptions(
                    friendly = "Ami ekhon basay achi bhai. Tumi kothay?",
                    polite = "Ji, ami ekhon basay achi. Apni kothay achen?",
                    professional = "Ji, ami bortomane amar sthane achi. Kono dorkar thakle janaben.",
                    detectedLanguage = "Banglish",
                    isOfflineFallback = true
                )
            }
        }

        // Well-being / How are you ("kemon", "kmn", "কেমন")
        if (lower.contains("kemon") || lower.contains("kmn") || lastIncoming.contains("কেমন")) {
            return if (hasBanglaScript) {
                ReplyOptions(
                    friendly = "আলহামদুলিল্লাহ ভালো আছি! তোমার কী অবস্থা?",
                    polite = "জি আলহামদুলিল্লাহ, ভালো আছি। আপনি কেমন আছেন?",
                    professional = "আলহামদুলিল্লাহ ভালো আছি। আশা করি আপনিও সুস্থ ও ভালো আছেন।",
                    detectedLanguage = "Bangla",
                    isOfflineFallback = true
                )
            } else {
                ReplyOptions(
                    friendly = "Alhamdulillah bhalo achi! Tomar ki obostha?",
                    polite = "Ji Alhamdulillah, bhalo achi. Apni kemon achen?",
                    professional = "Alhamdulillah bhalo achi. Asha kori apnio bhalo achen.",
                    detectedLanguage = "Banglish",
                    isOfflineFallback = true
                )
            }
        }

        // Short greetings ("hy", "hi", "hlw", "hello", "hey", "হাই", "হ্যালো")
        if (lower in listOf("hy", "hi", "hlw", "hello", "hey", "oi", "ভাই", "হাই", "হ্যালো") ||
            lower.startsWith("hi ") || lower.startsWith("hello ") || lower.startsWith("hlw ")
        ) {
            return if (hasBanglaScript) {
                ReplyOptions(
                    friendly = "হ্যালো ভাই! কেমন আছো বলো?",
                    polite = "হ্যালো! কেমন আছেন আপনি?",
                    professional = "হ্যালো, আপনাকে কীভাবে সাহায্য করতে পারি?",
                    detectedLanguage = "Bangla",
                    isOfflineFallback = true
                )
            } else {
                ReplyOptions(
                    friendly = "Hey! Kemon acho? Ki khobor?",
                    polite = "Hello! Apni kemon achen?",
                    professional = "Hello! How can I help you today?",
                    detectedLanguage = "English/Banglish",
                    isOfflineFallback = true
                )
            }
        }

        // Gratitude / OK ("thanks", "thank you", "dhonnobad", "ok", "accha", "আচ্ছা", "ধন্যবাদ")
        if (lower.contains("thank") || lower.contains("dhonnobad") || lower in listOf("ok", "okay", "accha", "acha", "hmm", "hm") ||
            lastIncoming.contains("ধন্যবাদ") || lastIncoming.contains("আচ্ছা") || lastIncoming.contains("ওকে")
        ) {
            return if (hasBanglaScript) {
                ReplyOptions(
                    friendly = "আচ্ছা ভাই, ঠিক আছে!",
                    polite = "জি আচ্ছা, আপনাকেও অনেক ধন্যবাদ।",
                    professional = "অসংখ্য ধন্যবাদ আপনাকে। ভালো থাকবেন।",
                    detectedLanguage = "Bangla",
                    isOfflineFallback = true
                )
            } else {
                ReplyOptions(
                    friendly = "Accha bhai, thik ache!",
                    polite = "Ji accha, apnakeo onek dhonnobad.",
                    professional = "Thank you very much. Have a great day!",
                    detectedLanguage = "Banglish/English",
                    isOfflineFallback = true
                )
            }
        }

        val isBanglish = !hasBanglaScript && listOf(
            "ki", "bhai", "vai", "ache", "achi", "korcho", "koro", "bhalo", "valo", "tumi", "apni", "amar", "tomar", "kobe", "keno", "bol", "bolo"
        ).any { lower.contains(it) }

        return when {
            hasBanglaScript -> ReplyOptions(
                friendly = "হ্যাঁ ভাই, বুঝতে পেরেছি। একটু পর বিস্তারিত জানাচ্ছি!",
                polite = "জি, আপনার মেসেজটি দেখেছি। আমি একটু পর আপনাকে জানাচ্ছি।",
                professional = "ধন্যবাদ আপনার মেসেজের জন্য। আমি বিষয়টি দেখে দ্রুত জানাচ্ছি।",
                detectedLanguage = "Bangla (Smart Auto)",
                isOfflineFallback = true
            )
            isBanglish -> ReplyOptions(
                friendly = "Haa bhai, bujhte perechi! Ektu por janacchi tomake.",
                polite = "Ji, apnar message ti dekhechi. Ami ektu por janacchi.",
                professional = "Dhonnobad message er jonno. Ami dekhe apnake janacchi.",
                detectedLanguage = "Banglish (Smart Auto)",
                isOfflineFallback = true
            )
            else -> ReplyOptions(
                friendly = "Got your message! Doing great, I'll get back to you in a bit.",
                polite = "Thank you for your message! I'm doing well and will reply shortly.",
                professional = "Thank you for reaching out. I have received your message and will respond shortly.",
                detectedLanguage = "English (Smart Auto)",
                isOfflineFallback = true
            )
        }
    }
}
