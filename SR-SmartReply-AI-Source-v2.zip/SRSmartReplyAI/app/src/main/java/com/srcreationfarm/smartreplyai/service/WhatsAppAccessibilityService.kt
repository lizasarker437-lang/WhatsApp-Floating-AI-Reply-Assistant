package com.srcreationfarm.smartreplyai.service

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.ai.GeminiReplyClient
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyHistoryItem
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

class WhatsAppAccessibilityService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private lateinit var settingsManager: SettingsManager
    private lateinit var dbHelper: ReplyDatabaseHelper
    private val geminiClient = GeminiReplyClient()

    private var floatingView: View? = null
    private var windowParams: WindowManager.LayoutParams? = null

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var activeJob: Job? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var currentDetectedSnippet: String = ""
    private var currentReplies: ReplyOptions? = null

    // Anti-Loop & Instant Auto-Reply State Tracking
    private var lastRepliedSignature: String = ""
    private var lastSentReplyText: String = ""
    private var lastAutoReplyTimestamp: Long = 0L
    private var isProcessingAutoReply: Boolean = false

    private val autoScanRunnable = Runnable {
        checkAndTriggerAutoReply()
    }

    companion object {
        @Volatile
        var isServiceRunning: Boolean = false
            private set

        private const val PKG_WHATSAPP = "com.whatsapp"
        private const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"
        private const val COOLDOWN_AFTER_SEND_MS = 2800L
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        settingsManager = SettingsManager.getInstance(this)
        dbHelper = ReplyDatabaseHelper(this)
        setupFloatingOverlay()
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun setupFloatingOverlay() {
        if (floatingView != null) return

        val view = LayoutInflater.from(this).inflate(R.layout.layout_floating_ai, null)
        floatingView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = settingsManager.getOrbX()
            y = settingsManager.getOrbY()
        }
        windowParams = params

        val orbButton = view.findViewById<View>(R.id.btnFloatingOrb)
        val panelContainer = view.findViewById<View>(R.id.panelReplyContainer)
        val btnClosePanel = view.findViewById<View>(R.id.btnClosePanel)
        val btnRegenerate = view.findViewById<View>(R.id.btnRegenerateReply)

        val cardFriendly = view.findViewById<View>(R.id.cardReplyFriendly)
        val cardPolite = view.findViewById<View>(R.id.cardReplyPolite)
        val cardProfessional = view.findViewById<View>(R.id.cardReplyProfessional)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var longPressTriggered = false

        val longPressRunnable = Runnable {
            if (!isDragging) {
                longPressTriggered = true
                triggerHaptic()
                if (panelContainer.visibility == View.VISIBLE) {
                    panelContainer.visibility = View.GONE
                } else {
                    panelContainer.visibility = View.VISIBLE
                    scanAndPopulateManualPanel()
                }
            }
        }

        orbButton.setOnTouchListener { _, event ->
            val currentParams = windowParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = currentParams.x
                    initialY = currentParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    longPressTriggered = false
                    mainHandler.postDelayed(longPressRunnable, 600L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (initialTouchX - event.rawX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    if (abs(deltaX) > 12 || abs(deltaY) > 12) {
                        isDragging = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    if (isDragging) {
                        currentParams.x = (initialX + deltaX).coerceAtLeast(0)
                        currentParams.y = (initialY + deltaY).coerceAtLeast(40)
                        try {
                            windowManager.updateViewLayout(view, currentParams)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (isDragging) {
                        settingsManager.saveOrbPosition(currentParams.x, currentParams.y)
                    } else if (!longPressTriggered) {
                        triggerHaptic()
                        // Single tap toggles Instant Auto-Reply ON / PAUSED
                        val newState = !settingsManager.isFullAutoReplyEnabled()
                        settingsManager.setFullAutoReplyEnabled(newState)
                        updateFloatingBadgeUI()
                        val statusMsg = if (newState) {
                            "Auto-Reply ON (${settingsManager.getSelectedToneLabel()})"
                        } else {
                            "Auto-Reply PAUSED (Long-press button for manual panel)"
                        }
                        Toast.makeText(this, statusMsg, Toast.LENGTH_SHORT).show()
                        if (newState) {
                            lastRepliedSignature = "" // allow immediate check on resume
                            scheduleAutoScan(300L)
                        }
                    }
                    true
                }
                else -> false
            }
        }

        btnClosePanel.setOnClickListener {
            panelContainer.visibility = View.GONE
        }

        btnRegenerate.setOnClickListener {
            triggerHaptic()
            scanAndPopulateManualPanel()
        }

        cardFriendly.setOnClickListener {
            currentReplies?.friendly?.let { reply ->
                handleReplySelected(reply, "Friendly")
            }
        }
        cardPolite.setOnClickListener {
            currentReplies?.polite?.let { reply ->
                handleReplySelected(reply, "Polite")
            }
        }
        cardProfessional.setOnClickListener {
            currentReplies?.professional?.let { reply ->
                handleReplySelected(reply, "Professional")
            }
        }

        cardFriendly.setOnLongClickListener {
            currentReplies?.friendly?.let { copyToClipboard(it) }
            true
        }
        cardPolite.setOnLongClickListener {
            currentReplies?.polite?.let { copyToClipboard(it) }
            true
        }
        cardProfessional.setOnLongClickListener {
            currentReplies?.professional?.let { copyToClipboard(it) }
            true
        }

        try {
            windowManager.addView(view, params)
            view.visibility = View.GONE
            updateFloatingBadgeUI()
        } catch (_: Exception) {
        }
    }

    private fun updateFloatingBadgeUI(customText: String? = null) {
        val badge = floatingView?.findViewById<TextView>(R.id.tvFloatingStatusBadge) ?: return
        if (customText != null) {
            badge.text = customText
            badge.setTextColor(Color.parseColor("#38BDF8"))
            return
        }
        if (settingsManager.isFullAutoReplyEnabled()) {
            badge.text = "AUTO: ${settingsManager.getSelectedToneShortLabel()}"
            badge.setTextColor(Color.parseColor("#34D399"))
        } else {
            badge.text = "PAUSED"
            badge.setTextColor(Color.parseColor("#F87171"))
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        val overlay = floatingView ?: return

        val isSupportedWhatsApp = pkg == PKG_WHATSAPP ||
                (pkg == PKG_WHATSAPP_BUSINESS && settingsManager.isWhatsAppBusinessEnabled())

        if (isSupportedWhatsApp) {
            if (settingsManager.isFloatingEnabled()) {
                if (overlay.visibility != View.VISIBLE) {
                    overlay.visibility = View.VISIBLE
                }
                updateFloatingBadgeUI()
            } else {
                overlay.visibility = View.GONE
            }

            // Trigger automatic incoming message check when screen content updates
            if (settingsManager.isFullAutoReplyEnabled()) {
                scheduleAutoScan(settingsManager.getAutoReplyDelayMs())
            }
        } else if (!pkg.startsWith("com.android.systemui") && !pkg.startsWith("com.google.android.inputmethod")) {
            mainHandler.removeCallbacks(autoScanRunnable)
            overlay.visibility = View.GONE
            overlay.findViewById<View>(R.id.panelReplyContainer)?.visibility = View.GONE
        }
    }

    private fun scheduleAutoScan(delayMs: Long) {
        mainHandler.removeCallbacks(autoScanRunnable)
        mainHandler.postDelayed(autoScanRunnable, delayMs)
    }

    private fun checkAndTriggerAutoReply() {
        if (!settingsManager.isFullAutoReplyEnabled()) return
        if (isProcessingAutoReply) return

        val now = System.currentTimeMillis()
        if (now - lastAutoReplyTimestamp < COOLDOWN_AFTER_SEND_MS) {
            return
        }

        val rootNode = rootInActiveWindow ?: return
        val pkg = rootNode.packageName?.toString() ?: return
        val isSupportedWhatsApp = pkg == PKG_WHATSAPP ||
                (pkg == PKG_WHATSAPP_BUSINESS && settingsManager.isWhatsAppBusinessEnabled())
        if (!isSupportedWhatsApp) return

        // 1. Verify we are inside an active chat conversation (message input box must exist)
        val inputNode = findWhatsAppInputNode(rootNode) ?: return

        // 2. Do not interrupt if user is manually typing a message in the input box
        if (isUserManuallyTyping(inputNode)) return

        // 3. Scan visible chat messages
        val messages = scanVisibleWhatsAppMessages(settingsManager.getContextDepth(), rootNode)
        if (messages.isEmpty()) return

        // 4. Only auto-reply if the VERY LAST (bottom-most) message in the chat is "Incoming"
        val lastMessage = messages.last()
        if (lastMessage.sender != "Incoming") return

        val incomingText = lastMessage.text.trim()
        if (incomingText.isEmpty() || incomingText == lastSentReplyText) return

        val contactTitle = detectContactTitle(rootNode)
        val signature = "$contactTitle::$incomingText"

        // 5. Prevent replying twice to the exact same incoming message
        if (signature == lastRepliedSignature) return

        isProcessingAutoReply = true
        lastRepliedSignature = signature
        currentDetectedSnippet = incomingText
        updateFloatingBadgeUI("Replying...")

        activeJob?.cancel()
        activeJob = serviceScope.launch {
            try {
                val options = geminiClient.generateReplies(
                    apiKey = settingsManager.getApiKey(),
                    messages = messages,
                    languagePreference = settingsManager.getLanguagePreference()
                )
                currentReplies = options

                val chosenToneKey = settingsManager.getSelectedTone()
                val chosenToneLabel = settingsManager.getSelectedToneShortLabel()
                val replyToSend = options.getReplyByTone(chosenToneKey)

                if (replyToSend.isNotBlank()) {
                    lastSentReplyText = replyToSend
                    lastAutoReplyTimestamp = System.currentTimeMillis()
                    handleReplySelected(replyToSend, chosenToneLabel)
                }
            } catch (_: Exception) {
            } finally {
                mainHandler.postDelayed({
                    isProcessingAutoReply = false
                    updateFloatingBadgeUI()
                }, 1200L)
            }
        }
    }

    private fun scanAndPopulateManualPanel() {
        val view = floatingView ?: return
        val tvDetected = view.findViewById<TextView>(R.id.tvDetectedMessage)
        val progress = view.findViewById<ProgressBar>(R.id.progressAiLoading)
        val tvFriendly = view.findViewById<TextView>(R.id.tvReplyFriendly)
        val tvPolite = view.findViewById<TextView>(R.id.tvReplyPolite)
        val tvProfessional = view.findViewById<TextView>(R.id.tvReplyProfessional)

        val rootNode = rootInActiveWindow
        val messages = scanVisibleWhatsAppMessages(settingsManager.getContextDepth(), rootNode)
        if (messages.isEmpty()) {
            tvDetected.text = "No open chat messages detected. Open a WhatsApp conversation first."
            return
        }

        val latestIncoming = messages.lastOrNull { it.sender == "Incoming" }?.text
            ?: messages.last().text
        currentDetectedSnippet = latestIncoming
        tvDetected.text = "Message: $latestIncoming"

        progress.visibility = View.VISIBLE
        tvFriendly.text = "Generating..."
        tvPolite.text = "Generating..."
        tvProfessional.text = "Generating..."

        activeJob?.cancel()
        activeJob = serviceScope.launch {
            val options = geminiClient.generateReplies(
                apiKey = settingsManager.getApiKey(),
                messages = messages,
                languagePreference = settingsManager.getLanguagePreference()
            )
            currentReplies = options
            progress.visibility = View.GONE
            tvFriendly.text = options.friendly
            tvPolite.text = options.polite
            tvProfessional.text = options.professional
        }
    }

    private fun detectContactTitle(rootNode: AccessibilityNodeInfo): String {
        val titleIds = listOf(
            "com.whatsapp:id/conversation_contact_name",
            "com.whatsapp.w4b:id/conversation_contact_name"
        )
        for (id in titleIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                val name = found.first().text?.toString()?.trim()
                if (!name.isNullOrEmpty()) return name
            }
        }
        return "ActiveChat"
    }

    private fun isUserManuallyTyping(inputNode: AccessibilityNodeInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (inputNode.isShowingHintText) return false
        }
        val existing = inputNode.text?.toString()?.trim() ?: return false
        if (existing.isEmpty()) return false
        val commonHints = setOf("message", "type a message", "মেসেজ", "বার্তা লিখুন")
        return existing.lowercase() !in commonHints
    }

    private fun scanVisibleWhatsAppMessages(
        maxCount: Int,
        root: AccessibilityNodeInfo? = rootInActiveWindow
    ): List<ChatMessage> {
        val rootNode = root ?: return emptyList()
        val screenWidth = resources.displayMetrics.widthPixels
        val results = mutableListOf<ChatMessage>()

        val viewIds = listOf(
            "com.whatsapp:id/message_text",
            "com.whatsapp.w4b:id/message_text"
        )

        var nodes: List<AccessibilityNodeInfo> = emptyList()
        for (id in viewIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                nodes = found
                break
            }
        }

        if (nodes.isNotEmpty()) {
            // Sort nodes top-to-bottom by screen vertical position to ensure accurate chronological order
            val sortedNodes = nodes.mapNotNull { node ->
                val text = node.text?.toString()?.trim()
                if (text.isNullOrEmpty()) null
                else {
                    val rect = Rect()
                    node.getBoundsInScreen(rect)
                    Triple(rect.top, rect.left, text)
                }
            }.sortedBy { it.first }

            for ((_, leftPos, text) in sortedNodes.takeLast(maxCount)) {
                val sender = if (leftPos < screenWidth / 4) "Incoming" else "Me"
                results.add(ChatMessage(sender, text))
            }
        } else {
            collectFallbackTextNodes(rootNode, screenWidth, resources.displayMetrics.heightPixels, results)
        }

        return results.takeLast(maxCount)
    }

    private fun collectFallbackTextNodes(
        node: AccessibilityNodeInfo?,
        screenWidth: Int,
        screenHeight: Int,
        out: MutableList<ChatMessage>
    ) {
        if (node == null) return
        val className = node.className?.toString() ?: ""
        if (className == "android.widget.TextView" && !node.isEditable) {
            val txt = node.text?.toString()?.trim() ?: ""
            if (txt.length >= 2 && !txt.matches(Regex("^\\d{1,2}:\\d{2}\\s?(AM|PM|am|pm)?$"))) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.top > screenHeight / 6 && rect.bottom < (screenHeight * 0.86)) {
                    val sender = if (rect.left < screenWidth / 4) "Incoming" else "Me"
                    out.add(ChatMessage(sender, txt))
                }
            }
        }
        for (i in 0 until node.childCount) {
            collectFallbackTextNodes(node.getChild(i), screenWidth, screenHeight, out)
        }
    }

    private fun handleReplySelected(replyText: String, tone: String) {
        triggerHaptic()
        if (settingsManager.isSaveHistoryEnabled()) {
            dbHelper.insertReply(
                ReplyHistoryItem(
                    incomingSnippet = currentDetectedSnippet.ifEmpty { "WhatsApp Chat" },
                    selectedReply = replyText,
                    tone = tone,
                    timestamp = System.currentTimeMillis()
                )
            )
        }

        val inserted = insertTextIntoWhatsApp(replyText)
        if (inserted) {
            floatingView?.findViewById<View>(R.id.panelReplyContainer)?.visibility = View.GONE
            if (settingsManager.isAutoSendEnabled()) {
                mainHandler.postDelayed({
                    clickWhatsAppSendButton()
                }, 220L)
            }
        } else {
            copyToClipboard(replyText)
        }
    }

    private fun findWhatsAppInputNode(rootNode: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val entryIds = listOf("com.whatsapp:id/entry", "com.whatsapp.w4b:id/entry")
        for (id in entryIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                return found.first()
            }
        }
        return findFirstEditableNode(rootNode)
    }

    private fun insertTextIntoWhatsApp(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val inputNode = findWhatsAppInputNode(rootNode) ?: return false

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findFirstEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun clickWhatsAppSendButton() {
        val rootNode = rootInActiveWindow ?: return
        val sendIds = listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")
        for (id in sendIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                found.first().performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return
            }
        }
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("SR SmartReply", text))
        Toast.makeText(this, "Reply copied!", Toast.LENGTH_SHORT).show()
    }

    private fun triggerHaptic() {
        if (!settingsManager.isHapticEnabled()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(30)
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onInterrupt() {
        isServiceRunning = false
    }

    override fun onDestroy() {
        isServiceRunning = false
        mainHandler.removeCallbacks(autoScanRunnable)
        serviceScope.cancel()
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        floatingView = null
        super.onDestroy()
    }
}
