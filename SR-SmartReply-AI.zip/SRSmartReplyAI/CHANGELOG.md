# Changelog

## [2.2.0] - 2026-11-17
### Added & Optimized
- **Last 4-5 Messages Context Thread Analyzer (`ReplyJsonParser.analyzeConversationThread`):**
  - Scans the last 5 visible messages on screen to track ongoing conversation topic (`FOOD`, `ACTIVITY_WORK`, `LOCATION`, `SLEEP`, `FAMILY`, `CALL`, `PLAN_MEET`, `WELLBEING`), pronoun intimacy (`তুই/Tui`, `তুমি/Tumi`, `আপনি/Apni`), and script (`Bangla`, `Banglish`, `English`).
  - Resolves short follow-up final messages (`"Na"`, `"Tumi?"`, `"Kiser?"`, `"Keno?"`, `"Ki diye?"`) accurately using the context of the preceding 4 messages.
- **Ultra-Fast Single-Reply Pipeline (`GeminiReplyClient.generateFastSingleReply`):**
  - Generates ONLY the single active tone reply during Auto-Reply mode (cutting token generation time by ~65%).
  - Reduced Accessibility detection debounce to `150ms` and Send button click delay to `80ms` (with a `180ms` backup click) for near-instantaneous auto-replying.
