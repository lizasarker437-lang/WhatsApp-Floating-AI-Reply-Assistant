package com.srcreationfarm.smartreplyai

import com.srcreationfarm.smartreplyai.ai.ReplyJsonParser
import com.srcreationfarm.smartreplyai.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReplyJsonParserTest {

    @Test
    fun parseFastSingleReply_extractsSingleReplyInstantly() {
        val raw = """{"reply": "Haa dosto, ektu agei khailam. Tui khaisos?"}"""
        val reply = ReplyJsonParser.parseFastSingleReply(raw, "friendly")
        assertEquals("Haa dosto, ektu agei khailam. Tui khaisos?", reply)
    }

    @Test
    fun analyzeConversationThread_analyzesLastFiveMessagesAndResolvesFollowUp() {
        val fiveMessageThread = listOf(
            ChatMessage("Incoming", "Kire dosto ki koros?"),
            ChatMessage("Me", "Eito basay bose achi re. Tui?"),
            ChatMessage("Incoming", "Dupure ভাত khaisos?"),
            ChatMessage("Me", "Haa ektu agei khailam. Tui khaisos?"),
            ChatMessage("Incoming", "Na")
        )

        val ctx = ReplyJsonParser.analyzeConversationThread(fiveMessageThread)
        assertEquals(ReplyJsonParser.PronounStyle.TUI, ctx.pronounStyle)
        assertEquals(ReplyJsonParser.ConversationTopic.FOOD, ctx.previousTopic)
        assertEquals("Na", ctx.lastIncomingMessage)

        val options = ReplyJsonParser.buildSmartFallbackReplies(fiveMessageThread)
        // Because the previous 4 messages were about FOOD and TUI pronoun, "Na" triggers a TUI-style food reply!
        assertTrue(options.friendly.contains("khas", ignoreCase = true) || options.friendly.contains("kheye", ignoreCase = true))
    }

    @Test
    fun buildSmartFallbackReplies_resolvesReciprocalShortFollowUpFromContext() {
        val thread = listOf(
            ChatMessage("Incoming", "Khaico ki?"),
            ChatMessage("Me", "Haa Alhamdulillah khawa shesh. Tumi khaico?"),
            ChatMessage("Incoming", "Haa. Tumi?")
        )
        val options = ReplyJsonParser.buildSmartFallbackReplies(thread)
        assertTrue(options.detectedLanguage.contains("Food"))
    }
}
