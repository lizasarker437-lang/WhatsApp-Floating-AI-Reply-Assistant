package com.srcreationfarm.smartreplyai

import com.srcreationfarm.smartreplyai.ai.ReplyJsonParser
import com.srcreationfarm.smartreplyai.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReplyJsonParserTest {

    @Test
    fun parseAiReply_extractsReplyCleanly() {
        val raw = "{\"reply\": \"Haa dosto, ektu agei khailam. Tui khaisos?\"}"
        val reply = ReplyJsonParser.parseAiReply(raw)
        assertEquals("Haa dosto, ektu agei khailam. Tui khaisos?", reply)
    }

    @Test
    fun buildSmartContextualReply_handlesScreenshot41MessagesCoherently() {
        val r1 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Kisui Kori ni....din to matro suru"))
        )
        assertTrue(r1.reply.contains("shuru", ignoreCase = true) || r1.reply.contains("nasta", ignoreCase = true))

        val r2 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Jasce alhamdulilha valo"))
        )
        assertTrue(r2.reply.contains("Alhamdulillah", ignoreCase = true))

        val r3 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Akta Kotha boloto"))
        )
        assertTrue(r3.reply.contains("bolo", ignoreCase = true) || r3.reply.contains("shunchi", ignoreCase = true))

        val r4 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Ami akta jinis jiggas kirbo"))
        )
        assertTrue(r4.reply.contains("bolo", ignoreCase = true) || r4.reply.contains("jiggesh", ignoreCase = true))
        assertFalse(r4.reply.any { it in '\u0980'..'\u09FF' })

        val r5 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Babu"))
        )
        assertTrue(r5.reply.contains("babu", ignoreCase = true) || r5.reply.contains("bolo", ignoreCase = true))
        assertFalse(r5.reply.any { it in '\u0980'..'\u09FF' })
    }

    @Test
    fun buildSmartContextualReply_handlesScreenshot55SequenceWithZeroRepetition() {
        val chat = mutableListOf<ChatMessage>()
        val sentSet = mutableSetOf<String>()

        // 1. "Hy"
        chat.add(ChatMessage("Incoming", "Hy"))
        val rep1 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        sentSet.add(rep1)
        chat.add(ChatMessage("Me", rep1))

        // 2. "Alhamdulilha valo tmr ki obostha" -> must say amio bhalo achi
        chat.add(ChatMessage("Incoming", "Alhamdulilha valo tmr ki obostha"))
        val rep2 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        assertTrue(rep2.contains("bhalo", ignoreCase = true))
        sentSet.add(rep2)
        chat.add(ChatMessage("Me", rep2))

        // 3. "Nasta korci...tmi korco ki" -> must NOT re-ask "Tumi nasta korcho?"
        chat.add(ChatMessage("Incoming", "Nasta korci...tmi korco ki"))
        val rep3 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        assertFalse(rep3.contains("Tumi nasta korcho", ignoreCase = true))
        sentSet.add(rep3)
        chat.add(ChatMessage("Me", rep3))

        // 4. "Bollam to korci ...abar jiggas korla je" -> must apologize for repeating question
        chat.add(ChatMessage("Incoming", "Bollam to korci ...abar jiggas korla je"))
        val rep4 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        assertTrue(rep4.contains("sorry", ignoreCase = true))
        sentSet.add(rep4)
        chat.add(ChatMessage("Me", rep4))

        // 5. "Tmi asole k" -> must answer identity ("Shahriar" / "chinte parcho na"), NEVER repeat rep4!
        chat.add(ChatMessage("Incoming", "Tmi asole k"))
        val rep5 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        assertTrue(rep5.contains("Shahriar", ignoreCase = true) || rep5.contains("chinte", ignoreCase = true))
        assertFalse(rep5.contains("bolo bolo", ignoreCase = true))
        sentSet.add(rep5)
        chat.add(ChatMessage("Me", rep5))

        assertEquals(5, sentSet.size)
    }
}
