package com.srcreationfarm.smartreplyai

import com.srcreationfarm.smartreplyai.ai.ReplyJsonParser
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReplyJsonParserTest {

    @Test
    fun parseAiReply_extractsReplyCleanly() {
        val raw = "{\"reply\": \"Haa dosto, ektu agei khailam. Tui khaisos?\"}"
        val reply = ReplyJsonParser.parseAiReply(raw)
        assertEquals("Haa dosto, ektu agei khailam. Tui khaisos?", reply)
    }

    @Test
    fun matchesTargetContact_matchesSpecificNameAndFormattedPhoneNumberAccurately() {
        // 1. Exact & case-insensitive name match
        assertTrue(SettingsManager.matchesTargetContact("SR", "sr"))
        assertTrue(SettingsManager.matchesTargetContact("Md Shahriar", "Shahriar"))
        assertFalse(SettingsManager.matchesTargetContact("Karim", "SR"))

        // 2. Phone number match across +880, spaces, and hyphens
        assertTrue(SettingsManager.matchesTargetContact("+880 1712-345678", "01712345678"))
        assertTrue(SettingsManager.matchesTargetContact("01712-345678", "+8801712345678"))
        assertFalse(SettingsManager.matchesTargetContact("+880 1811-000000", "01712345678"))
    }

    @Test
    fun buildSmartContextualReply_handlesScreenshot55SequenceWithZeroRepetition() {
        val chat = mutableListOf<ChatMessage>()
        val sentSet = mutableSetOf<String>()

        chat.add(ChatMessage("Incoming", "Hy"))
        val rep1 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        sentSet.add(rep1)
        chat.add(ChatMessage("Me", rep1))

        chat.add(ChatMessage("Incoming", "Alhamdulilha valo tmr ki obostha"))
        val rep2 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        assertTrue(rep2.contains("bhalo", ignoreCase = true))
        sentSet.add(rep2)
        chat.add(ChatMessage("Me", rep2))

        chat.add(ChatMessage("Incoming", "Nasta korci...tmi korco ki"))
        val rep3 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        assertFalse(rep3.contains("Tumi nasta korcho", ignoreCase = true))
        sentSet.add(rep3)
        chat.add(ChatMessage("Me", rep3))

        chat.add(ChatMessage("Incoming", "Bollam to korci ...abar jiggas korla je"))
        val rep4 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        assertTrue(rep4.contains("sorry", ignoreCase = true))
        sentSet.add(rep4)
        chat.add(ChatMessage("Me", rep4))

        chat.add(ChatMessage("Incoming", "Tmi asole k"))
        val rep5 = ReplyJsonParser.buildSmartContextualReply(chat, sentSet).reply
        assertTrue(rep5.contains("Shahriar", ignoreCase = true) || rep5.contains("chinte", ignoreCase = true))
        assertFalse(rep5.contains("bolo bolo", ignoreCase = true))
        sentSet.add(rep5)
        chat.add(ChatMessage("Me", rep5))

        assertEquals(5, sentSet.size)
    }
}
