package com.srcreationfarm.smartreplyai

import com.srcreationfarm.smartreplyai.ai.ReplyJsonParser
import com.srcreationfarm.smartreplyai.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReplyJsonParserTest {

    @Test
    fun parseAiReply_extractsReplyCleanly() {
        val raw = "{\"reply\": \"Haa dosto, ektu agei khailam. Tui khaisos?\"}"
        val reply = ReplyJsonParser.parseAiReply(raw)
        assertEquals("Haa dosto, ektu agei khailam. Tui khaisos?", reply)
    }

    @Test
    fun buildSmartContextualReply_handlesScreenshotMessagesCoherently() {
        // 1. "Kisui Kori ni....din to matro suru" -> should acknowledge day just started
        val r1 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Kisui Kori ni....din to matro suru"))
        )
        assertTrue(r1.reply.contains("shuru", ignoreCase = true) || r1.reply.contains("nasta", ignoreCase = true))

        // 2. "Jasce alhamdulilha valo" -> should respond warmly to positive wellbeing
        val r2 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Jasce alhamdulilha valo"))
        )
        assertTrue(r2.reply.contains("Alhamdulillah", ignoreCase = true))

        // 3. "Akta Kotha boloto" -> should invite the user to ask/speak
        val r3 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Akta Kotha boloto"))
        )
        assertTrue(r3.reply.contains("bolo", ignoreCase = true) || r3.reply.contains("shunchi", ignoreCase = true))

        // 4. "Ami akta jinis jiggas kirbo" -> should invite the question, never mix Bangla script
        val r4 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Ami akta jinis jiggas kirbo"))
        )
        assertTrue(r4.reply.contains("bolo", ignoreCase = true) || r4.reply.contains("jiggesh", ignoreCase = true))
        assertFalse(r4.reply.any { it in '\u0980'..'\u09FF' })

        // 5. "Babu" -> should reply affectionately in Banglish, NOT family inquiry in Bangla script
        val r5 = ReplyJsonParser.buildSmartContextualReply(
            listOf(ChatMessage("Incoming", "Babu"))
        )
        assertTrue(r5.reply.contains("babu", ignoreCase = true) || r5.reply.contains("bolo", ignoreCase = true))
        assertFalse(r5.reply.any { it in '\u0980'..'\u09FF' })
    }

    @Test
    fun buildSmartContextualReply_adaptsDirectlyToMessageAndContext() {
        val fiveMessageThread = listOf(
            ChatMessage("Incoming", "Kire dosto ki koros?"),
            ChatMessage("Me", "Eito basay bose achi re. Tui?"),
            ChatMessage("Incoming", "Dupure ভাত khaisos?"),
            ChatMessage("Me", "Haa ektu agei khailam. Tui khaisos?"),
            ChatMessage("Incoming", "Na")
        )

        val ctx = ReplyJsonParser.analyzeConversationThread(fiveMessageThread)
        assertEquals(ReplyJsonParser.PronounStyle.TUI, ctx.pronounStyle)
        assertEquals(ReplyJsonParser.ConversationTopic.FOOD, ctx.previousTopic)

        val result = ReplyJsonParser.buildSmartContextualReply(fiveMessageThread)
        assertTrue(result.reply.contains("khas", ignoreCase = true) || result.reply.contains("kheye", ignoreCase = true))
    }
}
