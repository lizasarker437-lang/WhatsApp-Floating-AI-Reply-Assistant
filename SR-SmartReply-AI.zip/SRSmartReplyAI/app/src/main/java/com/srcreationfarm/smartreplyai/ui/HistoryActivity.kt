package com.srcreationfarm.smartreplyai.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.ThemeManager
import com.srcreationfarm.smartreplyai.model.ReplyHistoryItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {

    private lateinit var dbHelper: ReplyDatabaseHelper
    private lateinit var adapter: HistoryAdapter
    private lateinit var tvEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        dbHelper = ReplyDatabaseHelper(this)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbarHistory)
        toolbar.setNavigationOnClickListener { finish() }

        tvEmpty = findViewById(R.id.tvEmptyHistory)
        val recycler = findViewById<RecyclerView>(R.id.recyclerHistory)
        recycler.layoutManager = LinearLayoutManager(this)

        adapter = HistoryAdapter(
            onCopy = { item ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("SR SmartReply", item.selectedReply))
                Toast.makeText(this, "Copied to clipboard!", Toast.LENGTH_SHORT).show()
            },
            onDelete = { item ->
                dbHelper.deleteById(item.id)
                loadHistory(findViewById<EditText>(R.id.etSearchHistory).text.toString())
            }
        )
        recycler.adapter = adapter

        val etSearch = findViewById<EditText>(R.id.etSearchHistory)
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                loadHistory(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        findViewById<MaterialButton>(R.id.btnClearHistory).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear All History?")
                .setMessage("Delete all saved AI replies permanently?")
                .setPositiveButton("Clear") { _, _ ->
                    dbHelper.clearAll()
                    loadHistory("")
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        loadHistory("")
    }

    private fun loadHistory(query: String) {
        val items = dbHelper.getAllReplies(query)
        adapter.submitList(items)
        tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private class HistoryAdapter(
        private val onCopy: (ReplyHistoryItem) -> Unit,
        private val onDelete: (ReplyHistoryItem) -> Unit
    ) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

        private var items: List<ReplyHistoryItem> = emptyList()
        private val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

        fun submitList(newList: List<ReplyHistoryItem>) {
            items = newList
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_history, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvTone.text = item.tone.uppercase(Locale.getDefault())
            holder.tvTime.text = dateFormat.format(Date(item.timestamp))
            holder.tvIncoming.text = "Chat: ${item.incomingSnippet}"
            holder.tvReply.text = item.selectedReply
            holder.btnCopy.setOnClickListener { onCopy(item) }
            holder.btnDelete.setOnClickListener { onDelete(item) }
        }

        override fun getItemCount(): Int = items.size

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvTone: TextView = view.findViewById(R.id.tvItemTone)
            val tvTime: TextView = view.findViewById(R.id.tvItemTimestamp)
            val tvIncoming: TextView = view.findViewById(R.id.tvItemIncoming)
            val tvReply: TextView = view.findViewById(R.id.tvItemReply)
            val btnCopy: MaterialButton = view.findViewById(R.id.btnItemCopy)
            val btnDelete: MaterialButton = view.findViewById(R.id.btnItemDelete)
        }
    }
}
