package com.srcreationfarm.smartreplyai.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.srcreationfarm.smartreplyai.BuildConfig
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.manager.ThemeManager

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbarAbout)
        toolbar.setNavigationOnClickListener { finish() }

        findViewById<TextView>(R.id.tvAboutVersion).text =
            "Version ${BuildConfig.VERSION_NAME} (Build ${BuildConfig.VERSION_CODE})"

        findViewById<MaterialButton>(R.id.btnAboutYoutube).setOnClickListener {
            openUrl(getString(R.string.youtube_url))
        }

        findViewById<MaterialButton>(R.id.btnAboutFacebook).setOnClickListener {
            openUrl(getString(R.string.facebook_url))
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open $url", Toast.LENGTH_SHORT).show()
        }
    }
}
