package com.srcreationfarm.smartreplyai

import android.app.Application
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.manager.ThemeManager

class SmartReplyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val settings = SettingsManager.getInstance(this)
        ThemeManager.applyNightMode(settings.getAppearanceMode())
    }
}
