package com.srcreationfarm.smartreplyai.model

data class ReplyHistoryItem(
    val id: Long = 0,
    val incomingSnippet: String,
    val selectedReply: String,
    val tone: String,
    val timestamp: Long
)
