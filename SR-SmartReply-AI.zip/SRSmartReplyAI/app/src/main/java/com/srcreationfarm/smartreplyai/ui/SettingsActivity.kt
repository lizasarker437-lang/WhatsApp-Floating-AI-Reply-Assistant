package com.srcreationfarm.smartreplyai.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.ai.GeminiReplyClient
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.manager.ThemeManager
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var settingsManager: SettingsManager
    private val geminiClient = GeminiReplyClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        settingsManager = SettingsManager.getInstance(this)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbarSettings)
        toolbar.setNavigationOnClickListener { finish() }

        setupGeneralSection()
        setupAppearanceSection()
        setupAutomationSection()
        setupPrivacySection()
    }

    private fun setupGeneralSection() {
        val etApiKey = findViewById<TextInputEditText>(R.id.etGeminiApiKey)
        etApiKey.setText(settingsManager.getApiKey())

        val btnSave = findViewById<MaterialButton>(R.id.btnSaveApiKey)
        btnSave.text = "Save & Test API Key"

        btnSave.setOnClickListener {
            val cleanKey = SettingsManager.sanitizeApiKey(etApiKey.text?.toString() ?: "")
            etApiKey.setText(cleanKey)
            settingsManager.setApiKey(cleanKey)
            Toast.makeText(this, "🔄 Gemini সংযোগ পরীক্ষা করা হচ্ছে...", Toast.LENGTH_SHORT).show()

            lifecycleScope.launch {
                val res = geminiClient.verifyGeminiConnection(cleanKey, "Assalamu Alaikum, kemon acho?")
                if (res.isSuccess && res.reply.isNotBlank()) {
                    settingsManager.recordConnectionSuccess(res.modelUsed, res.latencyMs)
                    AlertDialog.Builder(this@SettingsActivity)
                        .setTitle("✅ Gemini সংযোগ সফল!")
                        .setMessage(
                            "আপনার Gemini API Key সঠিকভাবে কাজ করছে।\n\n" +
                            "🤖 মডেল: ${res.modelUsed}\n" +
                            "⚡ সময়: ${res.latencyMs}ms\n" +
                            "✨ টেস্ট রিপ্লাই: \"${res.reply}\""
                        )
                        .setPositiveButton("OK", null)
                        .show()
                } else {
                    val err = res.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                    settingsManager.recordConnectionFailure(err)
                    AlertDialog.Builder(this@SettingsActivity)
                        .setTitle(err)
                        .setMessage(res.detailedDiagnostics)
                        .setPositiveButton("Get Free Key (AIza)") { _, _ ->
                            try {
                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey")))
                            } catch (_: Exception) {
                            }
                        }
                        .setNegativeButton("Close", null)
                        .show()
                }
            }
        }

        findViewById<MaterialButton>(R.id.btnGetApiKeyHelp).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey")))
            } catch (_: Exception) {
                Toast.makeText(this, "Visit aistudio.google.com/app/apikey", Toast.LENGTH_LONG).show()
            }
        }

        val tvDepth = findViewById<TextView>(R.id.tvContextDepthLabel)
        val sliderDepth = findViewById<Slider>(R.id.sliderContextDepth)
        val initialDepth = settingsManager.getContextDepth()
        sliderDepth.value = initialDepth.toFloat()
        tvDepth.text = "Chat Context Scan Depth: $initialDepth messages"

        sliderDepth.addOnChangeListener { _, value, _ ->
            val intVal = value.toInt()
            settingsManager.setContextDepth(intVal)
            tvDepth.text = "Chat Context Scan Depth: $intVal messages"
        }
    }

    private fun setupAppearanceSection() {
        val btnMode = findViewById<MaterialButton>(R.id.btnSelectAppearanceMode)
        val btnTheme = findViewById<MaterialButton>(R.id.btnSelectColorTheme)

        val modes = ThemeManager.APPEARANCE_MODES.toTypedArray()
        btnMode.text = "Appearance Mode: ${modes[settingsManager.getAppearanceMode().coerceIn(0, 2)]}"
        btnTheme.text = "Color Theme: ${settingsManager.getColorTheme()}"

        btnMode.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Appearance Mode")
                .setSingleChoiceItems(modes, settingsManager.getAppearanceMode()) { dialog, which ->
                    settingsManager.setAppearanceMode(which)
                    ThemeManager.applyNightMode(which)
                    dialog.dismiss()
                    recreate()
                }
                .show()
        }

        btnTheme.setOnClickListener {
            val themes = ThemeManager.ALL_THEMES.toTypedArray()
            val idx = themes.indexOf(settingsManager.getColorTheme()).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle("Select Color Theme")
                .setSingleChoiceItems(themes, idx) { dialog, which ->
                    settingsManager.setColorTheme(themes[which])
                    dialog.dismiss()
                    recreate()
                }
                .show()
        }
    }

    private fun setupAutomationSection() {
        val switchAutoSend = findViewById<MaterialSwitch>(R.id.switchSettingsAutoSend)
        val switchHistory = findViewById<MaterialSwitch>(R.id.switchSettingsSaveHistory)
        val switchHaptic = findViewById<MaterialSwitch>(R.id.switchSettingsHaptic)

        switchAutoSend.isChecked = settingsManager.isAutoSendEnabled()
        switchHistory.isChecked = settingsManager.isSaveHistoryEnabled()
        switchHaptic.isChecked = settingsManager.isHapticEnabled()

        switchAutoSend.setOnCheckedChangeListener { _, checked ->
            settingsManager.setAutoSendEnabled(checked)
        }
        switchHistory.setOnCheckedChangeListener { _, checked ->
            settingsManager.setSaveHistoryEnabled(checked)
        }
        switchHaptic.setOnCheckedChangeListener { _, checked ->
            settingsManager.setHapticEnabled(checked)
        }
    }

    @SuppressLint("BatteryLife")
    private fun setupPrivacySection() {
        findViewById<MaterialButton>(R.id.btnBatteryOptimization).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }

        findViewById<MaterialButton>(R.id.btnRestrictedSettingsGuide).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Android 13+ / HyperOS / MIUI Setup")
                .setMessage(
                    "If Accessibility permission is restricted for sideloaded APKs:\n\n" +
                    "1. Open Phone Settings > Apps > SR SmartReply AI.\n" +
                    "2. Tap the 3-dot menu (⋮) in the top-right corner.\n" +
                    "3. Select 'Allow restricted settings'.\n" +
                    "4. Return to Accessibility > Downloaded Apps and enable SR SmartReply AI."
                )
                .setPositiveButton("Open App Info") { _, _ ->
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                }
                .setNegativeButton("Close", null)
                .show()
        }

        findViewById<MaterialButton>(R.id.btnResetAllSettings).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Reset Everything?")
                .setMessage("This will clear your API key, preferences, and saved reply history.")
                .setPositiveButton("Reset") { _, _ ->
                    settingsManager.resetAll()
                    ReplyDatabaseHelper(this).clearAll()
                    Toast.makeText(this, "All settings and history cleared.", Toast.LENGTH_SHORT).show()
                    recreate()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}
