package com.srcreationfarm.smartreplyai.model

data class ChatMessage(
    val sender: String, // "Incoming" or "Me"
    val text: String
)
