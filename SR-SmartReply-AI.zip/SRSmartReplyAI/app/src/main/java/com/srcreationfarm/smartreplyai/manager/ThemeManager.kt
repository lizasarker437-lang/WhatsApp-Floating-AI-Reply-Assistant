package com.srcreationfarm.smartreplyai.manager

import android.app.Activity
import androidx.appcompat.app.AppCompatDelegate
import com.srcreationfarm.smartreplyai.R

object ThemeManager {

    const val THEME_MIDNIGHT_GOLD = "Midnight Gold"
    const val THEME_OCEAN_BLUE = "Ocean Blue"
    const val THEME_EMERALD_GREEN = "Emerald Green"
    const val THEME_ROYAL_PURPLE = "Royal Purple"
    const val THEME_SUNSET_CORAL = "Sunset Coral"
    const val THEME_GRAPHITE_CYAN = "Graphite Cyan"
    const val THEME_ROSE_QUARTZ = "Rose Quartz"
    const val THEME_ARCTIC_MINT = "Arctic Mint"
    const val THEME_LIGHT_DAY = "Light Day"

    val ALL_THEMES = listOf(
        THEME_MIDNIGHT_GOLD,
        THEME_OCEAN_BLUE,
        THEME_EMERALD_GREEN,
        THEME_ROYAL_PURPLE,
        THEME_SUNSET_CORAL,
        THEME_GRAPHITE_CYAN,
        THEME_ROSE_QUARTZ,
        THEME_ARCTIC_MINT,
        THEME_LIGHT_DAY
    )

    val APPEARANCE_MODES = listOf(
        "System Default",
        "Light Mode",
        "Dark Mode"
    )

    fun applyNightMode(modeIndex: Int) {
        when (modeIndex) {
            1 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            2 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    fun applyTheme(activity: Activity) {
        val settings = SettingsManager.getInstance(activity)
        applyNightMode(settings.getAppearanceMode())
        val styleRes = when (settings.getColorTheme()) {
            THEME_OCEAN_BLUE -> R.style.Theme_SRSmartReplyAI_OceanBlue
            THEME_EMERALD_GREEN -> R.style.Theme_SRSmartReplyAI_EmeraldGreen
            THEME_ROYAL_PURPLE -> R.style.Theme_SRSmartReplyAI_RoyalPurple
            THEME_SUNSET_CORAL -> R.style.Theme_SRSmartReplyAI_SunsetCoral
            THEME_GRAPHITE_CYAN -> R.style.Theme_SRSmartReplyAI_GraphiteCyan
            THEME_ROSE_QUARTZ -> R.style.Theme_SRSmartReplyAI_RoseQuartz
            THEME_ARCTIC_MINT -> R.style.Theme_SRSmartReplyAI_ArcticMint
            THEME_LIGHT_DAY -> R.style.Theme_SRSmartReplyAI_LightDay
            else -> R.style.Theme_SRSmartReplyAI_MidnightGold
        }
        activity.setTheme(styleRes)
    }
}
