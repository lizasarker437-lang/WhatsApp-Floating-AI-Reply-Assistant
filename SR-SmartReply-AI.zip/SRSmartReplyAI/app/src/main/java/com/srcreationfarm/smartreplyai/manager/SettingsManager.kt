package com.srcreationfarm.smartreplyai.manager

import android.content.Context
import android.content.SharedPreferences

class SettingsManager private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "sr_smartreply_prefs"

        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_FULL_AUTO_REPLY = "full_auto_reply_enabled"
        private const val KEY_AUTO_REPLY_DELAY_MS = "auto_reply_delay_ms"
        private const val KEY_FLOATING_ENABLED = "floating_enabled"
        private const val KEY_AUTO_SEND = "auto_send_enabled"
        private const val KEY_WHATSAPP_BUSINESS = "whatsapp_business_enabled"
        private const val KEY_LANGUAGE_PREF = "language_preference"
        private const val KEY_CONTEXT_DEPTH = "context_scan_depth"
        private const val KEY_APPEARANCE_MODE = "appearance_mode"
        private const val KEY_COLOR_THEME = "color_theme"
        private const val KEY_SAVE_HISTORY = "save_history_enabled"
        private const val KEY_HAPTIC_FEEDBACK = "haptic_feedback_enabled"
        private const val KEY_ORB_X = "floating_orb_x"
        private const val KEY_ORB_Y = "floating_orb_y"
        private const val KEY_RECENT_SENT_REPLIES = "recent_sent_replies_log"

        @Volatile
        private var instance: SettingsManager? = null

        fun getInstance(context: Context): SettingsManager {
            return instance ?: synchronized(this) {
                instance ?: SettingsManager(context).also { instance = it }
            }
        }
    }

    fun getApiKey(): String = prefs.getString(KEY_API_KEY, "") ?: ""
    fun setApiKey(key: String) = prefs.edit().putString(KEY_API_KEY, key.trim()).apply()

    fun isFullAutoReplyEnabled(): Boolean = prefs.getBoolean(KEY_FULL_AUTO_REPLY, true)
    fun setFullAutoReplyEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_FULL_AUTO_REPLY, enabled).apply()

    // Ultra-fast 120ms default detection delay
    fun getAutoReplyDelayMs(): Long = prefs.getLong(KEY_AUTO_REPLY_DELAY_MS, 120L)
    fun setAutoReplyDelayMs(delayMs: Long) = prefs.edit().putLong(KEY_AUTO_REPLY_DELAY_MS, delayMs.coerceIn(60L, 3000L)).apply()

    fun isFloatingEnabled(): Boolean = prefs.getBoolean(KEY_FLOATING_ENABLED, true)
    fun setFloatingEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_FLOATING_ENABLED, enabled).apply()

    fun isAutoSendEnabled(): Boolean = prefs.getBoolean(KEY_AUTO_SEND, true)
    fun setAutoSendEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_AUTO_SEND, enabled).apply()

    fun isWhatsAppBusinessEnabled(): Boolean = prefs.getBoolean(KEY_WHATSAPP_BUSINESS, true)
    fun setWhatsAppBusinessEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_WHATSAPP_BUSINESS, enabled).apply()

    fun getLanguagePreference(): String = prefs.getString(KEY_LANGUAGE_PREF, "Auto (BN + EN + Banglish)") ?: "Auto (BN + EN + Banglish)"
    fun setLanguagePreference(lang: String) = prefs.edit().putString(KEY_LANGUAGE_PREF, lang).apply()

    fun getContextDepth(): Int = prefs.getInt(KEY_CONTEXT_DEPTH, 5)
    fun setContextDepth(depth: Int) = prefs.edit().putInt(KEY_CONTEXT_DEPTH, depth.coerceIn(4, 10)).apply()

    fun getAppearanceMode(): Int = prefs.getInt(KEY_APPEARANCE_MODE, 0)
    fun setAppearanceMode(mode: Int) = prefs.edit().putInt(KEY_APPEARANCE_MODE, mode).apply()

    fun getColorTheme(): String = prefs.getString(KEY_COLOR_THEME, ThemeManager.THEME_MIDNIGHT_GOLD) ?: ThemeManager.THEME_MIDNIGHT_GOLD
    fun setColorTheme(theme: String) = prefs.edit().putString(KEY_COLOR_THEME, theme).apply()

    fun isSaveHistoryEnabled(): Boolean = prefs.getBoolean(KEY_SAVE_HISTORY, true)
    fun setSaveHistoryEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_SAVE_HISTORY, enabled).apply()

    fun isHapticEnabled(): Boolean = prefs.getBoolean(KEY_HAPTIC_FEEDBACK, true)
    fun setHapticEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_HAPTIC_FEEDBACK, enabled).apply()

    fun getOrbX(): Int = prefs.getInt(KEY_ORB_X, 24)
    fun getOrbY(): Int = prefs.getInt(KEY_ORB_Y, 260)
    fun saveOrbPosition(x: Int, y: Int) {
        prefs.edit().putInt(KEY_ORB_X, x).putInt(KEY_ORB_Y, y).apply()
    }

    fun getRecentSentReplies(): Set<String> {
        val raw = prefs.getString(KEY_RECENT_SENT_REPLIES, "") ?: ""
        if (raw.isBlank()) return emptySet()
        return raw.split("|||").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    }

    fun addRecentSentReply(reply: String) {
        val clean = reply.trim()
        if (clean.isEmpty()) return
        val current = prefs.getString(KEY_RECENT_SENT_REPLIES, "") ?: ""
        val list = current.split("|||").map { it.trim() }.filter { it.isNotEmpty() && it != clean }.toMutableList()
        list.add(0, clean)
        val capped = list.take(40).joinToString("|||")
        prefs.edit().putString(KEY_RECENT_SENT_REPLIES, capped).apply()
    }

    fun resetAll() {
        prefs.edit().clear().apply()
    }
}
