package com.srcreationfarm.smartreplyai.manager

import android.content.Context
import android.content.SharedPreferences

class SettingsManager private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "sr_smartreply_prefs"

        const val TONE_FRIENDLY = "friendly"
        const val TONE_POLITE = "polite"
        const val TONE_PROFESSIONAL = "professional"

        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_SELECTED_TONE = "selected_reply_tone"
        private const val KEY_FULL_AUTO_REPLY = "full_auto_reply_enabled"
        private const val KEY_AUTO_REPLY_DELAY_MS = "auto_reply_delay_ms"
        private const val KEY_FLOATING_ENABLED = "floating_enabled"
        private const val KEY_AUTO_SEND = "auto_send_enabled"
        private const val KEY_WHATSAPP_BUSINESS = "whatsapp_business_enabled"
        private const val KEY_LANGUAGE_PREF = "language_preference"
        private const val KEY_CONTEXT_DEPTH = "context_scan_depth"
        private const val KEY_APPEARANCE_MODE = "appearance_mode"
        private const val KEY_COLOR_THEME = "color_theme"
        private const val KEY_SAVE_HISTORY = "save_history_enabled"
        private const val KEY_HAPTIC_FEEDBACK = "haptic_feedback_enabled"
        private const val KEY_ORB_X = "floating_orb_x"
        private const val KEY_ORB_Y = "floating_orb_y"

        @Volatile
        private var instance: SettingsManager? = null

        fun getInstance(context: Context): SettingsManager {
            return instance ?: synchronized(this) {
                instance ?: SettingsManager(context).also { instance = it }
            }
        }
    }

    fun getApiKey(): String = prefs.getString(KEY_API_KEY, "") ?: ""
    fun setApiKey(key: String) = prefs.edit().putString(KEY_API_KEY, key.trim()).apply()

    fun getSelectedTone(): String = prefs.getString(KEY_SELECTED_TONE, TONE_FRIENDLY) ?: TONE_FRIENDLY
    fun setSelectedTone(tone: String) = prefs.edit().putString(KEY_SELECTED_TONE, tone).apply()

    fun getSelectedToneLabel(): String {
        return when (getSelectedTone()) {
            TONE_POLITE -> "Polite • ভদ্র ও আন্তরিক"
            TONE_PROFESSIONAL -> "Professional • পেশাদার"
            else -> "Friendly • বন্ধুত্বপূর্ণ"
        }
    }

    fun getSelectedToneShortLabel(): String {
        return when (getSelectedTone()) {
            TONE_POLITE -> "Polite"
            TONE_PROFESSIONAL -> "Pro"
            else -> "Friendly"
        }
    }

    fun isFullAutoReplyEnabled(): Boolean = prefs.getBoolean(KEY_FULL_AUTO_REPLY, true)
    fun setFullAutoReplyEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_FULL_AUTO_REPLY, enabled).apply()

    // Ultra-fast 150ms default detection delay
    fun getAutoReplyDelayMs(): Long = prefs.getLong(KEY_AUTO_REPLY_DELAY_MS, 150L)
    fun setAutoReplyDelayMs(delayMs: Long) = prefs.edit().putLong(KEY_AUTO_REPLY_DELAY_MS, delayMs.coerceIn(80L, 3000L)).apply()

    fun isFloatingEnabled(): Boolean = prefs.getBoolean(KEY_FLOATING_ENABLED, true)
    fun setFloatingEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_FLOATING_ENABLED, enabled).apply()

    fun isAutoSendEnabled(): Boolean = prefs.getBoolean(KEY_AUTO_SEND, true)
    fun setAutoSendEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_AUTO_SEND, enabled).apply()

    fun isWhatsAppBusinessEnabled(): Boolean = prefs.getBoolean(KEY_WHATSAPP_BUSINESS, true)
    fun setWhatsAppBusinessEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_WHATSAPP_BUSINESS, enabled).apply()

    fun getLanguagePreference(): String = prefs.getString(KEY_LANGUAGE_PREF, "Auto (BN + EN + Banglish)") ?: "Auto (BN + EN + Banglish)"
    fun setLanguagePreference(lang: String) = prefs.edit().putString(KEY_LANGUAGE_PREF, lang).apply()

    // Scans last 5 messages by default to analyze context
    fun getContextDepth(): Int = prefs.getInt(KEY_CONTEXT_DEPTH, 5)
    fun setContextDepth(depth: Int) = prefs.edit().putInt(KEY_CONTEXT_DEPTH, depth.coerceIn(4, 10)).apply()

    fun getAppearanceMode(): Int = prefs.getInt(KEY_APPEARANCE_MODE, 0) // 0=System, 1=Light, 2=Dark
    fun setAppearanceMode(mode: Int) = prefs.edit().putInt(KEY_APPEARANCE_MODE, mode).apply()

    fun getColorTheme(): String = prefs.getString(KEY_COLOR_THEME, ThemeManager.THEME_MIDNIGHT_GOLD) ?: ThemeManager.THEME_MIDNIGHT_GOLD
    fun setColorTheme(theme: String) = prefs.edit().putString(KEY_COLOR_THEME, theme).apply()

    fun isSaveHistoryEnabled(): Boolean = prefs.getBoolean(KEY_SAVE_HISTORY, true)
    fun setSaveHistoryEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_SAVE_HISTORY, enabled).apply()

    fun isHapticEnabled(): Boolean = prefs.getBoolean(KEY_HAPTIC_FEEDBACK, true)
    fun setHapticEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_HAPTIC_FEEDBACK, enabled).apply()

    fun getOrbX(): Int = prefs.getInt(KEY_ORB_X, 24)
    fun getOrbY(): Int = prefs.getInt(KEY_ORB_Y, 260)
    fun saveOrbPosition(x: Int, y: Int) {
        prefs.edit().putInt(KEY_ORB_X, x).putInt(KEY_ORB_Y, y).apply()
    }

    fun resetAll() {
        prefs.edit().clear().apply()
    }
}
