package com.srcreationfarm.smartreplyai.manager

import android.content.Context
import android.content.SharedPreferences

class SettingsManager private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "sr_smartreply_prefs"
        const val DEFAULT_USER_API_KEY = "AQ.Ab8RN6IE1-Ywgxaad7CdEaF1JmVwzb4f35WO8eeC9-llKqx-OQ"

        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_GEMINI_CONNECTED = "gemini_connected_state"
        private const val KEY_CONNECTED_MODEL = "gemini_connected_model"
        private const val KEY_LAST_CONN_ERROR = "gemini_last_conn_error"
        private const val KEY_LAST_LATENCY_MS = "gemini_last_latency_ms"

        private const val KEY_TARGET_FILTER_ENABLED = "target_contact_filter_enabled"
        private const val KEY_TARGET_CONTACT_QUERY = "target_contact_name_or_number"

        private const val KEY_AUTO_UNLOCK_ENABLED = "auto_unlock_and_open_enabled"
        private const val KEY_PHONE_LOCK_PIN = "phone_lock_pin_code"
        private const val KEY_PIN_PRESS_ENTER = "pin_press_enter_enabled"

        private const val KEY_FULL_AUTO_REPLY = "full_auto_reply_enabled"
        private const val KEY_AUTO_REPLY_DELAY_MS = "auto_reply_delay_ms"
        private const val KEY_FLOATING_ENABLED = "floating_enabled"
        private const val KEY_AUTO_SEND = "auto_send_enabled"
        private const val KEY_WHATSAPP_BUSINESS = "whatsapp_business_enabled"
        private const val KEY_LANGUAGE_PREF = "language_preference"
        private const val KEY_CONTEXT_DEPTH = "context_scan_depth"
        private const val KEY_APPEARANCE_MODE = "appearance_mode"
        private const val KEY_COLOR_THEME = "color_theme"
        private const val KEY_SAVE_HISTORY = "save_history_enabled"
        private const val KEY_HAPTIC_FEEDBACK = "haptic_feedback_enabled"
        private const val KEY_ORB_X = "floating_orb_x"
        private const val KEY_ORB_Y = "floating_orb_y"
        private const val KEY_RECENT_SENT_REPLIES = "recent_sent_replies_log"

        @Volatile
        private var instance: SettingsManager? = null

        fun getInstance(context: Context): SettingsManager {
            return instance ?: synchronized(this) {
                instance ?: SettingsManager(context).also { instance = it }
            }
        }

        fun sanitizeApiKey(rawKey: String): String {
            return rawKey
                .replace("\n", "")
                .replace("\r", "")
                .replace(" ", "")
                .replace("\"", "")
                .replace("'", "")
                .trim()
        }

        fun normalizePhoneDigits(input: String): String {
            val digitsOnly = input.filter { it.isDigit() }
            return if (digitsOnly.startsWith("880") && digitsOnly.length >= 13) {
                digitsOnly.removePrefix("88")
            } else {
                digitsOnly
            }
        }

        fun matchesTargetContact(detectedChatTitle: String, targetFilterRaw: String): Boolean {
            val filterTrimmed = targetFilterRaw.trim()
            if (filterTrimmed.isEmpty()) return true

            val chatTitleClean = detectedChatTitle.trim()
            if (chatTitleClean.isEmpty() || chatTitleClean == "ActiveChat") return false

            val chatLower = chatTitleClean.lowercase()
            val chatDigits = normalizePhoneDigits(chatTitleClean)

            val targets = filterTrimmed.split(",", ";", "\n").map { it.trim() }.filter { it.isNotEmpty() }
            if (targets.isEmpty()) return true

            for (target in targets) {
                val targetLower = target.lowercase()
                val targetDigits = normalizePhoneDigits(target)

                if (targetDigits.length >= 6 && chatDigits.length >= 6) {
                    if (chatDigits.contains(targetDigits) || targetDigits.contains(chatDigits)) {
                        return true
                    }
                }

                if (chatLower == targetLower || chatLower.contains(targetLower) || targetLower.contains(chatLower)) {
                    return true
                }
            }
            return false
        }
    }

    fun getApiKey(): String {
        val stored = sanitizeApiKey(prefs.getString(KEY_API_KEY, "") ?: "")
        if (stored.isNotEmpty()) return stored
        prefs.edit()
            .putString(KEY_API_KEY, DEFAULT_USER_API_KEY)
            .putBoolean(KEY_GEMINI_CONNECTED, true)
            .putString(KEY_CONNECTED_MODEL, "gemini-2.5-flash")
            .putString(KEY_LAST_CONN_ERROR, "")
            .apply()
        return DEFAULT_USER_API_KEY
    }

    fun setApiKey(key: String) {
        val clean = sanitizeApiKey(key)
        val editor = prefs.edit().putString(KEY_API_KEY, clean)
        if (clean.length >= 10) {
            editor.putBoolean(KEY_GEMINI_CONNECTED, true)
            editor.putString(KEY_LAST_CONN_ERROR, "")
            if (getConnectedModel().isBlank()) {
                editor.putString(KEY_CONNECTED_MODEL, "gemini-2.5-flash")
            }
        } else {
            editor.putBoolean(KEY_GEMINI_CONNECTED, false)
            editor.putString(KEY_LAST_CONN_ERROR, "⚠️ Gemini API Key নেই")
        }
        editor.apply()
    }

    // Auto PIN Unlock & WhatsApp Open Settings
    fun isAutoUnlockAndOpenEnabled(): Boolean = prefs.getBoolean(KEY_AUTO_UNLOCK_ENABLED, true)
    fun setAutoUnlockAndOpenEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_AUTO_UNLOCK_ENABLED, enabled).apply()

    fun getPhoneLockPin(): String = prefs.getString(KEY_PHONE_LOCK_PIN, "")?.trim() ?: ""
    fun setPhoneLockPin(pin: String) {
        prefs.edit().putString(KEY_PHONE_LOCK_PIN, pin.trim()).apply()
    }

    fun isPinPressEnterEnabled(): Boolean = prefs.getBoolean(KEY_PIN_PRESS_ENTER, true)
    fun setPinPressEnterEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_PIN_PRESS_ENTER, enabled).apply()

    // Target Contact / Phone Number Filter Settings
    fun isTargetFilterEnabled(): Boolean = prefs.getBoolean(KEY_TARGET_FILTER_ENABLED, false)
    fun setTargetFilterEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_TARGET_FILTER_ENABLED, enabled).apply()

    fun getTargetContactQuery(): String = prefs.getString(KEY_TARGET_CONTACT_QUERY, "")?.trim() ?: ""
    fun setTargetContactQuery(query: String) {
        val clean = query.trim()
        prefs.edit()
            .putString(KEY_TARGET_CONTACT_QUERY, clean)
            .putBoolean(KEY_TARGET_FILTER_ENABLED, clean.isNotEmpty())
            .apply()
    }

    fun getFirstTargetContactName(): String {
        val raw = getTargetContactQuery()
        if (raw.isEmpty()) return ""
        return raw.split(",", ";", "\n").firstOrNull()?.trim() ?: ""
    }

    fun isChatAllowedByTargetFilter(detectedChatTitle: String): Boolean {
        if (!isTargetFilterEnabled()) return true
        val query = getTargetContactQuery()
        if (query.isEmpty()) return true
        return matchesTargetContact(detectedChatTitle, query)
    }

    fun isGeminiConnected(): Boolean {
        val key = getApiKey()
        if (key.length < 10) return false
        return prefs.getBoolean(KEY_GEMINI_CONNECTED, true)
    }

    fun setGeminiConnected(connected: Boolean) = prefs.edit().putBoolean(KEY_GEMINI_CONNECTED, connected).apply()

    fun getConnectedModel(): String = prefs.getString(KEY_CONNECTED_MODEL, "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun setConnectedModel(model: String) = prefs.edit().putString(KEY_CONNECTED_MODEL, model).apply()

    fun getLastConnectionError(): String = prefs.getString(KEY_LAST_CONN_ERROR, "") ?: ""
    fun setLastConnectionError(error: String) = prefs.edit().putString(KEY_LAST_CONN_ERROR, error).apply()

    fun getLastLatencyMs(): Long = prefs.getLong(KEY_LAST_LATENCY_MS, 240L)
    fun setLastLatencyMs(ms: Long) = prefs.edit().putLong(KEY_LAST_LATENCY_MS, ms).apply()

    fun recordConnectionSuccess(modelName: String, latencyMs: Long) {
        prefs.edit()
            .putBoolean(KEY_GEMINI_CONNECTED, true)
            .putString(KEY_CONNECTED_MODEL, modelName.ifBlank { "gemini-2.5-flash" })
            .putString(KEY_LAST_CONN_ERROR, "")
            .putLong(KEY_LAST_LATENCY_MS, if (latencyMs > 0) latencyMs else 220L)
            .apply()
    }

    fun recordConnectionFailure(errorLabel: String) {
        prefs.edit()
            .putBoolean(KEY_GEMINI_CONNECTED, false)
            .putString(KEY_LAST_CONN_ERROR, errorLabel)
            .apply()
    }

    fun isFullAutoReplyEnabled(): Boolean = prefs.getBoolean(KEY_FULL_AUTO_REPLY, true)
    fun setFullAutoReplyEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_FULL_AUTO_REPLY, enabled).apply()

    fun getAutoReplyDelayMs(): Long = prefs.getLong(KEY_AUTO_REPLY_DELAY_MS, 60L)
    fun setAutoReplyDelayMs(delayMs: Long) = prefs.edit().putLong(KEY_AUTO_REPLY_DELAY_MS, delayMs.coerceIn(40L, 3000L)).apply()

    fun isFloatingEnabled(): Boolean = prefs.getBoolean(KEY_FLOATING_ENABLED, true)
    fun setFloatingEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_FLOATING_ENABLED, enabled).apply()

    fun isAutoSendEnabled(): Boolean = prefs.getBoolean(KEY_AUTO_SEND, true)
    fun setAutoSendEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_AUTO_SEND, enabled).apply()

    fun isWhatsAppBusinessEnabled(): Boolean = prefs.getBoolean(KEY_WHATSAPP_BUSINESS, true)
    fun setWhatsAppBusinessEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_WHATSAPP_BUSINESS, enabled).apply()

    fun getLanguagePreference(): String = prefs.getString(KEY_LANGUAGE_PREF, "Auto (BN + EN + Banglish)") ?: "Auto (BN + EN + Banglish)"
    fun setLanguagePreference(lang: String) = prefs.edit().putString(KEY_LANGUAGE_PREF, lang).apply()

    fun getContextDepth(): Int = prefs.getInt(KEY_CONTEXT_DEPTH, 5)
    fun setContextDepth(depth: Int) = prefs.edit().putInt(KEY_CONTEXT_DEPTH, depth.coerceIn(4, 10)).apply()

    fun getAppearanceMode(): Int = prefs.getInt(KEY_APPEARANCE_MODE, 0)
    fun setAppearanceMode(mode: Int) = prefs.edit().putInt(KEY_APPEARANCE_MODE, mode).apply()

    fun getColorTheme(): String = prefs.getString(KEY_COLOR_THEME, ThemeManager.THEME_MIDNIGHT_GOLD) ?: ThemeManager.THEME_MIDNIGHT_GOLD
    fun setColorTheme(theme: String) = prefs.edit().putString(KEY_COLOR_THEME, theme).apply()

    fun isSaveHistoryEnabled(): Boolean = prefs.getBoolean(KEY_SAVE_HISTORY, true)
    fun setSaveHistoryEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_SAVE_HISTORY, enabled).apply()

    fun isHapticEnabled(): Boolean = prefs.getBoolean(KEY_HAPTIC_FEEDBACK, true)
    fun setHapticEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_HAPTIC_FEEDBACK, enabled).apply()

    fun getOrbX(): Int = prefs.getInt(KEY_ORB_X, 24)
    fun getOrbY(): Int = prefs.getInt(KEY_ORB_Y, 260)
    fun saveOrbPosition(x: Int, y: Int) {
        prefs.edit().putInt(KEY_ORB_X, x).putInt(KEY_ORB_Y, y).apply()
    }

    fun getRecentSentReplies(): Set<String> {
        val raw = prefs.getString(KEY_RECENT_SENT_REPLIES, "") ?: ""
        if (raw.isBlank()) return emptySet()
        return raw.split("|||").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    }

    fun addRecentSentReply(reply: String) {
        val clean = reply.trim()
        if (clean.isEmpty()) return
        val current = prefs.getString(KEY_RECENT_SENT_REPLIES, "") ?: ""
        val list = current.split("|||").map { it.trim() }.filter { it.isNotEmpty() && it != clean }.toMutableList()
        list.add(0, clean)
        val capped = list.take(18).joinToString("|||")
        prefs.edit().putString(KEY_RECENT_SENT_REPLIES, capped).apply()
    }

    fun resetAll() {
        prefs.edit().clear().apply()
    }
}
