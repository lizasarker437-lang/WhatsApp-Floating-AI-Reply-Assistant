package com.srcreationfarm.smartreplyai.model

data class ReplyOptions(
    val friendly: String,
    val polite: String,
    val professional: String,
    val detectedLanguage: String = "Auto",
    val isOfflineFallback: Boolean = false
) {
    fun getReplyByTone(toneKey: String): String {
        return when (toneKey.lowercase()) {
            "polite" -> polite
            "professional" -> professional
            else -> friendly
        }
    }
}
