package com.srcreationfarm.smartreplyai.model

data class ReplyOptions(
    val reply: String,
    val detectedContext: String = "Gemini AI",
    val isOfflineFallback: Boolean = false,
    val isSuccess: Boolean = true,
    val errorMessage: String = "",
    val detailedDiagnostics: String = "",
    val modelUsed: String = "",
    val latencyMs: Long = 0L
)
