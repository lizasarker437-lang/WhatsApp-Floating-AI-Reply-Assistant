package com.srcreationfarm.smartreplyai.model

data class ReplyOptions(
    val reply: String,
    val detectedContext: String = "Auto-Adaptive",
    val isOfflineFallback: Boolean = false
)
