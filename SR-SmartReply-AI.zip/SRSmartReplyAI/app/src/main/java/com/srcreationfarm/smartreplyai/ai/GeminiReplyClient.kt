package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class GeminiReplyClient {

    private val candidateModels = listOf(
        "gemini-2.5-flash",
        "gemini-2.0-flash"
    )

    /**
     * Ultra-Fast Single Reply generator for Auto-Reply mode:
     * Analyzes the last 4-5 messages for context, and generates ONLY 1 human-like reply
     * specifically targeting the very last message in the user's selected tone.
     */
    suspend fun generateFastSingleReply(
        apiKey: String,
        messages: List<ChatMessage>,
        selectedTone: String,
        languagePreference: String
    ): String = withContext(Dispatchers.IO) {
        val windowMessages = messages.takeLast(5)
        if (apiKey.isBlank() || windowMessages.isEmpty()) {
            return@withContext ReplyJsonParser
                .buildSmartFallbackReplies(windowMessages)
                .getReplyByTone(selectedTone)
        }

        val prompt = buildFastSingleReplyPrompt(windowMessages, selectedTone, languagePreference)

        for (modelName in candidateModels) {
            try {
                val rawResponse = executePostRequest(
                    apiKey = apiKey,
                    modelName = modelName,
                    prompt = prompt,
                    maxOutputTokens = 110,
                    connectTimeoutMs = 4500,
                    readTimeoutMs = 5500
                )
                if (!rawResponse.isNullOrBlank()) {
                    val parsed = ReplyJsonParser.parseFastSingleReply(rawResponse, selectedTone)
                    if (parsed.isNotBlank()) {
                        return@withContext parsed
                    }
                }
            } catch (_: Exception) {
                // Immediately try fallback model or local context engine
            }
        }

        ReplyJsonParser.buildSmartFallbackReplies(windowMessages).getReplyByTone(selectedTone)
    }

    /**
     * Full 3-option generator for manual preview panel (long-press on floating button).
     */
    suspend fun generateReplies(
        apiKey: String,
        messages: List<ChatMessage>,
        languagePreference: String
    ): ReplyOptions = withContext(Dispatchers.IO) {
        val windowMessages = messages.takeLast(5)
        if (apiKey.isBlank() || windowMessages.isEmpty()) {
            return@withContext ReplyJsonParser.buildSmartFallbackReplies(windowMessages)
        }

        val conversationText = windowMessages.mapIndexed { idx, msg ->
            "[#${idx + 1}] ${msg.sender}: ${msg.text}"
        }.joinToString("\n")
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val previousOwnReplies = windowMessages.filter { it.sender == "Me" }.map { it.text }
        val prompt = buildFullThreeOptionsPrompt(conversationText, lastIncoming, previousOwnReplies, languagePreference)

        for (modelName in candidateModels) {
            try {
                val rawResponse = executePostRequest(
                    apiKey = apiKey,
                    modelName = modelName,
                    prompt = prompt,
                    maxOutputTokens = 320,
                    connectTimeoutMs = 6000,
                    readTimeoutMs = 7500
                )
                if (!rawResponse.isNullOrBlank()) {
                    return@withContext ReplyJsonParser.parseGeminiResponse(rawResponse)
                }
            } catch (_: Exception) {
            }
        }

        ReplyJsonParser.buildSmartFallbackReplies(windowMessages)
    }

    private fun executePostRequest(
        apiKey: String,
        modelName: String,
        prompt: String,
        maxOutputTokens: Int,
        connectTimeoutMs: Int,
        readTimeoutMs: Int
    ): String? {
        val endpoint =
            "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val url = URL(endpoint)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
            doOutput = true
        }

        val payload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.6)
                put("maxOutputTokens", maxOutputTokens)
                put("responseMimeType", "application/json")
            })
        }

        OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
            writer.write(payload.toString())
            writer.flush()
        }

        val responseCode = connection.responseCode
        val stream = if (responseCode in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream
        }

        val responseBody = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use {
            it.readText()
        }
        connection.disconnect()

        if (responseCode !in 200..299) {
            return null
        }

        val root = JSONObject(responseBody)
        return root
            .getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")
    }

    private fun buildFastSingleReplyPrompt(
        windowMessages: List<ChatMessage>,
        selectedTone: String,
        languagePreference: String
    ): String {
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val historyFormatted = windowMessages.mapIndexed { i, m ->
            val tag = if (i == windowMessages.lastIndex) "[LATEST TARGET MESSAGE]" else "[Context #${i + 1}]"
            "$tag ${m.sender}: ${m.text}"
        }.joinToString("\n")

        val toneInstruction = when (selectedTone.lowercase()) {
            "polite" -> "Polite, respectful, warm, and courteous (ভদ্র ও আন্তরিক)"
            "professional" -> "Clear, composed, polite, and professional (পেশাদার)"
            else -> "Friendly, natural, casual human friend style (বন্ধুত্বপূর্ণ)"
        }

        return listOf(
            "You are a real human chatting on WhatsApp in Bangladesh.",
            "Analyze the last ${windowMessages.size} messages below to understand the ongoing conversation context, topic, and relationship, then write ONE immediate, realistic reply specifically to the [LATEST TARGET MESSAGE]: \"$lastIncoming\".",
            "",
            "STRICT RULES:",
            "1. CONTEXT + FINAL MESSAGE FOCUS: Use the previous messages to understand the ongoing topic (especially if \"$lastIncoming\" is a short follow-up like \"Keno?\", \"Ki diye?\", \"Tumi?\", \"Na\", \"Sotti?\"), and directly answer \"$lastIncoming\".",
            "2. EXACT STYLE & PRONOUN MIRRORING (Preference: $languagePreference):",
            "   - Match the exact script of the conversation (Banglish -> natural Banglish; Bangla script -> natural Bangla; English -> natural English).",
            "   - Mirror the pronoun used in the chat: 'tui/tor/dosto' (তুই), 'tumi/tomar' (তুমি), or 'apni/apnar' (আপনি).",
            "3. TONE: $toneInstruction.",
            "4. SPEED & BREVITY: 1 to 2 short, natural WhatsApp sentences. Never sound robotic.",
            "",
            "Last ${windowMessages.size} Messages in Chat:",
            historyFormatted,
            "",
            "Return ONLY a JSON object with a single key \"reply\":",
            "{\"reply\": \"Your single natural reply to the latest message\"}"
        ).joinToString("\n")
    }

    private fun buildFullThreeOptionsPrompt(
        conversationText: String,
        lastIncoming: String,
        previousOwnReplies: List<String>,
        languagePreference: String
    ): String {
        val avoidList = if (previousOwnReplies.isEmpty()) "None" else previousOwnReplies.joinToString(" | ")
        return listOf(
            "You are a real human chatting on WhatsApp in Bangladesh.",
            "Analyze the last 4-5 messages below to understand the full context, and generate 3 realistic replies specifically addressing the final message: \"$lastIncoming\".",
            "",
            "Rules:",
            "1. Directly answer \"$lastIncoming\" using the context of the preceding messages.",
            "2. Match the exact script (Banglish, Bangla, or English) and pronoun ('tui', 'tumi', or 'apni'). Preference: $languagePreference.",
            "3. Do not repeat previous replies: [$avoidList].",
            "",
            "Last 4-5 Messages:",
            conversationText,
            "",
            "Return ONLY a JSON object:",
            "{\"friendly\": \"Casual friend-style reply\", \"polite\": \"Respectful polite reply\", \"professional\": \"Clear professional reply\"}"
        ).joinToString("\n")
    }
}
