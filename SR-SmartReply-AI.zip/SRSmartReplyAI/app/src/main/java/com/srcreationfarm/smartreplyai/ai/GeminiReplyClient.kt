package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class GeminiReplyClient {

    private val geminiModels = listOf(
        "gemini-2.0-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.5-flash",
        "gemini-1.5-flash"
    )

    /**
     * Ultra-Fast Single Reply generator for Auto-Reply mode:
     * 1. Scans last 4-5 messages & forbidden previous replies.
     * 2. Calls Gemini API (if API key configured).
     * 3. Automatically calls Built-in Free Cloud AI (if no API key or Gemini quota reached) so EVERY message gets a real AI reply!
     * 4. Guarantees uniqueness (never repeats any reply in excludedReplies).
     */
    suspend fun generateFastSingleReply(
        apiKey: String,
        messages: List<ChatMessage>,
        selectedTone: String,
        languagePreference: String,
        excludedReplies: Set<String> = emptySet()
    ): String = withContext(Dispatchers.IO) {
        val windowMessages = messages.takeLast(5)
        if (windowMessages.isEmpty()) return@withContext ""

        val allExcluded = HashSet<String>().apply {
            addAll(excludedReplies)
            windowMessages.filter { it.sender == "Me" }.forEach { add(it.text.trim()) }
        }

        val prompt = buildFastSingleReplyPrompt(windowMessages, selectedTone, languagePreference, allExcluded)

        // 1. Try Google Gemini API if user provided an API Key
        if (apiKey.isNotBlank()) {
            for (modelName in geminiModels) {
                try {
                    val rawResponse = executeGeminiPost(
                        apiKey = apiKey,
                        modelName = modelName,
                        prompt = prompt,
                        maxOutputTokens = 240,
                        connectTimeoutMs = 4000,
                        readTimeoutMs = 5000,
                        useJsonMime = true
                    ) ?: executeGeminiPost(
                        apiKey = apiKey,
                        modelName = modelName,
                        prompt = prompt,
                        maxOutputTokens = 240,
                        connectTimeoutMs = 4000,
                        readTimeoutMs = 5000,
                        useJsonMime = false
                    )
                    if (!rawResponse.isNullOrBlank()) {
                        val parsed = ReplyJsonParser.parseFastSingleReply(rawResponse, selectedTone)
                        if (parsed.isNotBlank() && !isDuplicateReply(parsed, allExcluded)) {
                            return@withContext parsed
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }

        // 2. Built-in Free Cloud AI (Works with ZERO API Key!)
        val cloudAiReply = callBuiltInFreeCloudAiSingle(windowMessages, selectedTone, languagePreference, allExcluded)
        if (!cloudAiReply.isNullOrBlank() && !isDuplicateReply(cloudAiReply, allExcluded)) {
            return@withContext cloudAiReply
        }

        // 3. Offline Context Engine with strict non-repeating guarantee
        ReplyJsonParser
            .buildSmartFallbackReplies(windowMessages, allExcluded)
            .getReplyByTone(selectedTone)
    }

    /**
     * Full 3-option generator for manual preview panel (long-press on floating button).
     */
    suspend fun generateReplies(
        apiKey: String,
        messages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String> = emptySet()
    ): ReplyOptions = withContext(Dispatchers.IO) {
        val windowMessages = messages.takeLast(5)
        if (windowMessages.isEmpty()) {
            return@withContext ReplyJsonParser.buildSmartFallbackReplies(windowMessages, excludedReplies)
        }

        val allExcluded = HashSet<String>().apply {
            addAll(excludedReplies)
            windowMessages.filter { it.sender == "Me" }.forEach { add(it.text.trim()) }
        }

        val conversationText = windowMessages.mapIndexed { idx, msg ->
            "[#${idx + 1}] ${msg.sender}: ${msg.text}"
        }.joinToString("\n")
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val prompt = buildFullThreeOptionsPrompt(conversationText, lastIncoming, allExcluded.take(12), languagePreference)

        if (apiKey.isNotBlank()) {
            for (modelName in geminiModels) {
                try {
                    val rawResponse = executeGeminiPost(
                        apiKey = apiKey,
                        modelName = modelName,
                        prompt = prompt,
                        maxOutputTokens = 380,
                        connectTimeoutMs = 5000,
                        readTimeoutMs = 6500,
                        useJsonMime = true
                    )
                    if (!rawResponse.isNullOrBlank()) {
                        return@withContext ReplyJsonParser.parseGeminiResponse(rawResponse)
                    }
                } catch (_: Exception) {
                }
            }
        }

        val cloudThree = callBuiltInFreeCloudAiThreeOptions(prompt)
        if (cloudThree != null) {
            return@withContext cloudThree
        }

        ReplyJsonParser.buildSmartFallbackReplies(windowMessages, allExcluded)
    }

    private fun isDuplicateReply(candidate: String, excluded: Set<String>): Boolean {
        val normCandidate = candidate.trim().lowercase()
        return excluded.any { it.trim().lowercase() == normCandidate }
    }

    private fun executeGeminiPost(
        apiKey: String,
        modelName: String,
        prompt: String,
        maxOutputTokens: Int,
        connectTimeoutMs: Int,
        readTimeoutMs: Int,
        useJsonMime: Boolean
    ): String? {
        val endpoint =
            "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val url = URL(endpoint)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
            doOutput = true
        }

        val genConfig = JSONObject().apply {
            put("temperature", 0.75)
            put("maxOutputTokens", maxOutputTokens)
            if (useJsonMime) {
                put("responseMimeType", "application/json")
            }
            if (modelName.startsWith("gemini-2.5")) {
                put("thinkingConfig", JSONObject().apply {
                    put("thinkingBudget", 0)
                })
            }
        }

        val payload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("generationConfig", genConfig)
        }

        OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
            writer.write(payload.toString())
            writer.flush()
        }

        val responseCode = connection.responseCode
        val stream = if (responseCode in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream
        }

        val responseBody = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use {
            it.readText()
        }
        connection.disconnect()

        if (responseCode !in 200..299) {
            return null
        }

        val root = JSONObject(responseBody)
        val parts = root
            .getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")

        for (i in 0 until parts.length()) {
            val partObj = parts.getJSONObject(i)
            if (!partObj.optBoolean("thought", false) && partObj.has("text")) {
                val txt = partObj.getString("text").trim()
                if (txt.isNotEmpty()) return txt
            }
        }
        return null
    }

    private fun callBuiltInFreeCloudAiSingle(
        windowMessages: List<ChatMessage>,
        selectedTone: String,
        languagePreference: String,
        excludedReplies: Set<String>
    ): String? {
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val historyFormatted = windowMessages.mapIndexed { i, m ->
            val tag = if (i == windowMessages.lastIndex) "[LATEST MESSAGE]" else "[#${i + 1}]"
            "$tag ${m.sender}: ${m.text}"
        }.joinToString("\n")
        val avoidStr = excludedReplies.take(10).joinToString(" | ")

        val systemMsg = listOf(
            "You are a real Bangladeshi human chatting naturally on WhatsApp.",
            "Read the last ${windowMessages.size} messages and write ONLY 1 short, realistic, human reply to the [LATEST MESSAGE]: \"$lastIncoming\".",
            "Rules:",
            "1. Directly answer or respond to the exact meaning of \"$lastIncoming\" based on the conversation context.",
            "2. Match the exact script and language of the sender (if Banglish like 'Ki koro'/'Aito aci'/'Ki sob bolteco', reply in natural Bangladeshi Banglish; if Bangla script, reply in Bangla; if English, reply in English). Preference: $languagePreference.",
            "3. Match the sender's pronoun ('tui/tor', 'tumi/tomar', or 'apni/apnar'). Tone: $selectedTone.",
            "4. NEVER repeat any of these previous replies: [$avoidStr].",
            "5. Output ONLY the raw reply text (1 short sentence, no quotes, no JSON, no explanations)."
        ).joinToString("\n")

        // Method A: OpenAI-compatible fast POST endpoint
        try {
            val url = URL("https://text.pollinations.ai/openai")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                connectTimeout = 4200
                readTimeout = 5200
                doOutput = true
            }

            val body = JSONObject().apply {
                put("model", "openai")
                put("temperature", 0.8)
                put("seed", (System.currentTimeMillis() % 100000).toInt())
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "system")
                        put("content", systemMsg)
                    })
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", "Chat History:\n$historyFormatted\n\nWrite the single reply to \"$lastIncoming\":")
                    })
                })
            }

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body.toString())
                writer.flush()
            }

            if (conn.responseCode in 200..299) {
                val resp = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
                conn.disconnect()
                val root = JSONObject(resp)
                val content = root
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim()
                val cleaned = ReplyJsonParser.parseFastSingleReply(content, selectedTone)
                if (cleaned.isNotBlank()) return cleaned
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {
        }

        // Method B: Direct GET Cloud AI fallback
        try {
            val compactPrompt = "$systemMsg\nChat:\n$historyFormatted\nReply:"
            val encoded = URLEncoder.encode(compactPrompt, "UTF-8")
            val seed = (System.currentTimeMillis() % 100000).toInt()
            val url = URL("https://text.pollinations.ai/$encoded?model=openai&seed=$seed")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 5000
            }
            if (conn.responseCode in 200..299) {
                val resp = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
                conn.disconnect()
                val cleaned = ReplyJsonParser.parseFastSingleReply(resp, selectedTone)
                if (cleaned.isNotBlank()) return cleaned
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {
        }

        return null
    }

    private fun callBuiltInFreeCloudAiThreeOptions(prompt: String): ReplyOptions? {
        try {
            val url = URL("https://text.pollinations.ai/openai")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                connectTimeout = 5000
                readTimeout = 6000
                doOutput = true
            }
            val body = JSONObject().apply {
                put("model", "openai")
                put("temperature", 0.75)
                put("seed", (System.currentTimeMillis() % 100000).toInt())
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    })
                })
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body.toString())
                writer.flush()
            }
            if (conn.responseCode in 200..299) {
                val resp = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
                conn.disconnect()
                val content = JSONObject(resp)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                return ReplyJsonParser.parseGeminiResponse(content)
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun buildFastSingleReplyPrompt(
        windowMessages: List<ChatMessage>,
        selectedTone: String,
        languagePreference: String,
        excludedReplies: Set<String>
    ): String {
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val historyFormatted = windowMessages.mapIndexed { i, m ->
            val tag = if (i == windowMessages.lastIndex) "[LATEST TARGET MESSAGE]" else "[Context #${i + 1}]"
            "$tag ${m.sender}: ${m.text}"
        }.joinToString("\n")

        val toneInstruction = when (selectedTone.lowercase()) {
            "polite" -> "Polite, respectful, warm, and courteous (ভদ্র ও আন্তরিক)"
            "professional" -> "Clear, composed, polite, and professional (পেশাদার)"
            else -> "Friendly, natural, casual human friend style (বন্ধুত্বপূর্ণ)"
        }
        val avoidList = if (excludedReplies.isEmpty()) "None" else excludedReplies.take(12).joinToString(" | ")

        return listOf(
            "You are a real human chatting on WhatsApp in Bangladesh.",
            "Analyze the last ${windowMessages.size} messages below to understand the ongoing conversation context, topic, and relationship, then write ONE immediate, realistic, unique reply specifically to the [LATEST TARGET MESSAGE]: \"$lastIncoming\".",
            "",
            "STRICT RULES:",
            "1. DIRECT MEANING & CONTEXT: Answer the exact point, question, or emotion of \"$lastIncoming\" using the context of the preceding messages. Never give vague 'I will confirm later' or 'I will let you know later' replies.",
            "2. EXACT STYLE & PRONOUN MIRRORING (Preference: $languagePreference):",
            "   - Match the exact script of the conversation (Banglish -> natural Banglish; Bangla script -> natural Bangla; English -> natural English).",
            "   - Mirror the pronoun used in the chat: 'tui/tor/dosto' (তুই), 'tumi/tomar' (তুমি), or 'apni/apnar' (আপনি).",
            "3. TONE: $toneInstruction.",
            "4. ZERO REPETITION: NEVER use or repeat any of these previously sent replies: [$avoidList]. Every reply must be 100% fresh and unique.",
            "5. SPEED & BREVITY: 1 to 2 short, natural WhatsApp sentences.",
            "",
            "Last ${windowMessages.size} Messages in Chat:",
            historyFormatted,
            "",
            "Return ONLY a JSON object with a single key \"reply\":",
            "{\"reply\": \"Your single unique natural reply\"}"
        ).joinToString("\n")
    }

    private fun buildFullThreeOptionsPrompt(
        conversationText: String,
        lastIncoming: String,
        previousOwnReplies: List<String>,
        languagePreference: String
    ): String {
        val avoidList = if (previousOwnReplies.isEmpty()) "None" else previousOwnReplies.joinToString(" | ")
        return listOf(
            "You are a real human chatting on WhatsApp in Bangladesh.",
            "Analyze the last 4-5 messages below to understand the full context, and generate 3 realistic, unique replies specifically addressing the final message: \"$lastIncoming\".",
            "",
            "Rules:",
            "1. Directly answer \"$lastIncoming\" using the context of the preceding messages.",
            "2. Match the exact script (Banglish, Bangla, or English) and pronoun ('tui', 'tumi', or 'apni'). Preference: $languagePreference.",
            "3. Do not repeat previous replies: [$avoidList].",
            "",
            "Last 4-5 Messages:",
            conversationText,
            "",
            "Return ONLY a JSON object:",
            "{\"friendly\": \"Casual friend-style reply\", \"polite\": \"Respectful polite reply\", \"professional\": \"Clear professional reply\"}"
        ).joinToString("\n")
    }
}
