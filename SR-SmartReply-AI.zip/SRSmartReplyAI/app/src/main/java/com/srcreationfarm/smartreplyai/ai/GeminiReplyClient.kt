package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

class GeminiReplyClient {

    companion object {
        private const val BROWSER_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
    }

    private val geminiModels = listOf(
        "gemini-2.5-flash",
        "gemini-2.0-flash",
        "gemini-2.5-flash-lite",
        "gemini-1.5-flash",
        "gemini-1.5-flash-latest"
    )

    private data class HttpAttemptResult(
        val text: String? = null,
        val httpCode: Int = 0,
        val errorLabel: String = ""
    )

    /**
     * Strictly uses Google Gemini AI to generate a realistic, message-driven reply.
     * NEVER sends offline canned replies! If Gemini is not connected or fails, returns isSuccess = false
     * along with the exact Bangla error status to display on the floating icon.
     */
    suspend fun generateContextualReply(
        apiKey: String,
        messages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String> = emptySet()
    ): ReplyOptions = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext ReplyOptions(
                reply = "",
                detectedContext = "Disconnected",
                isOfflineFallback = false,
                isSuccess = false,
                errorMessage = "⚠️ Gemini API Key নেই"
            )
        }

        val windowMessages = messages.takeLast(5)
        if (windowMessages.isEmpty()) {
            return@withContext ReplyOptions(
                reply = "",
                detectedContext = "Empty",
                isOfflineFallback = false,
                isSuccess = false,
                errorMessage = "⚠️ কোনো মেসেজ পাওয়া যায়নি"
            )
        }

        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text?.trim()
            ?: windowMessages.last().text.trim()

        val allExcluded = HashSet<String>().apply {
            addAll(excludedReplies)
            windowMessages.filter { it.sender == "Me" }.forEach { add(it.text.trim()) }
        }

        val prompt = buildMessageDrivenPrompt(windowMessages, languagePreference, allExcluded)
        var lastErrorLabel = "⚠️ Gemini সংযোগে সমস্যা"

        for (modelName in geminiModels) {
            // Try structured JSON config first, then plain config if model rejects extra config fields
            val firstAttempt = executeGeminiPost(
                apiKey = cleanKey,
                modelName = modelName,
                prompt = prompt,
                useSimpleConfig = false
            )
            if (!firstAttempt.text.isNullOrBlank()) {
                val parsed = ReplyJsonParser.parseAiReply(firstAttempt.text)
                if (isValidReply(parsed, lastIncoming, allExcluded)) {
                    return@withContext ReplyOptions(
                        reply = parsed,
                        detectedContext = "Gemini AI ($modelName)",
                        isOfflineFallback = false,
                        isSuccess = true,
                        errorMessage = ""
                    )
                }
            } else if (firstAttempt.errorLabel.isNotBlank()) {
                lastErrorLabel = firstAttempt.errorLabel
                // If API key itself is invalid (400/401/403 API_KEY_INVALID), stop trying other models
                if (firstAttempt.httpCode == 401 || firstAttempt.errorLabel.contains("API Key সঠিক নয়")) {
                    break
                }
            }

            val secondAttempt = executeGeminiPost(
                apiKey = cleanKey,
                modelName = modelName,
                prompt = prompt,
                useSimpleConfig = true
            )
            if (!secondAttempt.text.isNullOrBlank()) {
                val parsed = ReplyJsonParser.parseAiReply(secondAttempt.text)
                if (isValidReply(parsed, lastIncoming, allExcluded)) {
                    return@withContext ReplyOptions(
                        reply = parsed,
                        detectedContext = "Gemini AI ($modelName)",
                        isOfflineFallback = false,
                        isSuccess = true,
                        errorMessage = ""
                    )
                }
            } else if (secondAttempt.errorLabel.isNotBlank()) {
                lastErrorLabel = secondAttempt.errorLabel
                if (secondAttempt.httpCode == 401 || secondAttempt.errorLabel.contains("API Key সঠিক নয়")) {
                    break
                }
            }
        }

        ReplyOptions(
            reply = "",
            detectedContext = "Disconnected",
            isOfflineFallback = false,
            isSuccess = false,
            errorMessage = lastErrorLabel
        )
    }

    /**
     * Quick ping to verify whether the configured Gemini API Key & Internet connection are working.
     */
    suspend fun verifyGeminiConnection(apiKey: String): ReplyOptions = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext ReplyOptions(
                reply = "",
                detectedContext = "Disconnected",
                isOfflineFallback = false,
                isSuccess = false,
                errorMessage = "⚠️ Gemini API Key নেই"
            )
        }

        var lastErrorLabel = "⚠️ Gemini সংযোগে সমস্যা"
        for (modelName in geminiModels) {
            val attempt = executeGeminiPost(
                apiKey = cleanKey,
                modelName = modelName,
                prompt = "Reply with OK",
                useSimpleConfig = true
            )
            if (!attempt.text.isNullOrBlank()) {
                return@withContext ReplyOptions(
                    reply = "OK",
                    detectedContext = "Connected ($modelName)",
                    isOfflineFallback = false,
                    isSuccess = true,
                    errorMessage = ""
                )
            }
            if (attempt.errorLabel.isNotBlank()) {
                lastErrorLabel = attempt.errorLabel
                if (attempt.httpCode == 401 || attempt.errorLabel.contains("API Key সঠিক নয়")) {
                    break
                }
            }
        }

        ReplyOptions(
            reply = "",
            detectedContext = "Disconnected",
            isOfflineFallback = false,
            isSuccess = false,
            errorMessage = lastErrorLabel
        )
    }

    private fun isValidReply(
        candidate: String?,
        lastIncoming: String,
        excluded: Set<String>
    ): Boolean {
        if (candidate.isNullOrBlank()) return false
        val trimmed = candidate.trim()
        if (trimmed.length < 2 || trimmed.length > 280) return false

        val lower = trimmed.lowercase()
        val errorSignals = listOf(
            "<!doctype", "<html", "cloudflare", "rate limit", "bad gateway",
            "502 ", "403 ", "429 ", "internal server", "exception"
        )
        if (errorSignals.any { lower.contains(it) }) return false
        if (lower == lastIncoming.trim().lowercase()) return false

        return excluded.none { it.trim().lowercase() == lower }
    }

    private fun executeGeminiPost(
        apiKey: String,
        modelName: String,
        prompt: String,
        useSimpleConfig: Boolean
    ): HttpAttemptResult {
        var connection: HttpURLConnection? = null
        try {
            val endpoint =
                "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
            val url = URL(endpoint)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("User-Agent", BROWSER_USER_AGENT)
                connectTimeout = 7000
                readTimeout = 8000
                doOutput = true
            }

            val genConfig = JSONObject().apply {
                put("temperature", 0.72)
                put("maxOutputTokens", 220)
                if (!useSimpleConfig) {
                    put("responseMimeType", "application/json")
                    if (modelName.startsWith("gemini-2.5")) {
                        put("thinkingConfig", JSONObject().apply {
                            put("thinkingBudget", 0)
                        })
                    }
                }
            }

            val safetyCategories = listOf(
                "HARM_CATEGORY_HARASSMENT",
                "HARM_CATEGORY_HATE_SPEECH",
                "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                "HARM_CATEGORY_DANGEROUS_CONTENT"
            )
            val safetyArray = JSONArray().apply {
                for (cat in safetyCategories) {
                    put(JSONObject().apply {
                        put("category", cat)
                        put("threshold", "BLOCK_NONE")
                    })
                }
            }

            val payload = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
                put("generationConfig", genConfig)
                put("safetySettings", safetyArray)
            }

            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val responseCode = connection.responseCode
            val stream = if (responseCode in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            } ?: run {
                connection.disconnect()
                return HttpAttemptResult(null, responseCode, "⚠️ Gemini সংযোগে সমস্যা ($responseCode)")
            }

            val responseBody = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use {
                it.readText()
            }
            connection.disconnect()

            if (responseCode !in 200..299) {
                val lowerErr = responseBody.lowercase()
                val errMsg = when {
                    responseCode == 400 && (lowerErr.contains("api_key_invalid") || lowerErr.contains("api key not valid")) ->
                        "⚠️ API Key সঠিক নয়"
                    responseCode == 401 || responseCode == 403 ->
                        "⚠️ API Key সঠিক নয়"
                    responseCode == 429 ->
                        "⚠️ Gemini কোটা শেষ (429)"
                    responseCode >= 500 ->
                        "⚠️ Gemini সার্ভার ব্যস্ত"
                    else ->
                        "⚠️ Gemini সংযোগে সমস্যা"
                }
                return HttpAttemptResult(null, responseCode, errMsg)
            }

            val root = JSONObject(responseBody)
            val candidates = root.optJSONArray("candidates")
                ?: return HttpAttemptResult(null, responseCode, "⚠️ Gemini উত্তর দেয়নি")
            if (candidates.length() == 0) {
                return HttpAttemptResult(null, responseCode, "⚠️ Gemini উত্তর দেয়নি")
            }
            val contentObj = candidates.getJSONObject(0).optJSONObject("content")
                ?: return HttpAttemptResult(null, responseCode, "⚠️ Gemini উত্তর খালি")
            val parts = contentObj.optJSONArray("parts")
                ?: return HttpAttemptResult(null, responseCode, "⚠️ Gemini উত্তর খালি")

            for (i in 0 until parts.length()) {
                val partObj = parts.getJSONObject(i)
                if (!partObj.optBoolean("thought", false) && partObj.has("text")) {
                    val txt = partObj.getString("text").trim()
                    if (txt.isNotEmpty()) {
                        return HttpAttemptResult(txt, responseCode, "")
                    }
                }
            }
            return HttpAttemptResult(null, responseCode, "⚠️ Gemini উত্তর খালি")
        } catch (e: UnknownHostException) {
            return HttpAttemptResult(null, 0, "⚠️ ইন্টারনেট সংযোগ নেই")
        } catch (e: SocketTimeoutException) {
            return HttpAttemptResult(null, 0, "⚠️ ধীরগতির নেট (টাইমআউট)")
        } catch (e: Exception) {
            return HttpAttemptResult(null, 0, "⚠️ Gemini সংযোগে সমস্যা")
        } finally {
            try {
                connection?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private fun buildMessageDrivenPrompt(
        windowMessages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String>
    ): String {
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val historyFormatted = windowMessages.mapIndexed { i, m ->
            val tag = if (i == windowMessages.lastIndex) "[LATEST TARGET SMS]" else "[Context #${i + 1}]"
            "$tag ${m.sender}: ${m.text}"
        }.joinToString("\n")

        val avoidList = if (excludedReplies.isEmpty()) "None" else excludedReplies.take(12).joinToString(" | ")

        return listOf(
            "You are a real human chatting on WhatsApp in Bangladesh.",
            "Analyze the last ${windowMessages.size} messages below and write ONE immediate, realistic, natural reply that directly answers or reacts to the [LATEST TARGET SMS]: \"$lastIncoming\".",
            "",
            "STRICT CONVERSATIONAL RULES:",
            "1. PURE SMS-DRIVEN REALISM: Answer the exact point, question, or statement in \"$lastIncoming\" based on the conversation history.",
            "   - If they already answered a question (e.g., 'Nasta korci...tmi korco ki'), do NOT ask the same question back; answer for yourself and move the chat forward.",
            "   - If they say 'Akta kotha boloto' or 'Ami akta jinis jiggas korbo', invite them warmly ('Haa obosshoi bolo, ki jiggesh korba?').",
            "   - If they call you 'Babu' or 'Jaan', respond affectionately ('Haa babu bolo, ki korcho?').",
            "2. EXACT LANGUAGE & PRONOUN MIRRORING (Preference: $languagePreference):",
            "   - If \"$lastIncoming\" is in Banglish (Romanized Bangla), reply 100% in natural Bangladeshi Banglish (never mix Bengali script words into Banglish).",
            "   - If Bangla script, reply in natural spoken Bangla script.",
            "   - Mirror the exact pronoun used by the sender: 'tui/tor/dosto' (তুই), 'tumi/tmi/tomar' (তুমি), or 'apni/apnar' (আপনি).",
            "3. ZERO REPETITION: NEVER repeat any of these previously sent replies: [$avoidList].",
            "4. LENGTH: 1 short, natural WhatsApp sentence.",
            "",
            "Last ${windowMessages.size} Messages in Chat:",
            historyFormatted,
            "",
            "Return ONLY a JSON object with a single key \"reply\":",
            "{\"reply\": \"Your single realistic human reply\"}"
        ).joinToString("\n")
    }
}
