package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class GeminiReplyClient {

    companion object {
        private const val BROWSER_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
    }

    private val geminiModels = listOf(
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.0-flash",
        "gemini-1.5-flash-latest"
    )

    suspend fun generateContextualReply(
        apiKey: String,
        messages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String> = emptySet()
    ): ReplyOptions = withContext(Dispatchers.IO) {
        val windowMessages = messages.takeLast(5)
        if (windowMessages.isEmpty()) {
            return@withContext ReplyOptions("", "Empty")
        }

        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text?.trim()
            ?: windowMessages.last().text.trim()

        val allExcluded = HashSet<String>().apply {
            addAll(excludedReplies)
            windowMessages.filter { it.sender == "Me" }.forEach { add(it.text.trim()) }
        }

        val cleanKey = apiKey.trim()
        val prompt = buildMessageDrivenPrompt(windowMessages, languagePreference, allExcluded)

        // 1. If user provided a Groq API Key (gsk_...)
        if (cleanKey.startsWith("gsk_")) {
            val groqReply = callOpenAiCompatibleApi(
                endpoint = "https://api.groq.com/openai/v1/chat/completions",
                apiKey = cleanKey,
                model = "llama-3.3-70b-versatile",
                windowMessages = windowMessages,
                languagePreference = languagePreference,
                excludedReplies = allExcluded
            )
            if (isValidReply(groqReply, lastIncoming, allExcluded)) {
                return@withContext ReplyOptions(groqReply!!, "Groq AI • Live")
            }
        }

        // 2. If user provided a Google Gemini API Key (AIza...)
        if (cleanKey.isNotBlank() && !cleanKey.startsWith("gsk_")) {
            for (modelName in geminiModels) {
                try {
                    val rawResponse = executeGeminiPost(
                        apiKey = cleanKey,
                        modelName = modelName,
                        prompt = prompt,
                        useSimpleConfig = false
                    ) ?: executeGeminiPost(
                        apiKey = cleanKey,
                        modelName = modelName,
                        prompt = prompt,
                        useSimpleConfig = true
                    )
                    if (!rawResponse.isNullOrBlank()) {
                        val parsed = ReplyJsonParser.parseAiReply(rawResponse)
                        if (isValidReply(parsed, lastIncoming, allExcluded)) {
                            return@withContext ReplyOptions(parsed, "Gemini AI • Live")
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }

        // 3. Built-in Free Cloud AI (Works with ZERO API Key using Browser Headers!)
        val cloudAiReply = callBuiltInFreeCloudAi(windowMessages, languagePreference, allExcluded)
        if (isValidReply(cloudAiReply, lastIncoming, allExcluded)) {
            return@withContext ReplyOptions(cloudAiReply!!, "Cloud AI • Live")
        }

        // 4. Smart Context-Driven Local Engine (Coherent, Non-repeating, Message-Specific)
        ReplyJsonParser.buildSmartContextualReply(windowMessages, allExcluded)
    }

    private fun isValidReply(
        candidate: String?,
        lastIncoming: String,
        excluded: Set<String>
    ): Boolean {
        if (candidate.isNullOrBlank()) return false
        val trimmed = candidate.trim()
        if (trimmed.length < 2 || trimmed.length > 280) return false

        val lower = trimmed.lowercase()
        // Reject any HTML error page, JSON error object, or API warning
        val errorSignals = listOf(
            "<!doctype", "<html", "cloudflare", "error", "rate limit", "bad gateway",
            "502 ", "403 ", "429 ", "internal server", "exception", "api key"
        )
        if (errorSignals.any { lower.contains(it) }) return false

        // Reject if it just echoes the incoming message
        if (lower == lastIncoming.trim().lowercase()) return false

        // Reject if it duplicates any previously sent reply
        return excluded.none { it.trim().lowercase() == lower }
    }

    private fun executeGeminiPost(
        apiKey: String,
        modelName: String,
        prompt: String,
        useSimpleConfig: Boolean
    ): String? {
        val endpoint =
            "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val url = URL(endpoint)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("User-Agent", BROWSER_USER_AGENT)
            connectTimeout = 4500
            readTimeout = 5500
            doOutput = true
        }

        val genConfig = JSONObject().apply {
            put("temperature", 0.7)
            put("maxOutputTokens", 220)
            if (!useSimpleConfig) {
                put("responseMimeType", "application/json")
                if (modelName.startsWith("gemini-2.5")) {
                    put("thinkingConfig", JSONObject().apply {
                        put("thinkingBudget", 0)
                    })
                }
            }
        }

        val payload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("generationConfig", genConfig)
        }

        OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
            writer.write(payload.toString())
            writer.flush()
        }

        val responseCode = connection.responseCode
        val stream = if (responseCode in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream
        } ?: run {
            connection.disconnect()
            return null
        }

        val responseBody = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use {
            it.readText()
        }
        connection.disconnect()

        if (responseCode !in 200..299) {
            return null
        }

        val root = JSONObject(responseBody)
        val candidates = root.optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        val contentObj = candidates.getJSONObject(0).optJSONObject("content") ?: return null
        val parts = contentObj.optJSONArray("parts") ?: return null

        for (i in 0 until parts.length()) {
            val partObj = parts.getJSONObject(i)
            if (!partObj.optBoolean("thought", false) && partObj.has("text")) {
                val txt = partObj.getString("text").trim()
                if (txt.isNotEmpty()) return txt
            }
        }
        return null
    }

    private fun callOpenAiCompatibleApi(
        endpoint: String,
        apiKey: String?,
        model: String,
        windowMessages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String>
    ): String? {
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val historyFormatted = windowMessages.mapIndexed { i, m ->
            val tag = if (i == windowMessages.lastIndex) "[LATEST SMS TO REPLY]" else "[#${i + 1}]"
            "$tag ${m.sender}: ${m.text}"
        }.joinToString("\n")
        val avoidStr = excludedReplies.take(10).joinToString(" | ")

        val systemMsg = listOf(
            "You are a real Bangladeshi person chatting naturally on WhatsApp.",
            "Read the last ${windowMessages.size} messages and write ONLY 1 realistic, human reply that directly responds to the exact words and meaning of [LATEST SMS TO REPLY]: \"$lastIncoming\".",
            "CRITICAL RULES:",
            "1. DIRECT & COHERENT RESPONSE: Answer what the sender actually said or asked in \"$lastIncoming\".",
            "   - If they say 'Akta kotha boloto' or 'Ami akta jinis jiggas korbo' (asking permission to ask something), say 'Haa obosshoi bolo, ki jiggesh korba?' or 'Haa bolo, shunchi to!'.",
            "   - If they say 'Kisui kori ni, din to matro suru', agree naturally like 'Haa tao thik, sokal e to kebol shuru holo! Nasta korcho?'.",
            "   - If they say 'Jasce alhamdulillah valo', say 'Alhamdulillah, shune bhalo laglo! Ekhon ki korcho?'.",
            "   - If they call you 'Babu' or 'Jaan', reply affectionately like 'Haa babu bolo, ki korcho ekhon?'.",
            "2. LANGUAGE & SCRIPT MATCHING (Preference: $languagePreference): If \"$lastIncoming\" is in Banglish (Romanized Bangla), reply ONLY in natural Bangladeshi Banglish (never mix Bengali script words into Banglish). If Bangla script, reply in natural Bangla script. If English, reply in casual English.",
            "3. PRONOUN MATCHING: Match 'tui/tor/dosto', 'tumi/tmi/tomar', or 'apni/apnar' from the chat.",
            "4. NEVER REPEAT any of these previous replies: [$avoidStr].",
            "5. Output ONLY the raw reply sentence (no quotes, no JSON, no prefixes)."
        ).joinToString("\n")

        try {
            val url = URL(endpoint)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json, text/plain, */*")
                setRequestProperty("User-Agent", BROWSER_USER_AGENT)
                setRequestProperty("Origin", "https://pollinations.ai")
                setRequestProperty("Referer", "https://pollinations.ai/")
                if (!apiKey.isNullOrBlank()) {
                    setRequestProperty("Authorization", "Bearer $apiKey")
                }
                connectTimeout = 4200
                readTimeout = 5200
                doOutput = true
            }

            val body = JSONObject().apply {
                put("model", model)
                put("temperature", 0.7)
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "system")
                        put("content", systemMsg)
                    })
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", "Chat History:\n$historyFormatted\n\nWrite ONLY the reply to \"$lastIncoming\":")
                    })
                })
            }

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body.toString())
                writer.flush()
            }

            if (conn.responseCode in 200..299) {
                val resp = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
                conn.disconnect()
                if (resp.trim().startsWith("{") && resp.trim().endsWith("}")) {
                    val root = JSONObject(resp)
                    val choices = root.optJSONArray("choices")
                    if (choices != null && choices.length() > 0) {
                        val content = choices.getJSONObject(0).getJSONObject("message").getString("content").trim()
                        val cleaned = ReplyJsonParser.parseAiReply(content)
                        if (cleaned.isNotBlank()) return cleaned
                    }
                } else {
                    val cleaned = ReplyJsonParser.parseAiReply(resp)
                    if (cleaned.isNotBlank()) return cleaned
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun callBuiltInFreeCloudAi(
        windowMessages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String>
    ): String? {
        // Provider 1: Pollinations OpenAI-Fast endpoint with Browser User-Agent
        val fastReply = callOpenAiCompatibleApi(
            endpoint = "https://text.pollinations.ai/openai",
            apiKey = null,
            model = "openai-fast",
            windowMessages = windowMessages,
            languagePreference = languagePreference,
            excludedReplies = excludedReplies
        )
        if (!fastReply.isNullOrBlank()) return fastReply

        // Provider 2: Pollinations Standard OpenAI model
        val stdReply = callOpenAiCompatibleApi(
            endpoint = "https://text.pollinations.ai/openai",
            apiKey = null,
            model = "openai",
            windowMessages = windowMessages,
            languagePreference = languagePreference,
            excludedReplies = excludedReplies
        )
        if (!stdReply.isNullOrBlank()) return stdReply

        // Provider 3: Direct GET endpoint with Browser User-Agent
        try {
            val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
                ?: windowMessages.last().text
            val historyShort = windowMessages.takeLast(4).joinToString(" | ") { "${it.sender}: ${it.text}" }
            val prompt = "You are chatting on WhatsApp in Bangladesh. Chat history: [$historyShort]. Write ONLY 1 short natural human reply in the exact same language/script (Banglish, Bangla, or English) to the last message \"$lastIncoming\". No quotes:"
            val encoded = URLEncoder.encode(prompt, "UTF-8")
            val seed = (System.currentTimeMillis() % 90000).toInt() + 1000
            val url = URL("https://text.pollinations.ai/$encoded?model=openai-fast&seed=$seed")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", BROWSER_USER_AGENT)
                setRequestProperty("Accept", "text/plain, */*")
                connectTimeout = 4000
                readTimeout = 4800
            }
            if (conn.responseCode in 200..299) {
                val resp = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
                conn.disconnect()
                val cleaned = ReplyJsonParser.parseAiReply(resp)
                if (cleaned.isNotBlank()) return cleaned
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {
        }

        return null
    }

    private fun buildMessageDrivenPrompt(
        windowMessages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String>
    ): String {
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val historyFormatted = windowMessages.mapIndexed { i, m ->
            val tag = if (i == windowMessages.lastIndex) "[LATEST TARGET SMS]" else "[Context #${i + 1}]"
            "$tag ${m.sender}: ${m.text}"
        }.joinToString("\n")

        val avoidList = if (excludedReplies.isEmpty()) "None" else excludedReplies.take(12).joinToString(" | ")

        return listOf(
            "You are a real human chatting on WhatsApp in Bangladesh.",
            "Analyze the last ${windowMessages.size} messages below and write ONE immediate, realistic, natural reply that directly answers or reacts to the [LATEST TARGET SMS]: \"$lastIncoming\".",
            "",
            "STRICT CONVERSATIONAL RULES:",
            "1. PURE SMS-DRIVEN REALISM: Answer the exact point, question, or statement in \"$lastIncoming\".",
            "   - If they say 'Akta kotha boloto' or 'Ami akta jinis jiggas korbo', invite them to ask ('Haa obosshoi bolo, ki jiggesh korba?').",
            "   - If they say 'Kisui kori ni, din to matro suru', agree naturally ('Haa tao thik, din to kebol shuru holo!').",
            "   - If they say 'Babu' or 'Jaan', respond warmly ('Haa babu bolo, ki korcho?').",
            "2. EXACT LANGUAGE & PRONOUN MIRRORING (Preference: $languagePreference):",
            "   - If \"$lastIncoming\" is in Banglish (Romanized Bangla), reply 100% in natural Bangladeshi Banglish (never mix Bengali script words into Banglish).",
            "   - If Bangla script, reply in natural spoken Bangla script.",
            "   - Mirror the exact pronoun used by the sender: 'tui/tor/dosto' (তুই), 'tumi/tmi/tomar' (তুমি), or 'apni/apnar' (আপনি).",
            "3. ZERO REPETITION: NEVER repeat any of these previously sent replies: [$avoidList].",
            "4. LENGTH: 1 short, natural WhatsApp sentence.",
            "",
            "Last ${windowMessages.size} Messages in Chat:",
            historyFormatted,
            "",
            "Return ONLY a JSON object with a single key \"reply\":",
            "{\"reply\": \"Your single realistic human reply\"}"
        ).joinToString("\n")
    }
}
