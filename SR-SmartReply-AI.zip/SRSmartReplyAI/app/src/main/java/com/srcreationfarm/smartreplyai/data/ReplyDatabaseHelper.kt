package com.srcreationfarm.smartreplyai.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.srcreationfarm.smartreplyai.model.ReplyHistoryItem

class ReplyDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "sr_smartreply_history.db"
        private const val DATABASE_VERSION = 1

        private const val TABLE_HISTORY = "reply_history"
        private const val COL_ID = "id"
        private const val COL_INCOMING = "incoming_snippet"
        private const val COL_REPLY = "selected_reply"
        private const val COL_TONE = "tone"
        private const val COL_TIMESTAMP = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableSql = "CREATE TABLE $TABLE_HISTORY (" +
                "$COL_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COL_INCOMING TEXT NOT NULL, " +
                "$COL_REPLY TEXT NOT NULL, " +
                "$COL_TONE TEXT NOT NULL, " +
                "$COL_TIMESTAMP INTEGER NOT NULL)"
        db.execSQL(createTableSql)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 1) {
            onCreate(db)
        }
    }

    fun insertReply(item: ReplyHistoryItem): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_INCOMING, item.incomingSnippet)
            put(COL_REPLY, item.selectedReply)
            put(COL_TONE, item.tone)
            put(COL_TIMESTAMP, item.timestamp)
        }
        return db.insert(TABLE_HISTORY, null, values)
    }

    fun getAllReplies(query: String = ""): List<ReplyHistoryItem> {
        val list = mutableListOf<ReplyHistoryItem>()
        val db = readableDatabase
        val selection = if (query.isNotBlank()) {
            "$COL_INCOMING LIKE ? OR $COL_REPLY LIKE ?"
        } else null
        val selectionArgs = if (query.isNotBlank()) {
            arrayOf("%$query%", "%$query%")
        } else null

        db.query(
            TABLE_HISTORY,
            null,
            selection,
            selectionArgs,
            null,
            null,
            "$COL_TIMESTAMP DESC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                list.add(
                    ReplyHistoryItem(
                        id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ID)),
                        incomingSnippet = cursor.getString(cursor.getColumnIndexOrThrow(COL_INCOMING)),
                        selectedReply = cursor.getString(cursor.getColumnIndexOrThrow(COL_REPLY)),
                        tone = cursor.getString(cursor.getColumnIndexOrThrow(COL_TONE)),
                        timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(COL_TIMESTAMP))
                    )
                )
            }
        }
        return list
    }

    fun getCount(): Int {
        val db = readableDatabase
        db.rawQuery("SELECT COUNT(*) FROM $TABLE_HISTORY", null).use { cursor ->
            return if (cursor.moveToFirst()) cursor.getInt(0) else 0
        }
    }

    fun deleteById(id: Long) {
        writableDatabase.delete(TABLE_HISTORY, "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun clearAll() {
        writableDatabase.delete(TABLE_HISTORY, null, null)
    }
}
