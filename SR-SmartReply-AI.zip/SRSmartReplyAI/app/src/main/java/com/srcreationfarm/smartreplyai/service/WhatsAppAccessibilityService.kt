package com.srcreationfarm.smartreplyai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.ui.UnlockWakeActivity
import com.srcreationfarm.smartreplyai.ai.GeminiReplyClient
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyHistoryItem
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

class WhatsAppAccessibilityService : AccessibilityService() {

    private enum class OrbVisualState {
        CONNECTED_IDLE,
        ACTIVE_STEP,
        ERROR_DISCONNECTED,
        PAUSED
    }

    private lateinit var windowManager: WindowManager
    private lateinit var settingsManager: SettingsManager
    private lateinit var dbHelper: ReplyDatabaseHelper
    private val geminiClient = GeminiReplyClient()

    private var floatingView: View? = null
    private var windowParams: WindowManager.LayoutParams? = null

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var activeJob: Job? = null
    private var unlockNavigationJob: Job? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var currentDetectedSnippet: String = ""
    private var currentReplyOption: ReplyOptions? = null

    // Anti-Loop & Ultra-Fast Auto-Reply State Tracking
    private var lastRepliedSignature: String = ""
    private var lastSentReplyText: String = ""
    private var lastAutoReplyTimestamp: Long = 0L
    private var isProcessingAutoReply: Boolean = false
    private var lastObservedApiKey: String = ""

    // Notification Unlock Deduplication
    private var lastNotificationSignature: String = ""
    private var lastNotificationTriggerTime: Long = 0L

    private val autoScanRunnable = Runnable {
        checkAndTriggerAutoReply()
    }

    private val visibilityWatchdogRunnable = object : Runnable {
        override fun run() {
            val overlay = floatingView ?: return
            if (overlay.visibility == View.VISIBLE) {
                if (!settingsManager.isFloatingEnabled() || !isWhatsAppCurrentlyInForeground()) {
                    hideFloatingOverlayImmediately()
                } else {
                    if (!isProcessingAutoReply) {
                        refreshIdleFloatingStatus()
                    }
                    mainHandler.postDelayed(this, 300L)
                }
            }
        }
    }

    private val systemNavigationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_CLOSE_SYSTEM_DIALOGS,
                Intent.ACTION_SCREEN_OFF -> {
                    hideFloatingOverlayImmediately()
                }
            }
        }
    }

    companion object {
        @Volatile
        var isServiceRunning: Boolean = false
            private set

        @Volatile
        private var activeInstance: WhatsAppAccessibilityService? = null

        private const val PKG_WHATSAPP = "com.whatsapp"
        private const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"
        private const val COOLDOWN_AFTER_SEND_MS = 750L

        fun onIncomingWhatsAppNotification(
            context: Context,
            packageName: String,
            senderTitle: String,
            messageText: String,
            contentIntent: PendingIntent?
        ) {
            activeInstance?.handleNotificationTrigger(
                pkg = packageName,
                senderTitle = senderTitle,
                messageText = messageText,
                contentIntent = contentIntent
            )
        }

        fun triggerTestLaunchAndFindContact(targetName: String) {
            activeInstance?.executeTestOpenAndSearch(targetName)
        }
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        activeInstance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        settingsManager = SettingsManager.getInstance(this)
        dbHelper = ReplyDatabaseHelper(this)
        lastObservedApiKey = settingsManager.getApiKey()
        setupFloatingOverlay()

        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                addAction(Intent.ACTION_SCREEN_OFF)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(systemNavigationReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(systemNavigationReceiver, filter)
            }
        } catch (_: Exception) {
        }
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun setupFloatingOverlay() {
        if (floatingView != null) return

        val view = LayoutInflater.from(this).inflate(R.layout.layout_floating_ai, null)
        floatingView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = settingsManager.getOrbX()
            y = settingsManager.getOrbY()
        }
        windowParams = params

        val orbButton = view.findViewById<View>(R.id.btnFloatingOrb)
        val panelContainer = view.findViewById<View>(R.id.panelReplyContainer)
        val btnClosePanel = view.findViewById<View>(R.id.btnClosePanel)
        val btnRegenerate = view.findViewById<View>(R.id.btnRegenerateReply)
        val cardSmartReply = view.findViewById<View>(R.id.cardSmartReply)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var longPressTriggered = false

        val longPressRunnable = Runnable {
            if (!isDragging) {
                longPressTriggered = true
                triggerHaptic()
                if (panelContainer.visibility == View.VISIBLE) {
                    panelContainer.visibility = View.GONE
                } else {
                    panelContainer.visibility = View.VISIBLE
                    scanAndPopulateManualPanel()
                }
            }
        }

        orbButton.setOnTouchListener { _, event ->
            val currentParams = windowParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = currentParams.x
                    initialY = currentParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    longPressTriggered = false
                    mainHandler.postDelayed(longPressRunnable, 600L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (initialTouchX - event.rawX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    if (abs(deltaX) > 12 || abs(deltaY) > 12) {
                        isDragging = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    if (isDragging) {
                        currentParams.x = (initialX + deltaX).coerceAtLeast(0)
                        currentParams.y = (initialY + deltaY).coerceAtLeast(40)
                        try {
                            windowManager.updateViewLayout(view, currentParams)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (isDragging) {
                        settingsManager.saveOrbPosition(currentParams.x, currentParams.y)
                    } else if (!longPressTriggered) {
                        triggerHaptic()
                        val hasErr = settingsManager.getLastConnectionError().isNotBlank()
                        if (hasErr || settingsManager.getApiKey().isBlank() || !isNetworkConnected()) {
                            verifyConnectionAndNotify()
                        } else {
                            val newState = !settingsManager.isFullAutoReplyEnabled()
                            settingsManager.setFullAutoReplyEnabled(newState)
                            refreshIdleFloatingStatus()
                            val statusMsg = if (newState) {
                                "✅ Gemini ফাস্ট অটো-রিপ্লাই চালু"
                            } else {
                                "⏸️ অটো-রিপ্লাই সাময়িকভাবে বন্ধ"
                            }
                            Toast.makeText(this, statusMsg, Toast.LENGTH_SHORT).show()
                            if (newState) {
                                lastRepliedSignature = ""
                                scheduleAutoScan(50L)
                            }
                        }
                    }
                    true
                }
                else -> false
            }
        }

        btnClosePanel.setOnClickListener {
            panelContainer.visibility = View.GONE
        }

        btnRegenerate.setOnClickListener {
            triggerHaptic()
            scanAndPopulateManualPanel()
        }

        cardSmartReply.setOnClickListener {
            currentReplyOption?.let { opt ->
                if (opt.isSuccess && opt.reply.isNotBlank()) {
                    serviceScope.launch {
                        updateFloatingNotification("🚀 রিপ্লাই দেওয়া হচ্ছে...", "#FBBF24", OrbVisualState.ACTIVE_STEP)
                        handleReplySelected(opt.reply, opt.detectedContext)
                        delay(280L)
                        updateFloatingNotification("✅ রিপ্লাই দেওয়া সম্পন্ন!", "#34D399", OrbVisualState.CONNECTED_IDLE)
                        delay(700L)
                        refreshIdleFloatingStatus()
                    }
                }
            }
        }

        cardSmartReply.setOnLongClickListener {
            currentReplyOption?.let { opt ->
                if (opt.isSuccess && opt.reply.isNotBlank()) {
                    copyToClipboard(opt.reply)
                }
            }
            true
        }

        try {
            windowManager.addView(view, params)
            view.visibility = View.GONE
            refreshIdleFloatingStatus()
        } catch (_: Exception) {
        }
    }

    // =========================================================================
    // NEW IN v4.0: NOTIFICATION -> WAKE SCREEN -> AUTO PIN UNLOCK -> OPEN WHATSAPP -> FIND CONTACT -> AUTO REPLY
    // =========================================================================

    fun handleNotificationTrigger(
        pkg: String,
        senderTitle: String,
        messageText: String,
        contentIntent: PendingIntent?
    ) {
        if (!settingsManager.isFullAutoReplyEnabled()) return
        if (!settingsManager.isAutoUnlockAndOpenEnabled()) return

        // Target Contact Filter verification
        val configuredTarget = settingsManager.getFirstTargetContactName()
        if (settingsManager.isTargetFilterEnabled() && configuredTarget.isNotEmpty()) {
            if (senderTitle.isNotEmpty() && !settingsManager.isChatAllowedByTargetFilter(senderTitle)) {
                return
            }
        }

        val now = System.currentTimeMillis()
        val sig = "$senderTitle::$messageText"
        if (sig == lastNotificationSignature && (now - lastNotificationTriggerTime) < 3500L) {
            return
        }
        lastNotificationSignature = sig
        lastNotificationTriggerTime = now

        // If WhatsApp is already open in foreground and not locked, just let normal auto-scan handle it or navigate to contact
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val isScreenInteractive = pm.isInteractive
        val isLocked = km.isKeyguardLocked

        if (isScreenInteractive && !isLocked && isWhatsAppCurrentlyInForeground()) {
            val root = rootInActiveWindow
            if (root != null && findWhatsAppInputNode(root) != null) {
                val activeChat = detectContactTitle(root)
                val targetName = configuredTarget.ifEmpty { senderTitle }
                if (targetName.isEmpty() || SettingsManager.matchesTargetContact(activeChat, targetName)) {
                    scheduleAutoScan(60L)
                    return
                }
            }
        }

        unlockNavigationJob?.cancel()
        unlockNavigationJob = serviceScope.launch {
            try {
                // 1. Wake up screen if off
                wakeUpDeviceScreen()
                delay(350L)

                // 2. If device is locked, perform swipe up + enter saved PIN + press Enter
                if (km.isKeyguardLocked) {
                    performLockScreenPinUnlock(km)
                }

                // 3. Open WhatsApp and navigate to the target contact chat
                val targetContact = configuredTarget.ifEmpty { senderTitle }
                openWhatsAppAndNavigateToTarget(
                    pkg = pkg.ifEmpty { PKG_WHATSAPP },
                    targetContactName = targetContact,
                    contentIntent = contentIntent
                )
            } catch (_: Exception) {
            }
        }
    }

    fun executeTestOpenAndSearch(targetName: String) {
        unlockNavigationJob?.cancel()
        unlockNavigationJob = serviceScope.launch {
            val searchTarget = targetName.trim().ifEmpty { settingsManager.getFirstTargetContactName() }
            openWhatsAppAndNavigateToTarget(
                pkg = PKG_WHATSAPP,
                targetContactName = searchTarget,
                contentIntent = null
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun wakeUpDeviceScreen() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isInteractive) {
                val wl = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                            PowerManager.ACQUIRE_CAUSES_WAKEUP or
                            PowerManager.ON_AFTER_RELEASE,
                    "srsmartreply:autowakelock"
                )
                wl.acquire(12000L)
            }
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (km.isKeyguardLocked) {
                val wakeIntent = Intent(this, UnlockWakeActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                startActivity(wakeIntent)
            }
        } catch (_: Exception) {
        }
    }

    private suspend fun performLockScreenPinUnlock(km: KeyguardManager) {
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels

        // Step A: Swipe Up from bottom of lock screen to reveal PIN keypad
        performSwipeGesture(
            startX = screenW * 0.5f,
            startY = screenH * 0.82f,
            endX = screenW * 0.5f,
            endY = screenH * 0.22f,
            durationMs = 260L
        )
        delay(600L)

        if (!km.isKeyguardLocked) return

        val pin = settingsManager.getPhoneLockPin()
        if (pin.isEmpty()) return

        // Step B: Check if there is a direct editable PIN/Password text box
        val editablePinNode = findEditablePinNodeAcrossWindows()
        if (editablePinNode != null) {
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, pin)
            }
            editablePinNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            delay(250L)
            clickLockScreenEnterButton(screenW, screenH)
            delay(550L)
            return
        }

        // Step C: Enter each digit on the PIN keypad (Node click + Coordinate tap fallback)
        for (digitChar in pin) {
            if (!digitChar.isDigit()) continue
            val clickedByNode = clickLockScreenDigitNode(digitChar)
            if (!clickedByNode) {
                tapStandardPinPadCoordinate(digitChar, screenW, screenH)
            }
            delay(170L)
        }

        delay(220L)
        if (km.isKeyguardLocked && settingsManager.isPinPressEnterEnabled()) {
            clickLockScreenEnterButton(screenW, screenH)
            delay(550L)
        }
    }

    private fun findEditablePinNodeAcrossWindows(): AccessibilityNodeInfo? {
        try {
            for (win in windows) {
                val root = win.root ?: continue
                val pinIds = listOf(
                    "com.android.systemui:id/pinEntry",
                    "com.android.systemui:id/passwordEntry",
                    "com.android.systemui:id/simPinEntry"
                )
                for (id in pinIds) {
                    val found = root.findAccessibilityNodeInfosByViewId(id)
                    if (!found.isNullOrEmpty() && found.first().isEditable) {
                        return found.first()
                    }
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun clickLockScreenDigitNode(digit: Char): Boolean {
        val digitStr = digit.toString()
        val possibleViewIds = listOf(
            "com.android.systemui:id/key$digitStr",
            "com.android.keyguard:id/key$digitStr",
            "com.miui.systemui:id/key$digitStr"
        )

        val rootsToSearch = mutableListOf<AccessibilityNodeInfo>()
        try {
            windows?.forEach { win -> win.root?.let { rootsToSearch.add(it) } }
        } catch (_: Exception) {
        }
        rootInActiveWindow?.let { if (it !in rootsToSearch) rootsToSearch.add(it) }

        for (root in rootsToSearch) {
            for (id in possibleViewIds) {
                val found = root.findAccessibilityNodeInfosByViewId(id)
                if (!found.isNullOrEmpty()) {
                    if (clickNodeOrBounds(found.first())) return true
                }
            }
            val matchedByText = findDigitNodeRecursive(root, digitStr)
            if (matchedByText != null) {
                if (clickNodeOrBounds(matchedByText)) return true
            }
        }
        return false
    }

    private fun findDigitNodeRecursive(node: AccessibilityNodeInfo?, digitStr: String): AccessibilityNodeInfo? {
        if (node == null) return null
        val txt = node.text?.toString()?.trim() ?: ""
        val desc = node.contentDescription?.toString()?.trim() ?: ""
        if (txt == digitStr || desc == digitStr || txt.startsWith("$digitStr ") || desc.startsWith("$digitStr ")) {
            return node
        }
        for (i in 0 until node.childCount) {
            val found = findDigitNodeRecursive(node.getChild(i), digitStr)
            if (found != null) return found
        }
        return null
    }

    private fun clickLockScreenEnterButton(screenW: Int, screenH: Int): Boolean {
        val enterIds = listOf(
            "com.android.systemui:id/key_enter",
            "com.android.keyguard:id/key_enter",
            "com.miui.systemui:id/key_enter"
        )
        val rootsToSearch = mutableListOf<AccessibilityNodeInfo>()
        try {
            windows?.forEach { win -> win.root?.let { rootsToSearch.add(it) } }
        } catch (_: Exception) {
        }
        rootInActiveWindow?.let { if (it !in rootsToSearch) rootsToSearch.add(it) }

        for (root in rootsToSearch) {
            for (id in enterIds) {
                val found = root.findAccessibilityNodeInfosByViewId(id)
                if (!found.isNullOrEmpty()) {
                    if (clickNodeOrBounds(found.first())) return true
                }
            }
            for (label in listOf("OK", "Enter", "✓", "Done")) {
                val found = root.findAccessibilityNodeInfosByText(label)
                if (!found.isNullOrEmpty()) {
                    if (clickNodeOrBounds(found.first())) return true
                }
            }
        }
        // Coordinate fallback for bottom-right Enter key on standard PIN pad
        performTapGesture(screenW * 0.78f, screenH * 0.84f)
        return true
    }

    private fun clickNodeOrBounds(node: AccessibilityNodeInfo): Boolean {
        var curr: AccessibilityNodeInfo? = node
        while (curr != null) {
            if (curr.isClickable && curr.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            curr = curr.parent
        }
        val rect = Rect()
        node.getBoundsInScreen(rect)
        if (!rect.isEmpty && rect.centerX() > 0 && rect.centerY() > 0) {
            performTapGesture(rect.centerX().toFloat(), rect.centerY().toFloat())
            return true
        }
        return false
    }

    private fun tapStandardPinPadCoordinate(digit: Char, screenW: Int, screenH: Int) {
        val colLeft = screenW * 0.22f
        val colMid = screenW * 0.50f
        val colRight = screenW * 0.78f

        val row1 = screenH * 0.54f
        val row2 = screenH * 0.64f
        val row3 = screenH * 0.74f
        val row4 = screenH * 0.84f

        val (x, y) = when (digit) {
            '1' -> Pair(colLeft, row1)
            '2' -> Pair(colMid, row1)
            '3' -> Pair(colRight, row1)
            '4' -> Pair(colLeft, row2)
            '5' -> Pair(colMid, row2)
            '6' -> Pair(colRight, row2)
            '7' -> Pair(colLeft, row3)
            '8' -> Pair(colMid, row3)
            '9' -> Pair(colRight, row3)
            '0' -> Pair(colMid, row4)
            else -> return
        }
        performTapGesture(x, y)
    }

    private fun performSwipeGesture(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long
    ) {
        try {
            val path = Path().apply {
                moveTo(startX, startY)
                lineTo(endX, endY)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(gesture, null, null)
        } catch (_: Exception) {
        }
    }

    private fun performTapGesture(x: Float, y: Float) {
        try {
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0L, 55L)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(gesture, null, null)
        } catch (_: Exception) {
        }
    }

    private suspend fun openWhatsAppAndNavigateToTarget(
        pkg: String,
        targetContactName: String,
        contentIntent: PendingIntent?
    ) {
        // 1. Try firing the notification's PendingIntent first (jumps straight into the conversation!)
        var launchedViaPendingIntent = false
        if (contentIntent != null) {
            try {
                contentIntent.send()
                launchedViaPendingIntent = true
            } catch (_: Exception) {
            }
        }

        if (!launchedViaPendingIntent) {
            try {
                val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
                    ?: packageManager.getLaunchIntentForPackage(PKG_WHATSAPP)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    startActivity(launchIntent)
                }
            } catch (_: Exception) {
            }
        }

        delay(850L)
        showFloatingOverlayIfAllowed()

        // 2. Check if we are already inside the target contact's conversation
        val root1 = rootInActiveWindow
        if (root1 != null && findWhatsAppInputNode(root1) != null) {
            val currentTitle = detectContactTitle(root1)
            if (targetContactName.isEmpty() || SettingsManager.matchesTargetContact(currentTitle, targetContactName)) {
                lastRepliedSignature = ""
                scheduleAutoScan(80L)
                return
            }
            // If inside a different chat, press Back to return to WhatsApp main list and find target
            performGlobalAction(GLOBAL_ACTION_BACK)
            delay(500L)
        }

        if (targetContactName.isEmpty()) return

        updateFloatingNotification("🔍 [$targetContactName] খোঁজা হচ্ছে...", "#38BDF8", OrbVisualState.ACTIVE_STEP)

        // 3. Look for the target contact in the visible WhatsApp chat list
        val root2 = rootInActiveWindow
        if (root2 != null && findAndClickContactRowInList(root2, targetContactName)) {
            delay(650L)
            lastRepliedSignature = ""
            scheduleAutoScan(80L)
            return
        }

        // 4. Not visible in top list -> Click WhatsApp Search button, type target name/number, and click result!
        val root3 = rootInActiveWindow ?: return
        if (clickWhatsAppSearchIcon(root3)) {
            delay(500L)
            val rootAfterSearchClick = rootInActiveWindow ?: return
            val searchBox = findWhatsAppSearchInputNode(rootAfterSearchClick)
            if (searchBox != null) {
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, targetContactName)
                }
                searchBox.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                delay(750L)

                val rootWithResults = rootInActiveWindow
                if (rootWithResults != null && findAndClickContactRowInList(rootWithResults, targetContactName)) {
                    delay(650L)
                    lastRepliedSignature = ""
                    scheduleAutoScan(80L)
                }
            }
        }
    }

    private fun findAndClickContactRowInList(
        rootNode: AccessibilityNodeInfo,
        targetContactName: String
    ): Boolean {
        val rowTitleIds = listOf(
            "com.whatsapp:id/conversations_row_contact_name",
            "com.whatsapp.w4b:id/conversations_row_contact_name",
            "com.whatsapp:id/contactpicker_row_name",
            "com.whatsapp.w4b:id/contactpicker_row_name"
        )
        for (id in rowTitleIds) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!nodes.isNullOrEmpty()) {
                for (node in nodes) {
                    val rowTitle = node.text?.toString()?.trim() ?: continue
                    if (SettingsManager.matchesTargetContact(rowTitle, targetContactName)) {
                        if (clickNodeOrBounds(node)) return true
                    }
                }
            }
        }

        // Fallback text search across screen nodes
        val textMatches = rootNode.findAccessibilityNodeInfosByText(targetContactName)
        if (!textMatches.isNullOrEmpty()) {
            for (node in textMatches) {
                if (!node.isEditable && clickNodeOrBounds(node)) {
                    return true
                }
            }
        }
        return false
    }

    private fun clickWhatsAppSearchIcon(rootNode: AccessibilityNodeInfo): Boolean {
        val searchIds = listOf(
            "com.whatsapp:id/menuitem_search",
            "com.whatsapp.w4b:id/menuitem_search",
            "com.whatsapp:id/search_bar_inner",
            "com.whatsapp.w4b:id/search_bar_inner"
        )
        for (id in searchIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                if (clickNodeOrBounds(found.first())) return true
            }
        }
        for (label in listOf("Search", "খুঁজুন", "Ask Meta AI or Search")) {
            val found = rootNode.findAccessibilityNodeInfosByText(label)
            if (!found.isNullOrEmpty()) {
                if (clickNodeOrBounds(found.first())) return true
            }
        }
        return false
    }

    private fun findWhatsAppSearchInputNode(rootNode: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val inputIds = listOf(
            "com.whatsapp:id/search_src_text",
            "com.whatsapp.w4b:id/search_src_text",
            "com.whatsapp:id/search_input",
            "com.whatsapp.w4b:id/search_input"
        )
        for (id in inputIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) return found.first()
        }
        return findFirstEditableNode(rootNode)
    }

    // =========================================================================
    // EXISTING FLOATING OVERLAY & ULTRA-FAST AUTO-REPLY LOGIC
    // =========================================================================

    private fun isNetworkConnected(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    private fun verifyConnectionAndNotify() {
        val apiKey = settingsManager.getApiKey()
        if (apiKey.isBlank()) {
            settingsManager.recordConnectionFailure("⚠️ Gemini API Key নেই")
            refreshIdleFloatingStatus()
            Toast.makeText(this, "অ্যাপে গিয়ে Gemini API Key সেট করুন", Toast.LENGTH_SHORT).show()
            return
        }
        if (!isNetworkConnected()) {
            settingsManager.recordConnectionFailure("⚠️ ইন্টারনেট সংযোগ নেই")
            refreshIdleFloatingStatus()
            Toast.makeText(this, "ইন্টারনেট সংযোগ চালু করুন", Toast.LENGTH_SHORT).show()
            return
        }

        updateFloatingNotification("🔄 Gemini কানেকশন চেক হচ্ছে...", "#38BDF8", OrbVisualState.ACTIVE_STEP)
        serviceScope.launch {
            val res = geminiClient.verifyGeminiConnection(apiKey, "Assalamu Alaikum")
            if (res.isSuccess) {
                settingsManager.recordConnectionSuccess(res.modelUsed, res.latencyMs)
                settingsManager.setFullAutoReplyEnabled(true)
                refreshIdleFloatingStatus()
                Toast.makeText(this@WhatsAppAccessibilityService, "✅ Gemini সংযুক্ত (${res.modelUsed})", Toast.LENGTH_SHORT).show()
                lastRepliedSignature = ""
                scheduleAutoScan(60L)
            } else {
                val err = res.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                settingsManager.recordConnectionFailure(err)
                refreshIdleFloatingStatus()
                Toast.makeText(this@WhatsAppAccessibilityService, err, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun updateFloatingNotification(
        message: String,
        textColorHex: String,
        orbState: OrbVisualState
    ) {
        val view = floatingView ?: return
        val badge = view.findViewById<TextView>(R.id.tvFloatingStatusBadge) ?: return
        val orb = view.findViewById<View>(R.id.btnFloatingOrb) ?: return

        badge.text = message
        try {
            badge.setTextColor(Color.parseColor(textColorHex))
        } catch (_: Exception) {
        }

        val bgRes = when (orbState) {
            OrbVisualState.CONNECTED_IDLE -> R.drawable.bg_floating_pill
            OrbVisualState.ACTIVE_STEP -> R.drawable.bg_floating_pill_active
            OrbVisualState.ERROR_DISCONNECTED -> R.drawable.bg_floating_pill_error
            OrbVisualState.PAUSED -> R.drawable.bg_floating_pill
        }
        orb.setBackgroundResource(bgRes)
    }

    private fun refreshIdleFloatingStatus() {
        val apiKey = settingsManager.getApiKey()
        if (apiKey != lastObservedApiKey) {
            lastObservedApiKey = apiKey
            lastRepliedSignature = ""
        }

        if (apiKey.isBlank()) {
            updateFloatingNotification(
                "⚠️ Gemini API Key নেই",
                "#F87171",
                OrbVisualState.ERROR_DISCONNECTED
            )
            return
        }

        if (!isNetworkConnected()) {
            updateFloatingNotification(
                "⚠️ ইন্টারনেট সংযোগ নেই",
                "#F87171",
                OrbVisualState.ERROR_DISCONNECTED
            )
            return
        }

        val savedError = settingsManager.getLastConnectionError()
        if (savedError.isNotBlank() && !settingsManager.isGeminiConnected()) {
            updateFloatingNotification(
                savedError,
                "#F87171",
                OrbVisualState.ERROR_DISCONNECTED
            )
            return
        }

        if (!settingsManager.isFullAutoReplyEnabled()) {
            updateFloatingNotification(
                "⏸️ অটো-রিপ্লাই বন্ধ",
                "#FBBF24",
                OrbVisualState.PAUSED
            )
            return
        }

        if (settingsManager.isTargetFilterEnabled() && settingsManager.getTargetContactQuery().isNotEmpty()) {
            val rootNode = rootInActiveWindow
            if (rootNode != null && findWhatsAppInputNode(rootNode) != null) {
                val activeTitle = detectContactTitle(rootNode)
                if (!settingsManager.isChatAllowedByTargetFilter(activeTitle)) {
                    updateFloatingNotification(
                        "🔒 অন্য চ্যাট (টার্গেট নয়)",
                        "#FBBF24",
                        OrbVisualState.PAUSED
                    )
                    return
                } else {
                    val shortTitle = activeTitle.take(14)
                    updateFloatingNotification(
                        "✅ Gemini সংযুক্ত (🎯 $shortTitle)",
                        "#34D399",
                        OrbVisualState.CONNECTED_IDLE
                    )
                    return
                }
            }
        }

        updateFloatingNotification(
            "✅ Gemini সংযুক্ত",
            "#34D399",
            OrbVisualState.CONNECTED_IDLE
        )
    }

    private fun isSupportedWhatsAppPackage(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        return pkg == PKG_WHATSAPP ||
                (pkg == PKG_WHATSAPP_BUSINESS && settingsManager.isWhatsAppBusinessEnabled())
    }

    private fun isInputMethodPackage(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        val lower = pkg.lowercase()
        if (listOf("inputmethod", "keyboard", "honeyboard", "swiftkey", "ridmik", "gboard", "latin").any { lower.contains(it) }) {
            return true
        }
        return try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.enabledInputMethodList?.any { it.packageName == pkg } == true
        } catch (_: Exception) {
            false
        }
    }

    private fun isWhatsAppCurrentlyInForeground(): Boolean {
        try {
            val windowList = windows
            if (!windowList.isNullOrEmpty()) {
                val appWindows = windowList.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                if (appWindows.isNotEmpty()) {
                    val activeAppWindow = appWindows.firstOrNull { it.isActive || it.isFocused } ?: appWindows.first()
                    val appPkg = activeAppWindow.root?.packageName?.toString()
                    if (appPkg != null) {
                        return isSupportedWhatsAppPackage(appPkg)
                    }
                    return appWindows.any { isSupportedWhatsAppPackage(it.root?.packageName?.toString()) }
                }
            }
        } catch (_: Exception) {
        }

        val activeRootPkg = rootInActiveWindow?.packageName?.toString() ?: return false
        return isSupportedWhatsAppPackage(activeRootPkg)
    }

    private fun showFloatingOverlayIfAllowed() {
        val overlay = floatingView ?: return
        if (!settingsManager.isFloatingEnabled()) {
            hideFloatingOverlayImmediately()
            return
        }
        if (overlay.visibility != View.VISIBLE) {
            overlay.visibility = View.VISIBLE
            if (!isProcessingAutoReply) {
                refreshIdleFloatingStatus()
            }
        }
        mainHandler.removeCallbacks(visibilityWatchdogRunnable)
        mainHandler.postDelayed(visibilityWatchdogRunnable, 300L)
    }

    private fun hideFloatingOverlayImmediately() {
        mainHandler.removeCallbacks(autoScanRunnable)
        mainHandler.removeCallbacks(visibilityWatchdogRunnable)
        activeJob?.cancel()
        isProcessingAutoReply = false
        floatingView?.findViewById<View>(R.id.panelReplyContainer)?.visibility = View.GONE
        floatingView?.visibility = View.GONE
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val eventPkg = event.packageName?.toString() ?: ""
        if (eventPkg == packageName) return

        // Catch WhatsApp notifications directly via AccessibilityService as well!
        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED &&
            isSupportedWhatsAppPackage(eventPkg)
        ) {
            val notif = event.parcelableData as? Notification
            if (notif != null) {
                val extras = notif.extras
                val rawTitle = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
                val rawText = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""
                if (rawTitle.isNotEmpty() && rawText.isNotEmpty() &&
                    !rawTitle.equals("WhatsApp", ignoreCase = true) &&
                    !rawText.contains("new messages", ignoreCase = true)
                ) {
                    val cleanSender = rawTitle.replace(Regex("\\s*\\(\\d+\\s+messages?\\)$", RegexOption.IGNORE_CASE), "").trim()
                    handleNotificationTrigger(
                        pkg = eventPkg,
                        senderTitle = cleanSender,
                        messageText = rawText,
                        contentIntent = notif.contentIntent
                    )
                }
            }
            return
        }

        if (isSupportedWhatsAppPackage(eventPkg)) {
            showFloatingOverlayIfAllowed()
            if (settingsManager.isFullAutoReplyEnabled()) {
                scheduleAutoScan(settingsManager.getAutoReplyDelayMs())
            }
            return
        }

        if (isInputMethodPackage(eventPkg)) {
            if (!isWhatsAppCurrentlyInForeground()) {
                hideFloatingOverlayImmediately()
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED
        ) {
            if (!isWhatsAppCurrentlyInForeground()) {
                hideFloatingOverlayImmediately()
            }
        } else if (!isWhatsAppCurrentlyInForeground()) {
            hideFloatingOverlayImmediately()
        }
    }

    private fun scheduleAutoScan(delayMs: Long) {
        mainHandler.removeCallbacks(autoScanRunnable)
        mainHandler.postDelayed(autoScanRunnable, delayMs)
    }

    private fun checkAndTriggerAutoReply() {
        if (!settingsManager.isFullAutoReplyEnabled()) return
        if (isProcessingAutoReply) return

        if (!isWhatsAppCurrentlyInForeground()) {
            hideFloatingOverlayImmediately()
            return
        }

        val apiKey = settingsManager.getApiKey()
        if (apiKey.isBlank()) {
            settingsManager.recordConnectionFailure("⚠️ Gemini API Key নেই")
            refreshIdleFloatingStatus()
            return
        }
        if (!isNetworkConnected()) {
            settingsManager.recordConnectionFailure("⚠️ ইন্টারনেট সংযোগ নেই")
            refreshIdleFloatingStatus()
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastAutoReplyTimestamp < COOLDOWN_AFTER_SEND_MS) {
            return
        }

        val rootNode = rootInActiveWindow ?: return
        val pkg = rootNode.packageName?.toString() ?: return
        if (!isSupportedWhatsAppPackage(pkg)) {
            hideFloatingOverlayImmediately()
            return
        }

        val inputNode = findWhatsAppInputNode(rootNode) ?: return
        if (isUserManuallyTyping(inputNode)) return

        val contactTitle = detectContactTitle(rootNode)

        if (!settingsManager.isChatAllowedByTargetFilter(contactTitle)) {
            refreshIdleFloatingStatus()
            return
        }

        val recentSentSet = settingsManager.getRecentSentReplies()
        val contextDepth = settingsManager.getContextDepth().coerceAtLeast(5)
        val messages = scanVisibleWhatsAppMessages(contextDepth, rootNode, recentSentSet)
        if (messages.isEmpty()) return

        val lastMessage = messages.last()
        if (lastMessage.sender != "Incoming") return

        val incomingText = lastMessage.text.trim()
        if (incomingText.isEmpty() || incomingText.equals(lastSentReplyText, ignoreCase = true)) return
        if (recentSentSet.any { it.equals(incomingText, ignoreCase = true) }) return

        val incomingCount = messages.count { it.sender == "Incoming" }
        val signature = "$contactTitle::$incomingText::$incomingCount"

        if (signature == lastRepliedSignature) return

        isProcessingAutoReply = true
        lastRepliedSignature = signature
        currentDetectedSnippet = incomingText

        updateFloatingNotification(
            "📤 Gemini-এর কাছে পাঠানো হয়েছে...",
            "#38BDF8",
            OrbVisualState.ACTIVE_STEP
        )

        activeJob?.cancel()
        activeJob = serviceScope.launch {
            try {
                val result = geminiClient.generateContextualReply(
                    apiKey = apiKey,
                    messages = messages.takeLast(5),
                    languagePreference = settingsManager.getLanguagePreference(),
                    excludedReplies = recentSentSet,
                    contactName = contactTitle
                )

                val replyToSend = result.reply.trim()
                if (result.isSuccess && replyToSend.isNotBlank() && isWhatsAppCurrentlyInForeground()) {
                    settingsManager.recordConnectionSuccess(result.modelUsed, result.latencyMs)

                    updateFloatingNotification(
                        "📥 রিপ্লাই গৃহীত! 🚀 পাঠানো হচ্ছে...",
                        "#2DD4BF",
                        OrbVisualState.ACTIVE_STEP
                    )

                    lastSentReplyText = replyToSend
                    lastAutoReplyTimestamp = System.currentTimeMillis()
                    settingsManager.addRecentSentReply(replyToSend)
                    handleReplySelected(replyToSend, result.detectedContext)

                    delay(260L)

                    if (isWhatsAppCurrentlyInForeground()) {
                        updateFloatingNotification(
                            "✅ রিপ্লাই দেওয়া সম্পন্ন!",
                            "#34D399",
                            OrbVisualState.CONNECTED_IDLE
                        )
                        delay(750L)
                    }
                } else {
                    val err = result.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                    settingsManager.recordConnectionFailure(err)
                    lastRepliedSignature = ""
                    updateFloatingNotification(
                        err,
                        "#F87171",
                        OrbVisualState.ERROR_DISCONNECTED
                    )
                    delay(1500L)
                }
            } catch (_: Exception) {
                settingsManager.recordConnectionFailure("⚠️ Gemini সংযোগে সমস্যা")
                lastRepliedSignature = ""
            } finally {
                isProcessingAutoReply = false
                if (isWhatsAppCurrentlyInForeground()) {
                    refreshIdleFloatingStatus()
                } else {
                    hideFloatingOverlayImmediately()
                }
            }
        }
    }

    private fun scanAndPopulateManualPanel() {
        val view = floatingView ?: return
        val tvDetected = view.findViewById<TextView>(R.id.tvDetectedMessage)
        val progress = view.findViewById<ProgressBar>(R.id.progressAiLoading)
        val tvContextLabel = view.findViewById<TextView>(R.id.tvDetectedContextLabel)
        val tvSmartReply = view.findViewById<TextView>(R.id.tvSmartReplyText)

        val apiKey = settingsManager.getApiKey()
        if (apiKey.isBlank()) {
            settingsManager.recordConnectionFailure("⚠️ Gemini API Key নেই")
            refreshIdleFloatingStatus()
            tvDetected.text = "সংযোগ নেই"
            tvContextLabel.text = "⚠️ Gemini API Key সেট করা নেই"
            tvSmartReply.text = "অ্যাপের ড্যাশবোর্ডে গিয়ে আপনার Gemini API Key পেস্ট করে 'Save & Test Key' চাপুন।"
            return
        }

        if (!isNetworkConnected()) {
            settingsManager.recordConnectionFailure("⚠️ ইন্টারনেট সংযোগ নেই")
            refreshIdleFloatingStatus()
            tvDetected.text = "সংযোগ নেই"
            tvContextLabel.text = "⚠️ ইন্টারনেট সংযোগ নেই"
            tvSmartReply.text = "ফোনের ডাটা বা ওয়াইফাই চালু করুন।"
            return
        }

        val rootNode = rootInActiveWindow
        val contactTitle = if (rootNode != null) detectContactTitle(rootNode) else "ActiveChat"
        val recentSentSet = settingsManager.getRecentSentReplies()
        val messages = scanVisibleWhatsAppMessages(settingsManager.getContextDepth().coerceAtLeast(5), rootNode, recentSentSet)
        if (messages.isEmpty()) {
            tvDetected.text = "কোনো চ্যাট মেসেজ পাওয়া যায়নি। আগে WhatsApp চ্যাট ওপেন করুন।"
            return
        }

        val latestIncoming = messages.lastOrNull { it.sender == "Incoming" }?.text
            ?: messages.last().text
        currentDetectedSnippet = latestIncoming
        tvDetected.text = "[$contactTitle] SMS: $latestIncoming"

        progress.visibility = View.VISIBLE
        tvContextLabel.text = "📤 Gemini-এর কাছে পাঠানো হয়েছে..."
        tvSmartReply.text = "উত্তর তৈরি হচ্ছে..."
        updateFloatingNotification("📤 Gemini-এর কাছে পাঠানো হয়েছে...", "#38BDF8", OrbVisualState.ACTIVE_STEP)

        activeJob?.cancel()
        activeJob = serviceScope.launch {
            val result = geminiClient.generateContextualReply(
                apiKey = apiKey,
                messages = messages.takeLast(5),
                languagePreference = settingsManager.getLanguagePreference(),
                excludedReplies = recentSentSet,
                contactName = contactTitle
            )
            currentReplyOption = result
            progress.visibility = View.GONE

            if (result.isSuccess && result.reply.isNotBlank()) {
                settingsManager.recordConnectionSuccess(result.modelUsed, result.latencyMs)
                tvContextLabel.text = "📥 রিপ্লাই গ্রহণ করা হয়েছে (${result.detectedContext})"
                tvSmartReply.text = result.reply
                updateFloatingNotification("📥 রিপ্লাই গ্রহণ করা হয়েছে!", "#2DD4BF", OrbVisualState.CONNECTED_IDLE)
            } else {
                val err = result.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                settingsManager.recordConnectionFailure(err)
                tvContextLabel.text = err
                tvSmartReply.text = result.detailedDiagnostics.ifBlank { "Gemini AI-এর সাথে সংযোগ করা যায়নি। অ্যাপের ভেতরে গিয়ে 'Save & Test Key' চাপুন।" }
                refreshIdleFloatingStatus()
            }
        }
    }

    private fun detectContactTitle(rootNode: AccessibilityNodeInfo): String {
        val titleIds = listOf(
            "com.whatsapp:id/conversation_contact_name",
            "com.whatsapp.w4b:id/conversation_contact_name",
            "com.whatsapp:id/toolbar_title",
            "com.whatsapp.w4b:id/toolbar_title"
        )
        for (id in titleIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                val name = found.first().text?.toString()?.trim()
                if (!name.isNullOrEmpty()) return name
            }
        }

        val screenHeight = resources.displayMetrics.heightPixels
        val candidates = mutableListOf<Pair<Int, String>>()
        collectTopHeaderTitles(rootNode, (screenHeight * 0.14f).toInt(), candidates)
        val best = candidates.minByOrNull { it.first }?.second
        return best ?: "ActiveChat"
    }

    private fun collectTopHeaderTitles(
        node: AccessibilityNodeInfo?,
        maxTopPx: Int,
        out: MutableList<Pair<Int, String>>
    ) {
        if (node == null) return
        val cls = node.className?.toString() ?: ""
        if (cls == "android.widget.TextView" && !node.isEditable) {
            val txt = node.text?.toString()?.trim() ?: ""
            if (txt.isNotEmpty() && txt.lowercase() !in setOf("online", "typing...", "অনলাইন", "টাইপ করছেন...")) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.top in 15..maxTopPx && rect.bottom <= maxTopPx + 60) {
                    out.add(Pair(rect.top, txt))
                }
            }
        }
        for (i in 0 until node.childCount) {
            collectTopHeaderTitles(node.getChild(i), maxTopPx, out)
        }
    }

    private fun isUserManuallyTyping(inputNode: AccessibilityNodeInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (inputNode.isShowingHintText) return false
        }
        val existing = inputNode.text?.toString()?.trim() ?: return false
        if (existing.isEmpty()) return false
        val commonHints = setOf("message", "type a message", "মেসেজ", "বার্তা লিখুন")
        return existing.lowercase() !in commonHints
    }

    private fun classifyMessageSender(
        node: AccessibilityNodeInfo,
        rect: Rect,
        screenWidth: Int,
        text: String,
        recentSentReplies: Set<String>
    ): String {
        if (text.equals(lastSentReplyText, ignoreCase = true)) return "Me"
        if (recentSentReplies.any { it.equals(text, ignoreCase = true) }) return "Me"

        val parent = node.parent
        if (parent != null) {
            val statusNodes = parent.findAccessibilityNodeInfosByViewId("com.whatsapp:id/status")
            if (!statusNodes.isNullOrEmpty()) return "Me"
            val w4bStatusNodes = parent.findAccessibilityNodeInfosByViewId("com.whatsapp.w4b:id/status")
            if (!w4bStatusNodes.isNullOrEmpty()) return "Me"
        }

        val maxIncomingLeftMargin = (screenWidth * 0.118f).toInt()
        return if (rect.left <= maxIncomingLeftMargin) "Incoming" else "Me"
    }

    private fun scanVisibleWhatsAppMessages(
        maxCount: Int,
        root: AccessibilityNodeInfo? = rootInActiveWindow,
        recentSentReplies: Set<String> = emptySet()
    ): List<ChatMessage> {
        val rootNode = root ?: return emptyList()
        val screenWidth = resources.displayMetrics.widthPixels
        val results = mutableListOf<ChatMessage>()

        val viewIds = listOf(
            "com.whatsapp:id/message_text",
            "com.whatsapp.w4b:id/message_text"
        )

        var nodes: List<AccessibilityNodeInfo> = emptyList()
        for (id in viewIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                nodes = found
                break
            }
        }

        if (nodes.isNotEmpty()) {
            val sortedItems = nodes.mapNotNull { node ->
                val text = node.text?.toString()?.trim()
                if (text.isNullOrEmpty()) null
                else {
                    val rect = Rect()
                    node.getBoundsInScreen(rect)
                    val sender = classifyMessageSender(node, rect, screenWidth, text, recentSentReplies)
                    Triple(rect.top, sender, text)
                }
            }.sortedBy { it.first }

            for ((_, sender, text) in sortedItems.takeLast(maxCount)) {
                results.add(ChatMessage(sender, text))
            }
        } else {
            collectFallbackTextNodes(rootNode, screenWidth, resources.displayMetrics.heightPixels, recentSentReplies, results)
        }

        return results.takeLast(maxCount)
    }

    private fun collectFallbackTextNodes(
        node: AccessibilityNodeInfo?,
        screenWidth: Int,
        screenHeight: Int,
        recentSentReplies: Set<String>,
        out: MutableList<ChatMessage>
    ) {
        if (node == null) return
        val className = node.className?.toString() ?: ""
        if (className == "android.widget.TextView" && !node.isEditable) {
            val txt = node.text?.toString()?.trim() ?: ""
            if (txt.length >= 2 && !txt.matches(Regex("^\\d{1,2}:\\d{2}\\s?(AM|PM|am|pm)?$"))) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.top > screenHeight / 6 && rect.bottom < (screenHeight * 0.86)) {
                    val sender = classifyMessageSender(node, rect, screenWidth, txt, recentSentReplies)
                    out.add(ChatMessage(sender, txt))
                }
            }
        }
        for (i in 0 until node.childCount) {
            collectFallbackTextNodes(node.getChild(i), screenWidth, screenHeight, recentSentReplies, out)
        }
    }

    private fun handleReplySelected(replyText: String, contextTag: String) {
        triggerHaptic()
        settingsManager.addRecentSentReply(replyText)
        if (settingsManager.isSaveHistoryEnabled()) {
            dbHelper.insertReply(
                ReplyHistoryItem(
                    incomingSnippet = currentDetectedSnippet.ifEmpty { "WhatsApp Chat" },
                    selectedReply = replyText,
                    tone = contextTag,
                    timestamp = System.currentTimeMillis()
                )
            )
        }

        val inserted = insertTextIntoWhatsApp(replyText)
        if (inserted) {
            floatingView?.findViewById<View>(R.id.panelReplyContainer)?.visibility = View.GONE
            if (settingsManager.isAutoSendEnabled()) {
                mainHandler.postDelayed({
                    val clicked = clickWhatsAppSendButton()
                    if (!clicked) {
                        mainHandler.postDelayed({ clickWhatsAppSendButton() }, 80L)
                    }
                }, 40L)
            }
        } else {
            copyToClipboard(replyText)
        }
    }

    private fun findWhatsAppInputNode(rootNode: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val entryIds = listOf("com.whatsapp:id/entry", "com.whatsapp.w4b:id/entry")
        for (id in entryIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                return found.first()
            }
        }
        return findFirstEditableNode(rootNode)
    }

    private fun insertTextIntoWhatsApp(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val inputNode = findWhatsAppInputNode(rootNode) ?: return false

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findFirstEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun clickWhatsAppSendButton(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val sendIds = listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")
        for (id in sendIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                return found.first().performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
        }
        return false
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("SR SmartReply", text))
        Toast.makeText(this, "Reply copied!", Toast.LENGTH_SHORT).show()
    }

    private fun triggerHaptic() {
        if (!settingsManager.isHapticEnabled()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(20)
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onInterrupt() {
        isServiceRunning = false
        hideFloatingOverlayImmediately()
    }

    override fun onDestroy() {
        isServiceRunning = false
        if (activeInstance == this) {
            activeInstance = null
        }
        hideFloatingOverlayImmediately()
        try {
            unregisterReceiver(systemNavigationReceiver)
        } catch (_: Exception) {
        }
        unlockNavigationJob?.cancel()
        serviceScope.cancel()
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        floatingView = null
        super.onDestroy()
    }
}
