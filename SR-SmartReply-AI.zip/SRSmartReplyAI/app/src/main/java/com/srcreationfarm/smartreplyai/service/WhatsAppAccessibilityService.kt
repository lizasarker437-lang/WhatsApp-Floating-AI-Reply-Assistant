package com.srcreationfarm.smartreplyai.service

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.ai.GeminiReplyClient
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyHistoryItem
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

class WhatsAppAccessibilityService : AccessibilityService() {

    private enum class OrbVisualState {
        CONNECTED_IDLE,
        ACTIVE_STEP,
        ERROR_DISCONNECTED,
        PAUSED
    }

    private lateinit var windowManager: WindowManager
    private lateinit var settingsManager: SettingsManager
    private lateinit var dbHelper: ReplyDatabaseHelper
    private val geminiClient = GeminiReplyClient()

    private var floatingView: View? = null
    private var windowParams: WindowManager.LayoutParams? = null

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var activeJob: Job? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var currentDetectedSnippet: String = ""
    private var currentReplyOption: ReplyOptions? = null

    // Anti-Loop & Fast Auto-Reply State Tracking
    private var lastRepliedSignature: String = ""
    private var lastSentReplyText: String = ""
    private var lastAutoReplyTimestamp: Long = 0L
    private var isProcessingAutoReply: Boolean = false
    private var lastObservedApiKey: String = ""

    private val autoScanRunnable = Runnable {
        checkAndTriggerAutoReply()
    }

    private val visibilityWatchdogRunnable = object : Runnable {
        override fun run() {
            val overlay = floatingView ?: return
            if (overlay.visibility == View.VISIBLE) {
                if (!settingsManager.isFloatingEnabled() || !isWhatsAppCurrentlyInForeground()) {
                    hideFloatingOverlayImmediately()
                } else {
                    if (!isProcessingAutoReply) {
                        refreshIdleFloatingStatus()
                    }
                    mainHandler.postDelayed(this, 350L)
                }
            }
        }
    }

    private val systemNavigationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_CLOSE_SYSTEM_DIALOGS,
                Intent.ACTION_SCREEN_OFF -> {
                    hideFloatingOverlayImmediately()
                }
            }
        }
    }

    companion object {
        @Volatile
        var isServiceRunning: Boolean = false
            private set

        private const val PKG_WHATSAPP = "com.whatsapp"
        private const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"
        private const val COOLDOWN_AFTER_SEND_MS = 1000L
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        settingsManager = SettingsManager.getInstance(this)
        dbHelper = ReplyDatabaseHelper(this)
        lastObservedApiKey = settingsManager.getApiKey()
        setupFloatingOverlay()

        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                addAction(Intent.ACTION_SCREEN_OFF)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(systemNavigationReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(systemNavigationReceiver, filter)
            }
        } catch (_: Exception) {
        }
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun setupFloatingOverlay() {
        if (floatingView != null) return

        val view = LayoutInflater.from(this).inflate(R.layout.layout_floating_ai, null)
        floatingView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = settingsManager.getOrbX()
            y = settingsManager.getOrbY()
        }
        windowParams = params

        val orbButton = view.findViewById<View>(R.id.btnFloatingOrb)
        val panelContainer = view.findViewById<View>(R.id.panelReplyContainer)
        val btnClosePanel = view.findViewById<View>(R.id.btnClosePanel)
        val btnRegenerate = view.findViewById<View>(R.id.btnRegenerateReply)
        val cardSmartReply = view.findViewById<View>(R.id.cardSmartReply)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var longPressTriggered = false

        val longPressRunnable = Runnable {
            if (!isDragging) {
                longPressTriggered = true
                triggerHaptic()
                if (panelContainer.visibility == View.VISIBLE) {
                    panelContainer.visibility = View.GONE
                } else {
                    panelContainer.visibility = View.VISIBLE
                    scanAndPopulateManualPanel()
                }
            }
        }

        orbButton.setOnTouchListener { _, event ->
            val currentParams = windowParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = currentParams.x
                    initialY = currentParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    longPressTriggered = false
                    mainHandler.postDelayed(longPressRunnable, 600L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (initialTouchX - event.rawX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    if (abs(deltaX) > 12 || abs(deltaY) > 12) {
                        isDragging = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    if (isDragging) {
                        currentParams.x = (initialX + deltaX).coerceAtLeast(0)
                        currentParams.y = (initialY + deltaY).coerceAtLeast(40)
                        try {
                            windowManager.updateViewLayout(view, currentParams)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (isDragging) {
                        settingsManager.saveOrbPosition(currentParams.x, currentParams.y)
                    } else if (!longPressTriggered) {
                        triggerHaptic()
                        val hasErr = settingsManager.getLastConnectionError().isNotBlank()
                        if (hasErr || settingsManager.getApiKey().isBlank() || !isNetworkConnected()) {
                            verifyConnectionAndNotify()
                        } else {
                            val newState = !settingsManager.isFullAutoReplyEnabled()
                            settingsManager.setFullAutoReplyEnabled(newState)
                            refreshIdleFloatingStatus()
                            val statusMsg = if (newState) {
                                "✅ Gemini অটো-রিপ্লাই চালু করা হয়েছে"
                            } else {
                                "⏸️ অটো-রিপ্লাই সাময়িকভাবে বন্ধ"
                            }
                            Toast.makeText(this, statusMsg, Toast.LENGTH_SHORT).show()
                            if (newState) {
                                lastRepliedSignature = ""
                                scheduleAutoScan(100L)
                            }
                        }
                    }
                    true
                }
                else -> false
            }
        }

        btnClosePanel.setOnClickListener {
            panelContainer.visibility = View.GONE
        }

        btnRegenerate.setOnClickListener {
            triggerHaptic()
            scanAndPopulateManualPanel()
        }

        cardSmartReply.setOnClickListener {
            currentReplyOption?.let { opt ->
                if (opt.isSuccess && opt.reply.isNotBlank()) {
                    serviceScope.launch {
                        updateFloatingNotification("🚀 রিপ্লাই দেওয়া হচ্ছে...", "#FBBF24", OrbVisualState.ACTIVE_STEP)
                        handleReplySelected(opt.reply, opt.detectedContext)
                        delay(450L)
                        updateFloatingNotification("✅ রিপ্লাই দেওয়া সম্পন্ন!", "#34D399", OrbVisualState.CONNECTED_IDLE)
                        delay(1100L)
                        refreshIdleFloatingStatus()
                    }
                }
            }
        }

        cardSmartReply.setOnLongClickListener {
            currentReplyOption?.let { opt ->
                if (opt.isSuccess && opt.reply.isNotBlank()) {
                    copyToClipboard(opt.reply)
                }
            }
            true
        }

        try {
            windowManager.addView(view, params)
            view.visibility = View.GONE
            refreshIdleFloatingStatus()
        } catch (_: Exception) {
        }
    }

    private fun isNetworkConnected(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    private fun verifyConnectionAndNotify() {
        val apiKey = settingsManager.getApiKey()
        if (apiKey.isBlank()) {
            settingsManager.recordConnectionFailure("⚠️ Gemini API Key নেই")
            refreshIdleFloatingStatus()
            Toast.makeText(this, "অ্যাপে গিয়ে Gemini API Key (AIzaSy...) সেট করুন", Toast.LENGTH_SHORT).show()
            return
        }
        if (!isNetworkConnected()) {
            settingsManager.recordConnectionFailure("⚠️ ইন্টারনেট সংযোগ নেই")
            refreshIdleFloatingStatus()
            Toast.makeText(this, "ইন্টারনেট সংযোগ চালু করুন", Toast.LENGTH_SHORT).show()
            return
        }

        updateFloatingNotification("🔄 Gemini কানেকশন চেক হচ্ছে...", "#38BDF8", OrbVisualState.ACTIVE_STEP)
        serviceScope.launch {
            val res = geminiClient.verifyGeminiConnection(apiKey, "Assalamu Alaikum")
            if (res.isSuccess) {
                settingsManager.recordConnectionSuccess(res.modelUsed, res.latencyMs)
                settingsManager.setFullAutoReplyEnabled(true)
                refreshIdleFloatingStatus()
                Toast.makeText(this@WhatsAppAccessibilityService, "✅ Gemini সংযুক্ত (${res.modelUsed})", Toast.LENGTH_SHORT).show()
                lastRepliedSignature = ""
                scheduleAutoScan(120L)
            } else {
                val err = res.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                settingsManager.recordConnectionFailure(err)
                refreshIdleFloatingStatus()
                Toast.makeText(this@WhatsAppAccessibilityService, err, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun updateFloatingNotification(
        message: String,
        textColorHex: String,
        orbState: OrbVisualState
    ) {
        val view = floatingView ?: return
        val badge = view.findViewById<TextView>(R.id.tvFloatingStatusBadge) ?: return
        val orb = view.findViewById<View>(R.id.btnFloatingOrb) ?: return

        badge.text = message
        try {
            badge.setTextColor(Color.parseColor(textColorHex))
        } catch (_: Exception) {
        }

        val bgRes = when (orbState) {
            OrbVisualState.CONNECTED_IDLE -> R.drawable.bg_floating_pill
            OrbVisualState.ACTIVE_STEP -> R.drawable.bg_floating_pill_active
            OrbVisualState.ERROR_DISCONNECTED -> R.drawable.bg_floating_pill_error
            OrbVisualState.PAUSED -> R.drawable.bg_floating_pill
        }
        orb.setBackgroundResource(bgRes)
    }

    private fun refreshIdleFloatingStatus() {
        val apiKey = settingsManager.getApiKey()
        if (apiKey != lastObservedApiKey) {
            lastObservedApiKey = apiKey
            lastRepliedSignature = ""
        }

        if (apiKey.isBlank()) {
            updateFloatingNotification(
                "⚠️ Gemini API Key নেই",
                "#F87171",
                OrbVisualState.ERROR_DISCONNECTED
            )
            return
        }

        if (!isNetworkConnected()) {
            updateFloatingNotification(
                "⚠️ ইন্টারনেট সংযোগ নেই",
                "#F87171",
                OrbVisualState.ERROR_DISCONNECTED
            )
            return
        }

        val savedError = settingsManager.getLastConnectionError()
        if (savedError.isNotBlank() && !settingsManager.isGeminiConnected()) {
            updateFloatingNotification(
                savedError,
                "#F87171",
                OrbVisualState.ERROR_DISCONNECTED
            )
            return
        }

        if (!settingsManager.isFullAutoReplyEnabled()) {
            updateFloatingNotification(
                "⏸️ অটো-রিপ্লাই বন্ধ",
                "#FBBF24",
                OrbVisualState.PAUSED
            )
            return
        }

        updateFloatingNotification(
            "✅ Gemini সংযুক্ত",
            "#34D399",
            OrbVisualState.CONNECTED_IDLE
        )
    }

    private fun isSupportedWhatsAppPackage(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        return pkg == PKG_WHATSAPP ||
                (pkg == PKG_WHATSAPP_BUSINESS && settingsManager.isWhatsAppBusinessEnabled())
    }

    private fun isInputMethodPackage(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        val lower = pkg.lowercase()
        if (listOf("inputmethod", "keyboard", "honeyboard", "swiftkey", "ridmik", "gboard", "latin").any { lower.contains(it) }) {
            return true
        }
        return try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.enabledInputMethodList?.any { it.packageName == pkg } == true
        } catch (_: Exception) {
            false
        }
    }

    private fun isWhatsAppCurrentlyInForeground(): Boolean {
        try {
            val windowList = windows
            if (!windowList.isNullOrEmpty()) {
                val appWindows = windowList.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                if (appWindows.isNotEmpty()) {
                    val activeAppWindow = appWindows.firstOrNull { it.isActive || it.isFocused } ?: appWindows.first()
                    val appPkg = activeAppWindow.root?.packageName?.toString()
                    if (appPkg != null) {
                        return isSupportedWhatsAppPackage(appPkg)
                    }
                    return appWindows.any { isSupportedWhatsAppPackage(it.root?.packageName?.toString()) }
                }
            }
        } catch (_: Exception) {
        }

        val activeRootPkg = rootInActiveWindow?.packageName?.toString() ?: return false
        return isSupportedWhatsAppPackage(activeRootPkg)
    }

    private fun showFloatingOverlayIfAllowed() {
        val overlay = floatingView ?: return
        if (!settingsManager.isFloatingEnabled()) {
            hideFloatingOverlayImmediately()
            return
        }
        if (overlay.visibility != View.VISIBLE) {
            overlay.visibility = View.VISIBLE
            if (!isProcessingAutoReply) {
                refreshIdleFloatingStatus()
            }
        }
        mainHandler.removeCallbacks(visibilityWatchdogRunnable)
        mainHandler.postDelayed(visibilityWatchdogRunnable, 350L)
    }

    private fun hideFloatingOverlayImmediately() {
        mainHandler.removeCallbacks(autoScanRunnable)
        mainHandler.removeCallbacks(visibilityWatchdogRunnable)
        activeJob?.cancel()
        isProcessingAutoReply = false
        floatingView?.findViewById<View>(R.id.panelReplyContainer)?.visibility = View.GONE
        floatingView?.visibility = View.GONE
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val eventPkg = event.packageName?.toString() ?: ""
        if (eventPkg == packageName) return

        if (isSupportedWhatsAppPackage(eventPkg)) {
            showFloatingOverlayIfAllowed()
            if (settingsManager.isFullAutoReplyEnabled()) {
                scheduleAutoScan(settingsManager.getAutoReplyDelayMs())
            }
            return
        }

        if (isInputMethodPackage(eventPkg)) {
            if (!isWhatsAppCurrentlyInForeground()) {
                hideFloatingOverlayImmediately()
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED
        ) {
            if (!isWhatsAppCurrentlyInForeground()) {
                hideFloatingOverlayImmediately()
            }
        } else if (!isWhatsAppCurrentlyInForeground()) {
            hideFloatingOverlayImmediately()
        }
    }

    private fun scheduleAutoScan(delayMs: Long) {
        mainHandler.removeCallbacks(autoScanRunnable)
        mainHandler.postDelayed(autoScanRunnable, delayMs)
    }

    private fun checkAndTriggerAutoReply() {
        if (!settingsManager.isFullAutoReplyEnabled()) return
        if (isProcessingAutoReply) return

        if (!isWhatsAppCurrentlyInForeground()) {
            hideFloatingOverlayImmediately()
            return
        }

        val apiKey = settingsManager.getApiKey()
        if (apiKey.isBlank()) {
            settingsManager.recordConnectionFailure("⚠️ Gemini API Key নেই")
            refreshIdleFloatingStatus()
            return
        }
        if (!isNetworkConnected()) {
            settingsManager.recordConnectionFailure("⚠️ ইন্টারনেট সংযোগ নেই")
            refreshIdleFloatingStatus()
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastAutoReplyTimestamp < COOLDOWN_AFTER_SEND_MS) {
            return
        }

        val rootNode = rootInActiveWindow ?: return
        val pkg = rootNode.packageName?.toString() ?: return
        if (!isSupportedWhatsAppPackage(pkg)) {
            hideFloatingOverlayImmediately()
            return
        }

        val inputNode = findWhatsAppInputNode(rootNode) ?: return
        if (isUserManuallyTyping(inputNode)) return

        val recentSentSet = settingsManager.getRecentSentReplies()
        val contextDepth = settingsManager.getContextDepth().coerceAtLeast(5)
        val messages = scanVisibleWhatsAppMessages(contextDepth, rootNode, recentSentSet)
        if (messages.isEmpty()) return

        val lastMessage = messages.last()
        if (lastMessage.sender != "Incoming") return

        val incomingText = lastMessage.text.trim()
        if (incomingText.isEmpty() || incomingText.equals(lastSentReplyText, ignoreCase = true)) return
        if (recentSentSet.any { it.equals(incomingText, ignoreCase = true) }) return

        val contactTitle = detectContactTitle(rootNode)
        val incomingCount = messages.count { it.sender == "Incoming" }
        val signature = "$contactTitle::$incomingText::$incomingCount"

        if (signature == lastRepliedSignature) return

        isProcessingAutoReply = true
        lastRepliedSignature = signature
        currentDetectedSnippet = incomingText

        // STEP 1 NOTIFICATION: Sent to Gemini AI
        updateFloatingNotification(
            "📤 Gemini-এর কাছে পাঠানো হয়েছে...",
            "#38BDF8",
            OrbVisualState.ACTIVE_STEP
        )

        activeJob?.cancel()
        activeJob = serviceScope.launch {
            try {
                val result = geminiClient.generateContextualReply(
                    apiKey = apiKey,
                    messages = messages.takeLast(5),
                    languagePreference = settingsManager.getLanguagePreference(),
                    excludedReplies = recentSentSet
                )

                val replyToSend = result.reply.trim()
                if (result.isSuccess && replyToSend.isNotBlank() && isWhatsAppCurrentlyInForeground()) {
                    settingsManager.recordConnectionSuccess(result.modelUsed, result.latencyMs)

                    // STEP 2 NOTIFICATION: Reply received from Gemini AI
                    updateFloatingNotification(
                        "📥 রিপ্লাই গ্রহণ করা হয়েছে!",
                        "#2DD4BF",
                        OrbVisualState.ACTIVE_STEP
                    )
                    delay(450L)

                    if (!isWhatsAppCurrentlyInForeground()) {
                        hideFloatingOverlayImmediately()
                        return@launch
                    }

                    // STEP 3 NOTIFICATION: Sending reply to WhatsApp
                    updateFloatingNotification(
                        "🚀 রিপ্লাই দেওয়া হচ্ছে...",
                        "#FBBF24",
                        OrbVisualState.ACTIVE_STEP
                    )

                    lastSentReplyText = replyToSend
                    lastAutoReplyTimestamp = System.currentTimeMillis()
                    settingsManager.addRecentSentReply(replyToSend)
                    handleReplySelected(replyToSend, result.detectedContext)

                    delay(450L)

                    // STEP 4 NOTIFICATION: Reply sent completed
                    if (isWhatsAppCurrentlyInForeground()) {
                        updateFloatingNotification(
                            "✅ রিপ্লাই দেওয়া সম্পন্ন!",
                            "#34D399",
                            OrbVisualState.CONNECTED_IDLE
                        )
                        delay(1100L)
                    }
                } else {
                    val err = result.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                    settingsManager.recordConnectionFailure(err)
                    lastRepliedSignature = ""
                    updateFloatingNotification(
                        err,
                        "#F87171",
                        OrbVisualState.ERROR_DISCONNECTED
                    )
                    delay(1800L)
                }
            } catch (_: Exception) {
                settingsManager.recordConnectionFailure("⚠️ Gemini সংযোগে সমস্যা")
                lastRepliedSignature = ""
            } finally {
                isProcessingAutoReply = false
                if (isWhatsAppCurrentlyInForeground()) {
                    refreshIdleFloatingStatus()
                } else {
                    hideFloatingOverlayImmediately()
                }
            }
        }
    }

    private fun scanAndPopulateManualPanel() {
        val view = floatingView ?: return
        val tvDetected = view.findViewById<TextView>(R.id.tvDetectedMessage)
        val progress = view.findViewById<ProgressBar>(R.id.progressAiLoading)
        val tvContextLabel = view.findViewById<TextView>(R.id.tvDetectedContextLabel)
        val tvSmartReply = view.findViewById<TextView>(R.id.tvSmartReplyText)

        val apiKey = settingsManager.getApiKey()
        if (apiKey.isBlank()) {
            settingsManager.recordConnectionFailure("⚠️ Gemini API Key নেই")
            refreshIdleFloatingStatus()
            tvDetected.text = "সংযোগ নেই"
            tvContextLabel.text = "⚠️ Gemini API Key সেট করা নেই"
            tvSmartReply.text = "অ্যাপের ড্যাশবোর্ডে গিয়ে আপনার Gemini API Key (AIzaSy...) পেস্ট করে 'Save & Test Key' চাপুন।"
            return
        }

        if (!isNetworkConnected()) {
            settingsManager.recordConnectionFailure("⚠️ ইন্টারনেট সংযোগ নেই")
            refreshIdleFloatingStatus()
            tvDetected.text = "সংযোগ নেই"
            tvContextLabel.text = "⚠️ ইন্টারনেট সংযোগ নেই"
            tvSmartReply.text = "ফোনের ডাটা বা ওয়াইফাই চালু করুন।"
            return
        }

        val rootNode = rootInActiveWindow
        val recentSentSet = settingsManager.getRecentSentReplies()
        val messages = scanVisibleWhatsAppMessages(settingsManager.getContextDepth().coerceAtLeast(5), rootNode, recentSentSet)
        if (messages.isEmpty()) {
            tvDetected.text = "কোনো চ্যাট মেসেজ পাওয়া যায়নি। আগে WhatsApp চ্যাট ওপেন করুন।"
            return
        }

        val latestIncoming = messages.lastOrNull { it.sender == "Incoming" }?.text
            ?: messages.last().text
        currentDetectedSnippet = latestIncoming
        tvDetected.text = "SMS: $latestIncoming"

        progress.visibility = View.VISIBLE
        tvContextLabel.text = "📤 Gemini-এর কাছে পাঠানো হয়েছে..."
        tvSmartReply.text = "উত্তর তৈরি হচ্ছে..."
        updateFloatingNotification("📤 Gemini-এর কাছে পাঠানো হয়েছে...", "#38BDF8", OrbVisualState.ACTIVE_STEP)

        activeJob?.cancel()
        activeJob = serviceScope.launch {
            val result = geminiClient.generateContextualReply(
                apiKey = apiKey,
                messages = messages.takeLast(5),
                languagePreference = settingsManager.getLanguagePreference(),
                excludedReplies = recentSentSet
            )
            currentReplyOption = result
            progress.visibility = View.GONE

            if (result.isSuccess && result.reply.isNotBlank()) {
                settingsManager.recordConnectionSuccess(result.modelUsed, result.latencyMs)
                tvContextLabel.text = "📥 রিপ্লাই গ্রহণ করা হয়েছে (${result.detectedContext})"
                tvSmartReply.text = result.reply
                updateFloatingNotification("📥 রিপ্লাই গ্রহণ করা হয়েছে!", "#2DD4BF", OrbVisualState.CONNECTED_IDLE)
            } else {
                val err = result.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                settingsManager.recordConnectionFailure(err)
                tvContextLabel.text = err
                tvSmartReply.text = result.detailedDiagnostics.ifBlank { "Gemini AI-এর সাথে সংযোগ করা যায়নি। অ্যাপের ভেতরে গিয়ে 'Save & Test Key' চাপুন।" }
                refreshIdleFloatingStatus()
            }
        }
    }

    private fun detectContactTitle(rootNode: AccessibilityNodeInfo): String {
        val titleIds = listOf(
            "com.whatsapp:id/conversation_contact_name",
            "com.whatsapp.w4b:id/conversation_contact_name"
        )
        for (id in titleIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                val name = found.first().text?.toString()?.trim()
                if (!name.isNullOrEmpty()) return name
            }
        }
        return "ActiveChat"
    }

    private fun isUserManuallyTyping(inputNode: AccessibilityNodeInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (inputNode.isShowingHintText) return false
        }
        val existing = inputNode.text?.toString()?.trim() ?: return false
        if (existing.isEmpty()) return false
        val commonHints = setOf("message", "type a message", "মেসেজ", "বার্তা লিখুন")
        return existing.lowercase() !in commonHints
    }

    private fun classifyMessageSender(
        node: AccessibilityNodeInfo,
        rect: Rect,
        screenWidth: Int,
        text: String,
        recentSentReplies: Set<String>
    ): String {
        if (text.equals(lastSentReplyText, ignoreCase = true)) return "Me"
        if (recentSentReplies.any { it.equals(text, ignoreCase = true) }) return "Me"

        val parent = node.parent
        if (parent != null) {
            val statusNodes = parent.findAccessibilityNodeInfosByViewId("com.whatsapp:id/status")
            if (!statusNodes.isNullOrEmpty()) return "Me"
            val w4bStatusNodes = parent.findAccessibilityNodeInfosByViewId("com.whatsapp.w4b:id/status")
            if (!w4bStatusNodes.isNullOrEmpty()) return "Me"
        }

        val maxIncomingLeftMargin = (screenWidth * 0.118f).toInt()
        return if (rect.left <= maxIncomingLeftMargin) "Incoming" else "Me"
    }

    private fun scanVisibleWhatsAppMessages(
        maxCount: Int,
        root: AccessibilityNodeInfo? = rootInActiveWindow,
        recentSentReplies: Set<String> = emptySet()
    ): List<ChatMessage> {
        val rootNode = root ?: return emptyList()
        val screenWidth = resources.displayMetrics.widthPixels
        val results = mutableListOf<ChatMessage>()

        val viewIds = listOf(
            "com.whatsapp:id/message_text",
            "com.whatsapp.w4b:id/message_text"
        )

        var nodes: List<AccessibilityNodeInfo> = emptyList()
        for (id in viewIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                nodes = found
                break
            }
        }

        if (nodes.isNotEmpty()) {
            val sortedItems = nodes.mapNotNull { node ->
                val text = node.text?.toString()?.trim()
                if (text.isNullOrEmpty()) null
                else {
                    val rect = Rect()
                    node.getBoundsInScreen(rect)
                    val sender = classifyMessageSender(node, rect, screenWidth, text, recentSentReplies)
                    Triple(rect.top, sender, text)
                }
            }.sortedBy { it.first }

            for ((_, sender, text) in sortedItems.takeLast(maxCount)) {
                results.add(ChatMessage(sender, text))
            }
        } else {
            collectFallbackTextNodes(rootNode, screenWidth, resources.displayMetrics.heightPixels, recentSentReplies, results)
        }

        return results.takeLast(maxCount)
    }

    private fun collectFallbackTextNodes(
        node: AccessibilityNodeInfo?,
        screenWidth: Int,
        screenHeight: Int,
        recentSentReplies: Set<String>,
        out: MutableList<ChatMessage>
    ) {
        if (node == null) return
        val className = node.className?.toString() ?: ""
        if (className == "android.widget.TextView" && !node.isEditable) {
            val txt = node.text?.toString()?.trim() ?: ""
            if (txt.length >= 2 && !txt.matches(Regex("^\\d{1,2}:\\d{2}\\s?(AM|PM|am|pm)?$"))) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.top > screenHeight / 6 && rect.bottom < (screenHeight * 0.86)) {
                    val sender = classifyMessageSender(node, rect, screenWidth, txt, recentSentReplies)
                    out.add(ChatMessage(sender, txt))
                }
            }
        }
        for (i in 0 until node.childCount) {
            collectFallbackTextNodes(node.getChild(i), screenWidth, screenHeight, recentSentReplies, out)
        }
    }

    private fun handleReplySelected(replyText: String, contextTag: String) {
        triggerHaptic()
        settingsManager.addRecentSentReply(replyText)
        if (settingsManager.isSaveHistoryEnabled()) {
            dbHelper.insertReply(
                ReplyHistoryItem(
                    incomingSnippet = currentDetectedSnippet.ifEmpty { "WhatsApp Chat" },
                    selectedReply = replyText,
                    tone = contextTag,
                    timestamp = System.currentTimeMillis()
                )
            )
        }

        val inserted = insertTextIntoWhatsApp(replyText)
        if (inserted) {
            floatingView?.findViewById<View>(R.id.panelReplyContainer)?.visibility = View.GONE
            if (settingsManager.isAutoSendEnabled()) {
                mainHandler.postDelayed({
                    val clicked = clickWhatsAppSendButton()
                    if (!clicked) {
                        mainHandler.postDelayed({ clickWhatsAppSendButton() }, 90L)
                    }
                }, 70L)
            }
        } else {
            copyToClipboard(replyText)
        }
    }

    private fun findWhatsAppInputNode(rootNode: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val entryIds = listOf("com.whatsapp:id/entry", "com.whatsapp.w4b:id/entry")
        for (id in entryIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                return found.first()
            }
        }
        return findFirstEditableNode(rootNode)
    }

    private fun insertTextIntoWhatsApp(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val inputNode = findWhatsAppInputNode(rootNode) ?: return false

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findFirstEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun clickWhatsAppSendButton(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val sendIds = listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")
        for (id in sendIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                return found.first().performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
        }
        return false
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("SR SmartReply", text))
        Toast.makeText(this, "Reply copied!", Toast.LENGTH_SHORT).show()
    }

    private fun triggerHaptic() {
        if (!settingsManager.isHapticEnabled()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(25)
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onInterrupt() {
        isServiceRunning = false
        hideFloatingOverlayImmediately()
    }

    override fun onDestroy() {
        isServiceRunning = false
        hideFloatingOverlayImmediately()
        try {
            unregisterReceiver(systemNavigationReceiver)
        } catch (_: Exception) {
        }
        serviceScope.cancel()
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        floatingView = null
        super.onDestroy()
    }
}
