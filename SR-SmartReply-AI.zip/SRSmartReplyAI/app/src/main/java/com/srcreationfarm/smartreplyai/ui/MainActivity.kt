package com.srcreationfarm.smartreplyai.ui

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.srcreationfarm.smartreplyai.BuildConfig
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.ai.GeminiReplyClient
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.manager.ThemeManager
import com.srcreationfarm.smartreplyai.service.WhatsAppAccessibilityService
import com.srcreationfarm.smartreplyai.service.WhatsAppNotificationListener
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var settingsManager: SettingsManager
    private lateinit var dbHelper: ReplyDatabaseHelper
    private val geminiClient = GeminiReplyClient()
    private var appliedThemeName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settingsManager = SettingsManager.getInstance(this)
        dbHelper = ReplyDatabaseHelper(this)
        appliedThemeName = settingsManager.getColorTheme()

        setupToolbar()
        setupControls()
        setupGeminiTestConsole()
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeName != settingsManager.getColorTheme()) {
            recreate()
            return
        }
        refreshDashboardStatus()
    }

    private fun setupToolbar() {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.action_pin_unlock -> {
                    showPinAndTargetDialog()
                    true
                }
                R.id.action_api_key -> {
                    showQuickApiKeyDialog()
                    true
                }
                R.id.action_automation -> {
                    showAutomationControlsDialog()
                    true
                }
                R.id.action_theme -> {
                    showThemePickerDialog()
                    true
                }
                R.id.action_permissions -> {
                    showPermissionsMenuDialog()
                    true
                }
                R.id.action_history -> {
                    startActivity(Intent(this, HistoryActivity::class.java))
                    true
                }
                R.id.action_about -> {
                    startActivity(Intent(this, AboutActivity::class.java))
                    true
                }
                R.id.action_privacy -> {
                    showPrivacyHelpDialog()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupControls() {
        findViewById<MaterialButton>(R.id.btnEnableAccessibility).setOnClickListener {
            openAccessibilitySettings()
        }

        findViewById<MaterialButton>(R.id.btnEnableNotificationAccess).setOnClickListener {
            openNotificationListenerSettings()
        }

        findViewById<MaterialButton>(R.id.btnOpenThreeDotSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnTestLaunchAndSearch).setOnClickListener {
            if (!isAccessibilityServiceEnabled(this)) {
                Toast.makeText(this, "আগে 'Accessibility' বাটনে ট্যাপ করে সার্ভিসটি অন করুন!", Toast.LENGTH_LONG).show()
                openAccessibilitySettings()
                return@setOnClickListener
            }
            val query = settingsManager.getTargetContactQuery()
            Toast.makeText(this, "🚀 WhatsApp ওপেন করা হচ্ছে...", Toast.LENGTH_SHORT).show()
            WhatsAppAccessibilityService.triggerTestLaunchAndFindContact(query)
        }

        findViewById<MaterialButton>(R.id.btnOpenHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnFooterYoutube).setOnClickListener {
            openExternalUrl(getString(R.string.youtube_url))
        }

        findViewById<MaterialButton>(R.id.btnFooterFacebook).setOnClickListener {
            openExternalUrl(getString(R.string.facebook_url))
        }

        findViewById<MaterialButton>(R.id.btnFooterAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        findViewById<TextView>(R.id.tvAppVersion).text =
            "v${BuildConfig.VERSION_NAME} • © 2026 SR Creation Farm"
    }

    private fun setupGeminiTestConsole() {
        val etTestSms = findViewById<EditText>(R.id.etTestIncomingSms)
        val btnRunLiveTest = findViewById<MaterialButton>(R.id.btnRunLiveReplyTest)

        btnRunLiveTest.setOnClickListener {
            val savedKey = settingsManager.getApiKey()
            val sampleSms = etTestSms.text?.toString()?.trim().orEmpty().ifBlank { "Assalamu Alaikum, kemon acho?" }
            runLiveGeminiConnectionTest(savedKey, sampleSms, showPopup = false)
        }
    }

    private fun showPinAndTargetDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (18 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }

        val etPin = EditText(this).apply {
            hint = "ফোনের লক স্ক্রিন পিন (যেমন: 1234)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setText(settingsManager.getPhoneLockPin())
        }

        val etTarget = EditText(this).apply {
            hint = "নির্দিষ্ট নাম বা নাম্বার (ঐচ্ছিক, যেমন: SR)"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(settingsManager.getTargetContactQuery())
        }

        layout.addView(etPin)
        layout.addView(etTarget)

        AlertDialog.Builder(this)
            .setTitle("🔓 পিন লক ও টার্গেট সেটিংস")
            .setMessage("হোয়াটসঅ্যাপে নোটিফিকেশন আসামাত্র ফোনের লক খুলে হোয়াটসঅ্যাপ ওপেন করার জন্য আপনার পিন দিন:")
            .setView(layout)
            .setPositiveButton("💾 সেভ করুন") { _, _ ->
                val pinVal = etPin.text.toString().trim()
                val targetVal = etTarget.text.toString().trim()
                settingsManager.setPhoneLockPin(pinVal)
                settingsManager.setAutoUnlockAndOpenEnabled(true)
                if (targetVal.isEmpty()) {
                    settingsManager.setTargetContactQuery("")
                    settingsManager.setTargetFilterEnabled(false)
                } else {
                    settingsManager.setTargetContactQuery(targetVal)
                    settingsManager.setTargetFilterEnabled(true)
                }
                refreshDashboardStatus()
                Toast.makeText(this, "✅ পিন লক ও টার্গেট সেভ হয়েছে!", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("সব সেটিংস") { _, _ ->
                startActivity(Intent(this, SettingsActivity::class.java))
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showQuickApiKeyDialog() {
        val input = EditText(this).apply {
            hint = "Paste Gemini API Key (AQ... / AIzaSy...)"
            setText(settingsManager.getApiKey())
        }
        AlertDialog.Builder(this)
            .setTitle("🔑 Google Gemini API Key")
            .setMessage("আপনার Gemini API Key দিন এবং সংযোগ পরীক্ষা করুন:")
            .setView(input)
            .setPositiveButton("Save & Verify") { _, _ ->
                val newKey = SettingsManager.sanitizeApiKey(input.text.toString())
                settingsManager.setApiKey(newKey)
                val sampleSms = findViewById<EditText>(R.id.etTestIncomingSms)?.text?.toString()?.trim()
                    .orEmpty().ifBlank { "Assalamu Alaikum, kemon acho?" }
                runLiveGeminiConnectionTest(newKey, sampleSms, showPopup = true)
            }
            .setNeutralButton("Get Free Key") { _, _ ->
                openExternalUrl("https://aistudio.google.com/app/apikey")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAutomationControlsDialog() {
        val labels = arrayOf(
            "নোটিফিকেশন আসলে পিন দিয়ে অটো লক খুলবে ও WhatsApp ওপেন করবে",
            "Auto-Read & Instant AI Reply (মেসেজ পড়ে সাথে সাথে উত্তর)",
            "Show Floating AI Status Button on WhatsApp",
            "Auto-Press Send Button (অটোমেটিক সেন্ড)",
            "Support WhatsApp Business"
        )
        val checkedItems = booleanArrayOf(
            settingsManager.isAutoUnlockAndOpenEnabled(),
            settingsManager.isFullAutoReplyEnabled(),
            settingsManager.isFloatingEnabled(),
            settingsManager.isAutoSendEnabled(),
            settingsManager.isWhatsAppBusinessEnabled()
        )

        AlertDialog.Builder(this)
            .setTitle("🤖 Automation & Assistant Controls")
            .setMultiChoiceItems(labels, checkedItems) { _, which, isChecked ->
                when (which) {
                    0 -> settingsManager.setAutoUnlockAndOpenEnabled(isChecked)
                    1 -> settingsManager.setFullAutoReplyEnabled(isChecked)
                    2 -> settingsManager.setFloatingEnabled(isChecked)
                    3 -> settingsManager.setAutoSendEnabled(isChecked)
                    4 -> settingsManager.setWhatsAppBusinessEnabled(isChecked)
                }
            }
            .setPositiveButton("Save") { _, _ ->
                refreshDashboardStatus()
                Toast.makeText(this, "✅ অটোমেশন সেটিংস সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("All Settings") { _, _ ->
                startActivity(Intent(this, SettingsActivity::class.java))
            }
            .show()
    }

    private fun showPermissionsMenuDialog() {
        val items = arrayOf(
            "1. Enable Accessibility Service",
            "2. Enable Notification Access (নোটিফিকেশন ডিটেক্টর)",
            "3. Disable Battery Optimization",
            "4. Open App Info (Allow Restricted / Lock Screen)"
        )
        AlertDialog.Builder(this)
            .setTitle("🛡️ Permissions & Setup")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> openAccessibilitySettings()
                    1 -> openNotificationListenerSettings()
                    2 -> {
                        try {
                            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        } catch (_: Exception) {
                        }
                    }
                    3 -> {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.parse("package:$packageName")
                            }
                            startActivity(intent)
                        } catch (_: Exception) {
                        }
                    }
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun runLiveGeminiConnectionTest(
        apiKey: String,
        sampleSms: String,
        showPopup: Boolean
    ) {
        val tvBanner = findViewById<TextView>(R.id.tvConnectionBanner)
        val tvResult = findViewById<TextView>(R.id.tvLiveTestResult)
        val progress = findViewById<ProgressBar>(R.id.progressConnectionTest)

        if (apiKey.length < 10) {
            settingsManager.recordConnectionFailure("⚠️ Gemini API Key নেই")
            tvBanner.text = "❌ স্ট্যাটাস: কানেক্টেড নয় (⋮ মেনু থেকে API Key দিন)"
            tvBanner.setTextColor(Color.parseColor("#EF4444"))
            tvResult.text = "❌ পরীক্ষা ব্যর্থ: ওপরের থ্রি-ডট (⋮) মেনু থেকে আপনার Gemini API Key সেভ করুন।"
            return
        }

        progress.visibility = View.VISIBLE
        tvBanner.text = "🔄 Gemini AI সংযোগ পরীক্ষা করা হচ্ছে..."
        tvBanner.setTextColor(Color.parseColor("#38BDF8"))
        tvResult.text = "📤 টেস্ট মেসেজ পাঠানো হচ্ছে: \"$sampleSms\"..."

        lifecycleScope.launch {
            val res = geminiClient.verifyGeminiConnection(apiKey, sampleSms)
            progress.visibility = View.GONE

            if (res.isSuccess && res.reply.isNotBlank()) {
                val usedModel = res.modelUsed.ifBlank { "gemini-2.5-flash" }
                settingsManager.recordConnectionSuccess(usedModel, res.latencyMs)
                tvBanner.text = "✅ Gemini AI সফলভাবে কানেক্টেড! ($usedModel • ${res.latencyMs}ms)"
                tvBanner.setTextColor(Color.parseColor("#10B981"))

                val resultSummary = "✅ সংযোগ পরীক্ষা ১০০% সফল!\n" +
                        "🤖 সক্রিয় মডেল: $usedModel (রেসপন্স সময়: ${res.latencyMs}ms)\n" +
                        "💬 পরীক্ষামূলক মেসেজ: \"$sampleSms\"\n" +
                        "✨ Gemini AI-এর উত্তর: \"${res.reply}\""
                tvResult.text = resultSummary
                refreshDashboardStatus()

                if (showPopup) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("✅ Gemini সংযোগ সফল!")
                        .setMessage(resultSummary)
                        .setPositiveButton("OK", null)
                        .show()
                }
            } else {
                val errTitle = res.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                settingsManager.recordConnectionFailure(errTitle)
                tvBanner.text = "❌ কানেক্টেড নয়: $errTitle"
                tvBanner.setTextColor(Color.parseColor("#EF4444"))
                tvResult.text = "❌ সংযোগ পরীক্ষা ব্যর্থ ($errTitle)\n🔍 ${res.detailedDiagnostics}"
            }
        }
    }

    private fun refreshDashboardStatus() {
        val accEnabled = isAccessibilityServiceEnabled(this)
        val notifEnabled = isNotificationListenerEnabled(this)
        val tvTitle = findViewById<TextView>(R.id.tvServiceStatusTitle)
        val tvSub = findViewById<TextView>(R.id.tvServiceStatusSubtitle)
        val tvSummary = findViewById<TextView>(R.id.tvDashboardSummary)
        val tvBanner = findViewById<TextView>(R.id.tvConnectionBanner)
        val savedKey = settingsManager.getApiKey()

        if (savedKey.length < 10) {
            tvBanner.text = "❌ স্ট্যাটাস: কোনো Gemini API Key সেট করা নেই"
            tvBanner.setTextColor(Color.parseColor("#EF4444"))
        } else {
            val model = settingsManager.getConnectedModel().ifBlank { "gemini-2.5-flash" }
            val ms = settingsManager.getLastLatencyMs()
            tvBanner.text = "✅ স্ট্যাটাস: Gemini AI সফলভাবে কানেক্টেড! ($model • ${ms}ms)"
            tvBanner.setTextColor(Color.parseColor("#10B981"))
        }

        val notifStatus = if (notifEnabled) "Notification: ON" else "Notification: OFF"
        if (accEnabled && notifEnabled) {
            tvTitle.text = "✅ Auto-Unlock & AI Service: Active"
            tvSub.text = "নোটিফিকেশন আসামাত্র পিন আনলক ও হোয়াটসঅ্যাপ ওপেন প্রস্তুত"
        } else if (accEnabled) {
            tvTitle.text = "⚠️ Accessibility: ON • $notifStatus"
            tvSub.text = "লক স্ক্রিনে নোটিফিকেশন ধরার জন্য 'Notification Access' বাটনে ট্যাপ করে অন করুন।"
        } else {
            tvTitle.text = "⚠️ Accessibility: OFF • $notifStatus"
            tvSub.text = "অটো পিন আনলক ও রিপ্লাই চালু করতে নিচের দুটি পারমিশন বাটন অন করুন।"
        }

        val pinVal = settingsManager.getPhoneLockPin()
        val pinStatus = if (settingsManager.isAutoUnlockAndOpenEnabled() && pinVal.isNotEmpty()) {
            "🔓 অটো পিন আনলক: চালু (${pinVal.length} ডিজিট পিন সেভ করা আছে)"
        } else if (settingsManager.isAutoUnlockAndOpenEnabled()) {
            "⚠️ অটো পিন আনলক: পিন দেওয়া হয়নি (ওপরের ⋮ মেনু থেকে পিন দিন)"
        } else {
            "🔒 অটো পিন আনলক: বন্ধ আছে"
        }

        val targetQuery = settingsManager.getTargetContactQuery()
        val targetStatus = if (settingsManager.isTargetFilterEnabled() && targetQuery.isNotEmpty()) {
            "🎯 টার্গেট চ্যাট: শুধুমাত্র [$targetQuery]"
        } else {
            "🌐 মোড: যেকোনো হোয়াটসঅ্যাপ নোটিফিকেশনে ওপেন ও রিপ্লাই করবে"
        }

        val replyStatus = if (settingsManager.isFullAutoReplyEnabled()) {
            "🤖 অটো-রিপ্লাই: চালু • ভাষা: ${settingsManager.getLanguagePreference()}"
        } else {
            "⏸️ অটো-রিপ্লাই: সাময়িকভাবে বন্ধ"
        }

        tvSummary.text = "$pinStatus\n$targetStatus\n$replyStatus"

        val count = dbHelper.getCount()
        findViewById<TextView>(R.id.tvStatsCount).text = "Saved Replies: $count"

        val recent = dbHelper.getAllReplies().firstOrNull()
        if (recent != null) {
            findViewById<TextView>(R.id.tvRecentPreview).text =
                "Latest Reply (${recent.tone}): \"${recent.selectedReply}\""
        }
    }

    private fun showThemePickerDialog() {
        val themes = ThemeManager.ALL_THEMES.toTypedArray()
        val currentIdx = themes.indexOf(settingsManager.getColorTheme()).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("🎨 Choose App Color Theme")
            .setSingleChoiceItems(themes, currentIdx) { dialog, which ->
                settingsManager.setColorTheme(themes[which])
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showPrivacyHelpDialog() {
        AlertDialog.Builder(this)
            .setTitle("ℹ️ অটো পিন আনলক ও থ্রি-ডট মেনু গাইড")
            .setMessage(
                "১. সকল সেটিংস ওপরের ডান কোণায় থাকা থ্রি-ডট (⋮) মেনুতে রাখা হয়েছে।\n" +
                "২. থ্রি-ডট (⋮) মেনু থেকে '🔓 PIN Lock & Target Setup' বা '⚙️ All Settings'-এ গিয়ে আপনার ফোনের লক স্ক্রিন পিন সেভ করে রাখুন।\n" +
                "৩. হোয়াটসঅ্যাপে যেকোনো নোটিফিকেশন আসামাত্র অ্যাপটি ডিসপ্লে অন করবে, আপনার দেওয়া পিন টাইপ করে ফোনের লক খুলবে এবং সরাসরি হোয়াটসঅ্যাপে ওই চ্যাটটি ওপেন করে রিপ্লাই পাঠাবে।"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Please open Settings > Accessibility manually", Toast.LENGTH_LONG).show()
        }
    }

    private fun openNotificationListenerSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Please open Settings > Notification Access manually", Toast.LENGTH_LONG).show()
        }
    }

    private fun openExternalUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open link: $url", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedComponent = "${context.packageName}/${WhatsAppAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServices)
        while (colonSplitter.hasNext()) {
            val component = colonSplitter.next()
            if (component.equals(expectedComponent, ignoreCase = true)) {
                return true
            }
        }
        return WhatsAppAccessibilityService.isServiceRunning
    }

    private fun isNotificationListenerEnabled(context: Context): Boolean {
        val enabledListeners = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return WhatsAppNotificationListener.isListenerConnected
        return enabledListeners.contains(context.packageName) || WhatsAppNotificationListener.isListenerConnected
    }
}
