package com.srcreationfarm.smartreplyai.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.srcreationfarm.smartreplyai.BuildConfig
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.ai.GeminiReplyClient
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.manager.ThemeManager
import com.srcreationfarm.smartreplyai.service.WhatsAppAccessibilityService
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var settingsManager: SettingsManager
    private lateinit var dbHelper: ReplyDatabaseHelper
    private val geminiClient = GeminiReplyClient()
    private var appliedThemeName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settingsManager = SettingsManager.getInstance(this)
        dbHelper = ReplyDatabaseHelper(this)
        appliedThemeName = settingsManager.getColorTheme()

        setupToolbar()
        setupControls()
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeName != settingsManager.getColorTheme()) {
            recreate()
            return
        }
        refreshDashboardStatus()
    }

    private fun setupToolbar() {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.action_theme -> {
                    showThemePickerDialog()
                    true
                }
                R.id.action_permissions -> {
                    openAccessibilitySettings()
                    true
                }
                R.id.action_history -> {
                    startActivity(Intent(this, HistoryActivity::class.java))
                    true
                }
                R.id.action_about -> {
                    startActivity(Intent(this, AboutActivity::class.java))
                    true
                }
                R.id.action_privacy -> {
                    showPrivacyHelpDialog()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupControls() {
        findViewById<MaterialButton>(R.id.btnEnableAccessibility).setOnClickListener {
            openAccessibilitySettings()
        }

        findViewById<MaterialButton>(R.id.btnApiKeySetup).setOnClickListener {
            showQuickApiKeyDialog()
        }

        val switchFullAuto = findViewById<MaterialSwitch>(R.id.switchFullAutoReply)
        val switchFloating = findViewById<MaterialSwitch>(R.id.switchFloatingEnabled)
        val switchAutoSend = findViewById<MaterialSwitch>(R.id.switchAutoSend)
        val switchBusiness = findViewById<MaterialSwitch>(R.id.switchWhatsAppBusiness)
        val btnLanguage = findViewById<MaterialButton>(R.id.btnLanguageSelector)

        switchFullAuto.isChecked = settingsManager.isFullAutoReplyEnabled()
        switchFloating.isChecked = settingsManager.isFloatingEnabled()
        switchAutoSend.isChecked = settingsManager.isAutoSendEnabled()
        switchBusiness.isChecked = settingsManager.isWhatsAppBusinessEnabled()
        btnLanguage.text = settingsManager.getLanguagePreference()

        switchFullAuto.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setFullAutoReplyEnabled(isChecked)
        }
        switchFloating.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setFloatingEnabled(isChecked)
        }
        switchAutoSend.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setAutoSendEnabled(isChecked)
        }
        switchBusiness.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setWhatsAppBusinessEnabled(isChecked)
        }

        btnLanguage.setOnClickListener {
            val languages = arrayOf(
                "Auto (BN + EN + Banglish)",
                "Bangla (বাংলা)",
                "Banglish (Romanized Bangla)",
                "English"
            )
            AlertDialog.Builder(this)
                .setTitle("Select Reply Language Style")
                .setItems(languages) { _, which ->
                    val chosen = languages[which]
                    settingsManager.setLanguagePreference(chosen)
                    btnLanguage.text = chosen
                }
                .show()
        }

        findViewById<MaterialButton>(R.id.btnOpenHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnThemeQuick).setOnClickListener {
            showThemePickerDialog()
        }
        findViewById<MaterialButton>(R.id.btnFullSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnFooterYoutube).setOnClickListener {
            openExternalUrl(getString(R.string.youtube_url))
        }
        findViewById<MaterialButton>(R.id.btnFooterFacebook).setOnClickListener {
            openExternalUrl(getString(R.string.facebook_url))
        }
        findViewById<MaterialButton>(R.id.btnFooterAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        findViewById<TextView>(R.id.tvAppVersion).text =
            "v${BuildConfig.VERSION_NAME} • © 2026 SR Creation Farm"
    }

    private fun refreshDashboardStatus() {
        val enabled = isAccessibilityServiceEnabled(this)
        val tvTitle = findViewById<TextView>(R.id.tvServiceStatusTitle)
        val tvSub = findViewById<TextView>(R.id.tvServiceStatusSubtitle)
        val hasApiKey = settingsManager.getApiKey().isNotBlank()

        if (enabled && hasApiKey) {
            tvTitle.text = "Auto-Reply Service: Active"
            tvSub.text = "🔄 Gemini AI কানেকশন যাচাই করা হচ্ছে..."
            lifecycleScope.launch {
                val res = geminiClient.verifyGeminiConnection(settingsManager.getApiKey())
                if (res.isSuccess) {
                    tvTitle.text = "✅ Gemini AI সংযুক্ত ও প্রস্তুত"
                    tvSub.text = "শুধুমাত্র Gemini AI কানেক্টেড অবস্থায় অটো-রিপ্লাই সক্রিয় (${res.detectedContext})"
                } else {
                    tvTitle.text = res.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                    tvSub.text = "Gemini সংযুক্ত না থাকায় অটো-রিপ্লাই বন্ধ থাকবে। API Key বা ইন্টারনেট চেক করুন।"
                }
            }
        } else if (enabled && !hasApiKey) {
            tvTitle.text = "⚠️ Gemini API Key সেট করা নেই"
            tvSub.text = "Gemini AI ছাড়া অটো-রিপ্লাই যাবে না। নিচের 'Gemini API Key' বাটনে ট্যাপ করে Key দিন।"
        } else {
            tvTitle.text = "Accessibility Service: Inactive"
            tvSub.text = "Tap 'Accessibility Setup' and enable SR SmartReply AI for automatic replies."
        }

        findViewById<MaterialSwitch>(R.id.switchFullAutoReply).isChecked =
            settingsManager.isFullAutoReplyEnabled()

        val count = dbHelper.getCount()
        findViewById<TextView>(R.id.tvStatsCount).text = "Saved Replies: $count"

        val recent = dbHelper.getAllReplies().firstOrNull()
        if (recent != null) {
            findViewById<TextView>(R.id.tvRecentPreview).text =
                "Latest Reply (${recent.tone}): \"${recent.selectedReply}\""
        }
    }

    private fun showQuickApiKeyDialog() {
        val input = EditText(this).apply {
            hint = "Paste Gemini API Key (AIza...)"
            setText(settingsManager.getApiKey())
        }
        AlertDialog.Builder(this)
            .setTitle("Google Gemini API Key")
            .setMessage("শুধুমাত্র Gemini AI-এর সাথে সংযুক্ত থাকলেই অ্যাপটি অটো-রিপ্লাই করবে। আপনার Gemini API Key দিন:")
            .setView(input)
            .setPositiveButton("Save & Verify") { _, _ ->
                val newKey = input.text.toString().trim()
                settingsManager.setApiKey(newKey)
                Toast.makeText(this, "🔄 Gemini সংযোগ পরীক্ষা করা হচ্ছে...", Toast.LENGTH_SHORT).show()
                refreshDashboardStatus()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showThemePickerDialog() {
        val themes = ThemeManager.ALL_THEMES.toTypedArray()
        val currentIdx = themes.indexOf(settingsManager.getColorTheme()).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Choose App Color Theme")
            .setSingleChoiceItems(themes, currentIdx) { dialog, which ->
                settingsManager.setColorTheme(themes[which])
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showPrivacyHelpDialog() {
        AlertDialog.Builder(this)
            .setTitle("Gemini Live Notification Guide")
            .setMessage(
                "১. শুধুমাত্র Gemini AI কানেক্টেড থাকলে অটো-রিপ্লাই যাবে; কানেক্টেড না থাকলে ফ্লোটিং আইকন লাল হয়ে সমস্যার কারণ দেখাবে।\n" +
                "২. নতুন মেসেজ আসলে ফ্লোটিং আইকনে ধাপে ধাপে নোটিফিকেশন দেখাবে:\n" +
                "   • 📤 Gemini-এর কাছে পাঠানো হয়েছে...\n" +
                "   • 📥 রিপ্লাই গ্রহণ করা হয়েছে!\n" +
                "   • 🚀 রিপ্লাই দেওয়া হচ্ছে...\n" +
                "   • ✅ রিপ্লাই দেওয়া সম্পন্ন!"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Please open Settings > Accessibility manually", Toast.LENGTH_LONG).show()
        }
    }

    private fun openExternalUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open link: $url", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedComponent = "${context.packageName}/${WhatsAppAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServices)
        while (colonSplitter.hasNext()) {
            val component = colonSplitter.next()
            if (component.equals(expectedComponent, ignoreCase = true)) {
                return true
            }
        }
        return WhatsAppAccessibilityService.isServiceRunning
    }
}
