package com.srcreationfarm.smartreplyai.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import com.srcreationfarm.smartreplyai.BuildConfig
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.manager.ThemeManager
import com.srcreationfarm.smartreplyai.service.WhatsAppAccessibilityService

class MainActivity : AppCompatActivity() {

    private lateinit var settingsManager: SettingsManager
    private lateinit var dbHelper: ReplyDatabaseHelper
    private var appliedThemeName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settingsManager = SettingsManager.getInstance(this)
        dbHelper = ReplyDatabaseHelper(this)
        appliedThemeName = settingsManager.getColorTheme()

        setupToolbar()
        setupToneSelectionCards()
        setupControls()
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeName != settingsManager.getColorTheme()) {
            recreate()
            return
        }
        updateToneSelectionUI()
        refreshDashboardStatus()
    }

    private fun setupToolbar() {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.action_theme -> {
                    showThemePickerDialog()
                    true
                }
                R.id.action_permissions -> {
                    openAccessibilitySettings()
                    true
                }
                R.id.action_history -> {
                    startActivity(Intent(this, HistoryActivity::class.java))
                    true
                }
                R.id.action_about -> {
                    startActivity(Intent(this, AboutActivity::class.java))
                    true
                }
                R.id.action_privacy -> {
                    showPrivacyHelpDialog()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupToneSelectionCards() {
        val cardFriendly = findViewById<MaterialCardView>(R.id.cardSelectFriendly)
        val cardPolite = findViewById<MaterialCardView>(R.id.cardSelectPolite)
        val cardProfessional = findViewById<MaterialCardView>(R.id.cardSelectProfessional)

        cardFriendly.setOnClickListener {
            settingsManager.setSelectedTone(SettingsManager.TONE_FRIENDLY)
            updateToneSelectionUI()
            Toast.makeText(this, "Selected: Friendly • বন্ধুত্বপূর্ণ", Toast.LENGTH_SHORT).show()
        }

        cardPolite.setOnClickListener {
            settingsManager.setSelectedTone(SettingsManager.TONE_POLITE)
            updateToneSelectionUI()
            Toast.makeText(this, "Selected: Polite • ভদ্র ও আন্তরিক", Toast.LENGTH_SHORT).show()
        }

        cardProfessional.setOnClickListener {
            settingsManager.setSelectedTone(SettingsManager.TONE_PROFESSIONAL)
            updateToneSelectionUI()
            Toast.makeText(this, "Selected: Professional • পেশাদার", Toast.LENGTH_SHORT).show()
        }

        updateToneSelectionUI()
    }

    private fun updateToneSelectionUI() {
        val selected = settingsManager.getSelectedTone()
        val cardFriendly = findViewById<MaterialCardView>(R.id.cardSelectFriendly)
        val cardPolite = findViewById<MaterialCardView>(R.id.cardSelectPolite)
        val cardProfessional = findViewById<MaterialCardView>(R.id.cardSelectProfessional)

        val badgeFriendly = findViewById<TextView>(R.id.tvBadgeFriendly)
        val badgePolite = findViewById<TextView>(R.id.tvBadgePolite)
        val badgeProfessional = findViewById<TextView>(R.id.tvBadgeProfessional)
        val tvSummary = findViewById<TextView>(R.id.tvActiveToneSummary)

        val dpToPx = resources.displayMetrics.density
        val activeStroke = (2.5f * dpToPx).toInt()
        val inactiveStroke = (1.0f * dpToPx).toInt()

        val isFriendly = selected == SettingsManager.TONE_FRIENDLY
        val isPolite = selected == SettingsManager.TONE_POLITE
        val isPro = selected == SettingsManager.TONE_PROFESSIONAL

        cardFriendly.strokeWidth = if (isFriendly) activeStroke else inactiveStroke
        cardPolite.strokeWidth = if (isPolite) activeStroke else inactiveStroke
        cardProfessional.strokeWidth = if (isPro) activeStroke else inactiveStroke

        badgeFriendly.text = if (isFriendly) "✓ ACTIVE" else "SELECT"
        badgePolite.text = if (isPolite) "✓ ACTIVE" else "SELECT"
        badgeProfessional.text = if (isPro) "✓ ACTIVE" else "SELECT"

        tvSummary.text = "Active Section: ${settingsManager.getSelectedToneLabel()} (এসএমএস আসলে অটোমেটিক এই ধরনে রিপ্লাই যাবে)"
    }

    private fun setupControls() {
        findViewById<MaterialButton>(R.id.btnEnableAccessibility).setOnClickListener {
            openAccessibilitySettings()
        }

        findViewById<MaterialButton>(R.id.btnApiKeySetup).setOnClickListener {
            showQuickApiKeyDialog()
        }

        val switchFullAuto = findViewById<MaterialSwitch>(R.id.switchFullAutoReply)
        val switchFloating = findViewById<MaterialSwitch>(R.id.switchFloatingEnabled)
        val switchAutoSend = findViewById<MaterialSwitch>(R.id.switchAutoSend)
        val switchBusiness = findViewById<MaterialSwitch>(R.id.switchWhatsAppBusiness)
        val btnLanguage = findViewById<MaterialButton>(R.id.btnLanguageSelector)

        switchFullAuto.isChecked = settingsManager.isFullAutoReplyEnabled()
        switchFloating.isChecked = settingsManager.isFloatingEnabled()
        switchAutoSend.isChecked = settingsManager.isAutoSendEnabled()
        switchBusiness.isChecked = settingsManager.isWhatsAppBusinessEnabled()
        btnLanguage.text = settingsManager.getLanguagePreference()

        switchFullAuto.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setFullAutoReplyEnabled(isChecked)
        }
        switchFloating.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setFloatingEnabled(isChecked)
        }
        switchAutoSend.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setAutoSendEnabled(isChecked)
        }
        switchBusiness.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setWhatsAppBusinessEnabled(isChecked)
        }

        btnLanguage.setOnClickListener {
            val languages = arrayOf(
                "Auto (BN + EN + Banglish)",
                "Bangla (বাংলা)",
                "Banglish (Romanized Bangla)",
                "English"
            )
            AlertDialog.Builder(this)
                .setTitle("Select Reply Language Style")
                .setItems(languages) { _, which ->
                    val chosen = languages[which]
                    settingsManager.setLanguagePreference(chosen)
                    btnLanguage.text = chosen
                }
                .show()
        }

        findViewById<MaterialButton>(R.id.btnOpenHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnThemeQuick).setOnClickListener {
            showThemePickerDialog()
        }
        findViewById<MaterialButton>(R.id.btnFullSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnFooterYoutube).setOnClickListener {
            openExternalUrl(getString(R.string.youtube_url))
        }
        findViewById<MaterialButton>(R.id.btnFooterFacebook).setOnClickListener {
            openExternalUrl(getString(R.string.facebook_url))
        }
        findViewById<MaterialButton>(R.id.btnFooterAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        findViewById<TextView>(R.id.tvAppVersion).text =
            "v${BuildConfig.VERSION_NAME} • © 2026 SR Creation Farm"
    }

    private fun refreshDashboardStatus() {
        val enabled = isAccessibilityServiceEnabled(this)
        val tvTitle = findViewById<TextView>(R.id.tvServiceStatusTitle)
        val tvSub = findViewById<TextView>(R.id.tvServiceStatusSubtitle)
        val hasApiKey = settingsManager.getApiKey().isNotBlank()
        val toneLabel = settingsManager.getSelectedToneLabel()

        if (enabled) {
            tvTitle.text = "Auto-Reply Service: Active"
            tvSub.text = if (hasApiKey) {
                "Gemini AI Active • Auto-Replying in [$toneLabel] mode"
            } else {
                "Smart Built-in Auto Mode • Auto-Replying in [$toneLabel] mode"
            }
        } else {
            tvTitle.text = "Accessibility Service: Inactive"
            tvSub.text = "Tap 'Accessibility Setup' and enable SR SmartReply AI for automatic replies."
        }

        findViewById<MaterialSwitch>(R.id.switchFullAutoReply).isChecked =
            settingsManager.isFullAutoReplyEnabled()

        val count = dbHelper.getCount()
        findViewById<TextView>(R.id.tvStatsCount).text = "Saved Replies: $count"

        val recent = dbHelper.getAllReplies().firstOrNull()
        if (recent != null) {
            findViewById<TextView>(R.id.tvRecentPreview).text =
                "Latest Auto-Reply (${recent.tone}): \"${recent.selectedReply}\""
        }
    }

    private fun showQuickApiKeyDialog() {
        val input = EditText(this).apply {
            hint = "Paste Gemini API Key (AIza...)"
            setText(settingsManager.getApiKey())
        }
        AlertDialog.Builder(this)
            .setTitle("Google Gemini API Key")
            .setMessage("Enter your Gemini API key for advanced AI replies (or leave blank to use the built-in Smart Bangla/Banglish/English responder):")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                settingsManager.setApiKey(input.text.toString())
                refreshDashboardStatus()
                Toast.makeText(this, "API Key saved!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showThemePickerDialog() {
        val themes = ThemeManager.ALL_THEMES.toTypedArray()
        val currentIdx = themes.indexOf(settingsManager.getColorTheme()).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Choose App Color Theme")
            .setSingleChoiceItems(themes, currentIdx) { dialog, which ->
                settingsManager.setColorTheme(themes[which])
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showPrivacyHelpDialog() {
        AlertDialog.Builder(this)
            .setTitle("Automatic Reply Guide")
            .setMessage(
                "1. Select your preferred reply section inside the app (Friendly, Polite, or Professional).\n" +
                "2. Keep 'Auto-Read & Instant Auto-Reply' turned ON.\n" +
                "3. When WhatsApp chat is open on screen and a new message arrives, the app automatically reads it and sends the reply immediately!\n" +
                "4. Tap the floating button on WhatsApp anytime to Pause/Resume Auto-Reply, or long-press it to open manual options."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Please open Settings > Accessibility manually", Toast.LENGTH_LONG).show()
        }
    }

    private fun openExternalUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open link: $url", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedComponent = "${context.packageName}/${WhatsAppAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServices)
        while (colonSplitter.hasNext()) {
            val component = colonSplitter.next()
            if (component.equals(expectedComponent, ignoreCase = true)) {
                return true
            }
        }
        return WhatsAppAccessibilityService.isServiceRunning
    }
}
