package com.srcreationfarm.smartreplyai.ui

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText
import com.srcreationfarm.smartreplyai.BuildConfig
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.ai.GeminiReplyClient
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.manager.ThemeManager
import com.srcreationfarm.smartreplyai.service.WhatsAppAccessibilityService
import com.srcreationfarm.smartreplyai.service.WhatsAppNotificationListener
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var settingsManager: SettingsManager
    private lateinit var dbHelper: ReplyDatabaseHelper
    private val geminiClient = GeminiReplyClient()
    private var appliedThemeName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settingsManager = SettingsManager.getInstance(this)
        dbHelper = ReplyDatabaseHelper(this)
        appliedThemeName = settingsManager.getColorTheme()

        setupToolbar()
        setupUnlockAndTargetCard()
        setupControls()
        setupGeminiTestConsole()
    }

    override fun onResume() {
        super.onResume()
        if (appliedThemeName != settingsManager.getColorTheme()) {
            recreate()
            return
        }
        val etKey = findViewById<TextInputEditText>(R.id.etDashboardApiKey)
        val savedKey = settingsManager.getApiKey()
        if (etKey.text?.toString()?.trim() != savedKey) {
            etKey.setText(savedKey)
        }
        updateKeyFormatHint(savedKey)
        updateTargetContactStatusUI()
        refreshDashboardStatus()
    }

    private fun setupToolbar() {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.action_theme -> {
                    showThemePickerDialog()
                    true
                }
                R.id.action_permissions -> {
                    openAccessibilitySettings()
                    true
                }
                R.id.action_history -> {
                    startActivity(Intent(this, HistoryActivity::class.java))
                    true
                }
                R.id.action_about -> {
                    startActivity(Intent(this, AboutActivity::class.java))
                    true
                }
                R.id.action_privacy -> {
                    showPrivacyHelpDialog()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupUnlockAndTargetCard() {
        val switchAutoUnlock = findViewById<MaterialSwitch>(R.id.switchAutoUnlockAndOpen)
        val etPin = findViewById<TextInputEditText>(R.id.etPhoneLockPin)
        val switchPinEnter = findViewById<MaterialSwitch>(R.id.switchPinPressEnter)
        val switchTarget = findViewById<MaterialSwitch>(R.id.switchTargetContactOnly)
        val etTarget = findViewById<TextInputEditText>(R.id.etTargetContactFilter)
        val btnSaveTarget = findViewById<MaterialButton>(R.id.btnSaveTargetContact)
        val btnClearTarget = findViewById<MaterialButton>(R.id.btnClearTargetContact)
        val btnTestLaunch = findViewById<MaterialButton>(R.id.btnTestLaunchAndSearch)

        switchAutoUnlock.isChecked = settingsManager.isAutoUnlockAndOpenEnabled()
        etPin.setText(settingsManager.getPhoneLockPin())
        switchPinEnter.isChecked = settingsManager.isPinPressEnterEnabled()
        etTarget.setText(settingsManager.getTargetContactQuery())
        switchTarget.isChecked = settingsManager.isTargetFilterEnabled()
        updateTargetContactStatusUI()

        switchAutoUnlock.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setAutoUnlockAndOpenEnabled(isChecked)
            updateTargetContactStatusUI()
        }

        switchPinEnter.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setPinPressEnterEnabled(isChecked)
        }

        switchTarget.setOnCheckedChangeListener { _, isChecked ->
            val currentInput = etTarget.text?.toString()?.trim() ?: ""
            if (isChecked && currentInput.isEmpty()) {
                Toast.makeText(this, "নিচের বক্সে নির্দিষ্ট ব্যক্তির নাম বা ফোন নাম্বার লিখুন", Toast.LENGTH_SHORT).show()
            }
            if (currentInput.isNotEmpty()) {
                settingsManager.setTargetContactQuery(currentInput)
            }
            settingsManager.setTargetFilterEnabled(isChecked && currentInput.isNotEmpty())
            updateTargetContactStatusUI()
        }

        btnSaveTarget.setOnClickListener {
            val pinVal = etPin.text?.toString()?.trim() ?: ""
            val query = etTarget.text?.toString()?.trim() ?: ""

            settingsManager.setPhoneLockPin(pinVal)
            settingsManager.setAutoUnlockAndOpenEnabled(switchAutoUnlock.isChecked)
            settingsManager.setPinPressEnterEnabled(switchPinEnter.isChecked)

            if (query.isEmpty()) {
                settingsManager.setTargetContactQuery("")
                settingsManager.setTargetFilterEnabled(false)
                switchTarget.isChecked = false
            } else {
                settingsManager.setTargetContactQuery(query)
                settingsManager.setTargetFilterEnabled(true)
                switchTarget.isChecked = true
            }
            updateTargetContactStatusUI()

            val pinMsg = if (pinVal.isNotEmpty()) "পিন (${pinVal.length} ডিজিট)" else "পিন ছাড়া"
            val targetMsg = if (query.isNotEmpty()) "টার্গেট [$query]" else "সকল চ্যাট"
            Toast.makeText(this, "✅ সেভ হয়েছে: $pinMsg ও $targetMsg!", Toast.LENGTH_SHORT).show()
        }

        btnClearTarget.setOnClickListener {
            etTarget.setText("")
            settingsManager.setTargetContactQuery("")
            settingsManager.setTargetFilterEnabled(false)
            switchTarget.isChecked = false
            updateTargetContactStatusUI()
            Toast.makeText(this, "🌐 সকল চ্যাটে অটো-রিপ্লাই চালু করা হয়েছে (All Contacts)", Toast.LENGTH_SHORT).show()
        }

        btnTestLaunch.setOnClickListener {
            val pinVal = etPin.text?.toString()?.trim() ?: ""
            val query = etTarget.text?.toString()?.trim() ?: ""
            settingsManager.setPhoneLockPin(pinVal)
            if (query.isNotEmpty()) {
                settingsManager.setTargetContactQuery(query)
                settingsManager.setTargetFilterEnabled(true)
                switchTarget.isChecked = true
            }
            updateTargetContactStatusUI()

            if (!isAccessibilityServiceEnabled(this)) {
                Toast.makeText(this, "আগে উপরের 'Accessibility' বাটনে ট্যাপ করে সার্ভিসটি অন করুন!", Toast.LENGTH_LONG).show()
                openAccessibilitySettings()
                return@setOnClickListener
            }

            Toast.makeText(this, "🚀 WhatsApp ওপেন করে [$query] খোঁজা হচ্ছে...", Toast.LENGTH_SHORT).show()
            WhatsAppAccessibilityService.triggerTestLaunchAndFindContact(query)
        }
    }

    private fun updateTargetContactStatusUI() {
        val tvStatus = findViewById<TextView>(R.id.tvTargetFilterStatus)
        val isFilterOn = settingsManager.isTargetFilterEnabled()
        val targetQuery = settingsManager.getTargetContactQuery()
        val hasPin = settingsManager.getPhoneLockPin().isNotEmpty()
        val pinBadge = if (hasPin) "🔓 পিন সেট করা আছে" else "⚠️ পিন দেওয়া হয়নি"

        if (isFilterOn && targetQuery.isNotEmpty()) {
            tvStatus.text = "🎯 টার্গেট: \"$targetQuery\" • $pinBadge"
            tvStatus.setTextColor(Color.parseColor("#38BDF8"))
        } else {
            tvStatus.text = "🌐 মোড: সকল চ্যাট (All) • $pinBadge"
            tvStatus.setTextColor(Color.parseColor("#10B981"))
        }
    }

    private fun setupGeminiTestConsole() {
        val etKey = findViewById<TextInputEditText>(R.id.etDashboardApiKey)
        val etTestSms = findViewById<EditText>(R.id.etTestIncomingSms)
        val btnSaveAndTest = findViewById<MaterialButton>(R.id.btnSaveAndTestKey)
        val btnGetFreeKey = findViewById<MaterialButton>(R.id.btnGetFreeGeminiKey)
        val btnRunLiveTest = findViewById<MaterialButton>(R.id.btnRunLiveReplyTest)

        val currentKey = settingsManager.getApiKey()
        etKey.setText(currentKey)
        updateKeyFormatHint(currentKey)

        etKey.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateKeyFormatHint(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        btnSaveAndTest.setOnClickListener {
            val enteredKey = SettingsManager.sanitizeApiKey(etKey.text?.toString() ?: "")
            etKey.setText(enteredKey)
            settingsManager.setApiKey(enteredKey)
            val sampleSms = etTestSms.text?.toString()?.trim().orEmpty().ifBlank { "Assalamu Alaikum, kemon acho?" }
            runLiveGeminiConnectionTest(enteredKey, sampleSms, showPopup = false)
        }

        btnRunLiveTest.setOnClickListener {
            val enteredKey = SettingsManager.sanitizeApiKey(etKey.text?.toString() ?: "")
            etKey.setText(enteredKey)
            settingsManager.setApiKey(enteredKey)
            val sampleSms = etTestSms.text?.toString()?.trim().orEmpty().ifBlank { "Assalamu Alaikum, kemon acho?" }
            runLiveGeminiConnectionTest(enteredKey, sampleSms, showPopup = false)
        }

        btnGetFreeKey.setOnClickListener {
            openExternalUrl("https://aistudio.google.com/app/apikey")
        }
    }

    private fun updateKeyFormatHint(rawKey: String) {
        val tvHint = findViewById<TextView>(R.id.tvKeyFormatHint)
        val clean = SettingsManager.sanitizeApiKey(rawKey)
        when {
            clean.isEmpty() -> {
                tvHint.text = "নোট: এখানে আপনার Gemini API Key (AQ... অথবা AIzaSy...) পেস্ট করুন।"
                tvHint.setTextColor(Color.parseColor("#F59E0B"))
            }
            clean.startsWith("AQ.") && clean.length >= 20 -> {
                tvHint.text = "✓ সঠিক API Key শনাক্ত হয়েছে (Google Cloud / Vertex Gemini Key • ${clean.length} অক্ষর)।"
                tvHint.setTextColor(Color.parseColor("#10B981"))
            }
            clean.startsWith("AIza") && clean.length >= 30 -> {
                tvHint.text = "✓ সঠিক API Key শনাক্ত হয়েছে (Google AI Studio Gemini Key • ${clean.length} অক্ষর)।"
                tvHint.setTextColor(Color.parseColor("#10B981"))
            }
            clean.length >= 10 -> {
                tvHint.text = "✓ API Key সংরক্ষিত আছে (${clean.length} অক্ষর)।"
                tvHint.setTextColor(Color.parseColor("#10B981"))
            }
            else -> {
                tvHint.text = "⚠️ সম্পূর্ণ API Key পেস্ট করুন।"
                tvHint.setTextColor(Color.parseColor("#EF4444"))
            }
        }
    }

    private fun showQuickApiKeyDialog() {
        val etDashboard = findViewById<TextInputEditText>(R.id.etDashboardApiKey)
        val input = EditText(this).apply {
            hint = "Paste Gemini API Key"
            setText(settingsManager.getApiKey())
        }
        AlertDialog.Builder(this)
            .setTitle("Google Gemini API Key")
            .setMessage("আপনার Gemini API Key দিন এবং সংযোগ পরীক্ষা করুন:")
            .setView(input)
            .setPositiveButton("Save & Verify") { _, _ ->
                val newKey = SettingsManager.sanitizeApiKey(input.text.toString())
                settingsManager.setApiKey(newKey)
                etDashboard?.setText(newKey)
                updateKeyFormatHint(newKey)
                val sampleSms = findViewById<EditText>(R.id.etTestIncomingSms)?.text?.toString()?.trim()
                    .orEmpty().ifBlank { "Assalamu Alaikum, kemon acho?" }
                runLiveGeminiConnectionTest(newKey, sampleSms, showPopup = true)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun runLiveGeminiConnectionTest(
        apiKey: String,
        sampleSms: String,
        showPopup: Boolean
    ) {
        val tvBanner = findViewById<TextView>(R.id.tvConnectionBanner)
        val tvResult = findViewById<TextView>(R.id.tvLiveTestResult)
        val progress = findViewById<ProgressBar>(R.id.progressConnectionTest)
        val tvTitle = findViewById<TextView>(R.id.tvServiceStatusTitle)
        val tvSub = findViewById<TextView>(R.id.tvServiceStatusSubtitle)

        if (apiKey.length < 10) {
            settingsManager.recordConnectionFailure("⚠️ Gemini API Key নেই")
            tvBanner.text = "❌ স্ট্যাটাস: কানেক্টেড নয় (কোনো API Key দেওয়া হয়নি)"
            tvBanner.setTextColor(Color.parseColor("#EF4444"))
            tvResult.text = "❌ পরীক্ষা ব্যর্থ: আগে উপরের বক্সে আপনার Gemini API Key পেস্ট করে 'Save & Test Key' চাপুন।"
            return
        }

        progress.visibility = View.VISIBLE
        tvBanner.text = "🔄 Gemini AI সংযোগ পরীক্ষা করা হচ্ছে..."
        tvBanner.setTextColor(Color.parseColor("#38BDF8"))
        tvResult.text = "📤 টেস্ট মেসেজ পাঠানো হচ্ছে: \"$sampleSms\"..."

        lifecycleScope.launch {
            val res = geminiClient.verifyGeminiConnection(apiKey, sampleSms)
            progress.visibility = View.GONE

            if (res.isSuccess && res.reply.isNotBlank()) {
                val usedModel = res.modelUsed.ifBlank { "gemini-2.5-flash" }
                settingsManager.recordConnectionSuccess(usedModel, res.latencyMs)
                tvBanner.text = "✅ Gemini AI সফলভাবে কানেক্টেড! ($usedModel • ${res.latencyMs}ms)"
                tvBanner.setTextColor(Color.parseColor("#10B981"))

                val resultSummary = "✅ সংযোগ পরীক্ষা ১০০% সফল!\n" +
                        "🤖 সক্রিয় মডেল: $usedModel (রেসপন্স সময়: ${res.latencyMs}ms)\n" +
                        "💬 পরীক্ষামূলক মেসেজ: \"$sampleSms\"\n" +
                        "✨ Gemini AI-এর উত্তর: \"${res.reply}\""
                tvResult.text = resultSummary

                if (isAccessibilityServiceEnabled(this@MainActivity)) {
                    tvTitle.text = "✅ Gemini AI সংযুক্ত ও প্রস্তুত"
                    tvSub.text = "সফলভাবে সংযুক্ত ($usedModel)। এখন WhatsApp-এ ফাস্ট অটো-রিপ্লাই সক্রিয়!"
                } else {
                    tvTitle.text = "✅ Gemini AI সংযুক্ত (Accessibility চালু করুন)"
                    tvSub.text = "API Key সঠিকভাবে কাজ করছে! এখন 'Accessibility' বাটন থেকে সার্ভিসটি অন করুন।"
                }

                Toast.makeText(this@MainActivity, "✅ Gemini AI সফলভাবে কানেক্ট হয়েছে!", Toast.LENGTH_SHORT).show()
                if (showPopup) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("✅ Gemini সংযোগ সফল!")
                        .setMessage(resultSummary)
                        .setPositiveButton("OK", null)
                        .show()
                }
            } else {
                val errTitle = res.errorMessage.ifBlank { "⚠️ Gemini সংযোগে সমস্যা" }
                settingsManager.recordConnectionFailure(errTitle)
                tvBanner.text = "❌ কানেক্টেড নয়: $errTitle"
                tvBanner.setTextColor(Color.parseColor("#EF4444"))

                val failSummary = "❌ সংযোগ পরীক্ষা ব্যর্থ হয়েছে ($errTitle)\n" +
                        "🔍 কারণ ও সমাধান: ${res.detailedDiagnostics}"
                tvResult.text = failSummary
            }
        }
    }

    private fun setupControls() {
        findViewById<MaterialButton>(R.id.btnEnableAccessibility).setOnClickListener {
            openAccessibilitySettings()
        }

        findViewById<MaterialButton>(R.id.btnEnableNotificationAccess).setOnClickListener {
            openNotificationListenerSettings()
        }

        findViewById<MaterialButton>(R.id.btnApiKeySetup).setOnClickListener {
            showQuickApiKeyDialog()
        }

        val switchFullAuto = findViewById<MaterialSwitch>(R.id.switchFullAutoReply)
        val switchFloating = findViewById<MaterialSwitch>(R.id.switchFloatingEnabled)
        val switchAutoSend = findViewById<MaterialSwitch>(R.id.switchAutoSend)
        val switchBusiness = findViewById<MaterialSwitch>(R.id.switchWhatsAppBusiness)
        val btnLanguage = findViewById<MaterialButton>(R.id.btnLanguageSelector)

        switchFullAuto.isChecked = settingsManager.isFullAutoReplyEnabled()
        switchFloating.isChecked = settingsManager.isFloatingEnabled()
        switchAutoSend.isChecked = settingsManager.isAutoSendEnabled()
        switchBusiness.isChecked = settingsManager.isWhatsAppBusinessEnabled()
        btnLanguage.text = settingsManager.getLanguagePreference()

        switchFullAuto.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setFullAutoReplyEnabled(isChecked)
        }
        switchFloating.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setFloatingEnabled(isChecked)
        }
        switchAutoSend.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setAutoSendEnabled(isChecked)
        }
        switchBusiness.setOnCheckedChangeListener { _, isChecked ->
            settingsManager.setWhatsAppBusinessEnabled(isChecked)
        }

        btnLanguage.setOnClickListener {
            val languages = arrayOf(
                "Auto (BN + EN + Banglish)",
                "Bangla (বাংলা)",
                "Banglish (Romanized Bangla)",
                "English"
            )
            AlertDialog.Builder(this)
                .setTitle("Select Reply Language Style")
                .setItems(languages) { _, which ->
                    val chosen = languages[which]
                    settingsManager.setLanguagePreference(chosen)
                    btnLanguage.text = chosen
                }
                .show()
        }

        findViewById<MaterialButton>(R.id.btnOpenHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnThemeQuick).setOnClickListener {
            showThemePickerDialog()
        }
        findViewById<MaterialButton>(R.id.btnFullSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnFooterYoutube).setOnClickListener {
            openExternalUrl(getString(R.string.youtube_url))
        }
        findViewById<MaterialButton>(R.id.btnFooterFacebook).setOnClickListener {
            openExternalUrl(getString(R.string.facebook_url))
        }
        findViewById<MaterialButton>(R.id.btnFooterAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        findViewById<TextView>(R.id.tvAppVersion).text =
            "v${BuildConfig.VERSION_NAME} • © 2026 SR Creation Farm"
    }

    private fun refreshDashboardStatus() {
        val accEnabled = isAccessibilityServiceEnabled(this)
        val notifEnabled = isNotificationListenerEnabled(this)
        val tvTitle = findViewById<TextView>(R.id.tvServiceStatusTitle)
        val tvSub = findViewById<TextView>(R.id.tvServiceStatusSubtitle)
        val tvBanner = findViewById<TextView>(R.id.tvConnectionBanner)
        val savedKey = settingsManager.getApiKey()

        if (savedKey.length < 10) {
            tvBanner.text = "❌ স্ট্যাটাস: কোনো Gemini API Key সেট করা নেই"
            tvBanner.setTextColor(Color.parseColor("#EF4444"))
        } else {
            val model = settingsManager.getConnectedModel().ifBlank { "gemini-2.5-flash" }
            val ms = settingsManager.getLastLatencyMs()
            tvBanner.text = "✅ স্ট্যাটাস: Gemini AI সফলভাবে কানেক্টেড! ($model • ${ms}ms)"
            tvBanner.setTextColor(Color.parseColor("#10B981"))
        }

        val notifStatus = if (notifEnabled) "Notification: ON" else "Notification: OFF"
        val targetInfo = if (settingsManager.isTargetFilterEnabled() && settingsManager.getTargetContactQuery().isNotEmpty()) {
            " • টার্গেট: [${settingsManager.getTargetContactQuery()}]"
        } else {
            " • মোড: সকল চ্যাট"
        }

        if (accEnabled && savedKey.length >= 10) {
            tvTitle.text = "✅ Accessibility: ON • $notifStatus"
            tvSub.text = "Gemini সংযুক্ত$targetInfo। নোটিফিকেশন আসলেই অটো আনলক ও রিপ্লাই সক্রিয়!"
        } else if (!accEnabled && savedKey.length >= 10) {
            tvTitle.text = "⚠️ Accessibility: OFF • $notifStatus"
            tvSub.text = "অটো আনলক ও রিপ্লাই চালু করতে নিচের 'Accessibility' ও 'Notification Access' অন করুন।"
        } else {
            tvTitle.text = "⚠️ Gemini API Key সেট করা নেই"
            tvSub.text = "নিচের বক্সে আপনার Gemini API Key পেস্ট করে 'Save & Test Key' চাপুন।"
        }

        findViewById<MaterialSwitch>(R.id.switchFullAutoReply).isChecked =
            settingsManager.isFullAutoReplyEnabled()

        val count = dbHelper.getCount()
        findViewById<TextView>(R.id.tvStatsCount).text = "Saved Replies: $count"

        val recent = dbHelper.getAllReplies().firstOrNull()
        if (recent != null) {
            findViewById<TextView>(R.id.tvRecentPreview).text =
                "Latest Reply (${recent.tone}): \"${recent.selectedReply}\""
        }
    }

    private fun showThemePickerDialog() {
        val themes = ThemeManager.ALL_THEMES.toTypedArray()
        val currentIdx = themes.indexOf(settingsManager.getColorTheme()).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Choose App Color Theme")
            .setSingleChoiceItems(themes, currentIdx) { dialog, which ->
                settingsManager.setColorTheme(themes[which])
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showPrivacyHelpDialog() {
        AlertDialog.Builder(this)
            .setTitle("অটো পিন আনলক ও চ্যাট সার্চ গাইড")
            .setMessage(
                "১. উপরে 'Accessibility' এবং 'Notification Access'—এই দুটি পারমিশন অন করুন।\n" +
                "২. '🔓 অটো পিন আনলক ও নির্দিষ্ট ব্যক্তি/নাম্বার টার্গেট' কার্ডে আপনার ফোনের লক স্ক্রিন পিন (যেমন: 1234) এবং WhatsApp নাম বা নাম্বার (যেমন: SR) লিখে '💾 পিন ও নাম সেভ' চাপুন।\n" +
                "৩. WhatsApp-এ নতুন মেসেজের নোটিফিকেশন আসামাত্র অ্যাপটি স্ক্রিন অন করবে, সোয়াইপ করে পিন বসিয়ে লক খুলবে, WhatsApp-এ ঢুকে ওই নামটি খুঁজে বের করে Gemini AI দিয়ে অটোমেটিক রিপ্লাই পাঠিয়ে দেবে!"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Please open Settings > Accessibility manually", Toast.LENGTH_LONG).show()
        }
    }

    private fun openNotificationListenerSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Please open Settings > Notification Access manually", Toast.LENGTH_LONG).show()
        }
    }

    private fun openExternalUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open link: $url", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedComponent = "${context.packageName}/${WhatsAppAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServices)
        while (colonSplitter.hasNext()) {
            val component = colonSplitter.next()
            if (component.equals(expectedComponent, ignoreCase = true)) {
                return true
            }
        }
        return WhatsAppAccessibilityService.isServiceRunning
    }

    private fun isNotificationListenerEnabled(context: Context): Boolean {
        val enabledListeners = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return WhatsAppNotificationListener.isListenerConnected
        return enabledListeners.contains(context.packageName) || WhatsAppNotificationListener.isListenerConnected
    }
}
