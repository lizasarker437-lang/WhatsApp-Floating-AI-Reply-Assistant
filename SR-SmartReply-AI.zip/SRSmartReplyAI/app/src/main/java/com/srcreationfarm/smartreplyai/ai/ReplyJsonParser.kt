package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import org.json.JSONObject
import kotlin.math.abs

object ReplyJsonParser {

    enum class PronounStyle { TUI, TUMI, APNI }
    enum class ScriptStyle { BANGLA, BANGLISH, ENGLISH }
    enum class ConversationTopic {
        NONE, FOOD, ACTIVITY_WORK, LOCATION, WELLBEING, SLEEP, FAMILY, CALL, PLAN_MEET
    }

    data class ThreadContext(
        val windowMessages: List<ChatMessage>,
        val priorMessages: List<ChatMessage>,
        val lastIncomingMessage: String,
        val scriptStyle: ScriptStyle,
        val pronounStyle: PronounStyle,
        val previousTopic: ConversationTopic,
        val previousOwnReplies: Set<String>
    )

    fun parseGeminiResponse(rawText: String): ReplyOptions {
        val cleaned = rawText
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()

        val startIndex = cleaned.indexOf('{')
        val endIndex = cleaned.lastIndexOf('}')
        if (startIndex == -1 || endIndex == -1 || endIndex <= startIndex) {
            throw IllegalArgumentException("Invalid JSON boundaries in AI response")
        }

        val jsonStr = cleaned.substring(startIndex, endIndex + 1)
        val obj = JSONObject(jsonStr)

        val friendly = obj.optString("friendly", "").trim()
        val polite = obj.optString("polite", "").trim()
        val professional = obj.optString("professional", "").trim()

        if (friendly.isEmpty() && polite.isEmpty() && professional.isEmpty()) {
            throw IllegalArgumentException("Empty reply fields in JSON")
        }

        return ReplyOptions(
            friendly = friendly.ifEmpty { polite },
            polite = polite.ifEmpty { friendly },
            professional = professional.ifEmpty { polite }
        )
    }

    fun parseFastSingleReply(rawText: String, selectedTone: String): String {
        val cleaned = rawText
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()

        val startBrace = cleaned.indexOf('{')
        val endBrace = cleaned.lastIndexOf('}')
        if (startBrace != -1 && endBrace > startBrace) {
            try {
                val obj = JSONObject(cleaned.substring(startBrace, endBrace + 1))
                val direct = obj.optString("reply", "").trim()
                if (direct.isNotEmpty()) return direct
                val byTone = obj.optString(selectedTone.lowercase(), "").trim()
                if (byTone.isNotEmpty()) return byTone
                val friendly = obj.optString("friendly", "").trim()
                if (friendly.isNotEmpty()) return friendly
            } catch (_: Exception) {
            }
        }
        return cleaned.trim { it == '"' || it.isWhitespace() }.lines().firstOrNull { it.isNotBlank() }?.trim() ?: ""
    }

    fun detectScriptStyle(text: String): ScriptStyle? {
        if (text.isBlank()) return null
        val hasBanglaScript = text.any { it in '\u0980'..'\u09FF' }
        if (hasBanglaScript) return ScriptStyle.BANGLA

        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\s]"), " ") + " "
        val banglishMarkers = listOf(
            " ki ", " kemon ", " kmn ", " kothay ", " koi ", " bhai ", " vai ", " vaia ", " dosto ",
            " ache ", " achi ", " aci ", " acho ", " achen ", " achis ", " korcho ", " koro ", " koros ",
            " koren ", " korteso ", " khaico ", " khaisos ", " khaiso ", " kheyechen ", " khawa ",
            " bhalo ", " valo ", " tumi ", " tmi ", " tui ", " apni ", " amar ", " tomar ", " tor ", " apnar ",
            " haa ", " na ", " nai ", " naki ", " keno ", " kn ", " kobe ", " kokhon ", " kiser ",
            " basay ", " bashay ", " ghum ", " kaj ", " kaje ", " aso ", " asbo ", " jabo ", " jabi ",
            " jaba ", " bol ", " bolo ", " bolen ", " bolteco ", " bolcho ", " bujho ", " janabe ", " korba ",
            " accha ", " acha ", " aito ", " eito ", " hlw ", " salam ", " assalamu ", " kono ", " sob ",
            " dhonnobad ", " khobor ", " obostha ", " ektu ", " ekhon ", " ar ", " tarpor ", " sotti "
        )
        if (banglishMarkers.any { lower.contains(it) }) {
            return ScriptStyle.BANGLISH
        }
        return null
    }

    fun detectPronounStyle(text: String): PronounStyle? {
        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "
        val tuiMarkers = listOf(
            " tui ", " tor ", " toke ", " koros ", " koris ", " khaisos ", " khaisis ", " achis ",
            " asis ", " jabi ", " bolis ", " dosto ", " mama ", " তুই ", " তোর ", " তোকে ",
            " করিস ", " খাইছিস ", " আছিস ", " যাবি ", " দোস্ত "
        )
        if (tuiMarkers.any { lower.contains(it) }) return PronounStyle.TUI

        val apniMarkers = listOf(
            " apni ", " apnar ", " apnake ", " koren ", " korchen ", " kheyechen ", " achen ",
            " jaben ", " asben ", " bolun ", " bolen ", " sir ", " ভাইয়া ", " আপু ", " আপনি ", " আপনার ",
            " আপনাকে ", " করেন ", " করছেন ", " খেয়েছেন ", " আছেন ", " যাবেন ", " আসবেন ", " বলুন ", " স্যার "
        )
        if (apniMarkers.any { lower.contains(it) }) return PronounStyle.APNI

        val tumiMarkers = listOf(
            " tumi ", " tmi ", " tomar ", " tomake ", " koro ", " korcho ", " korba ", " bolteco ", " bujho ",
            " khaico ", " khaiso ", " acho ", " jaba ", " asba ", " bolo ", " তুমি ", " তোমার ", " তোমাকে ",
            " করো ", " করছো ", " খাইছো ", " আছো "
        )
        if (tumiMarkers.any { lower.contains(it) }) return PronounStyle.TUMI

        return null
    }

    fun detectTopicFromText(text: String): ConversationTopic {
        val lower = text.lowercase()
        return when {
            listOf("khaic", "khais", "kheyec", "khawa", "vat", "mangsho", "nasta", "খাইছ", "খেয়েছ", "খাওয়া", "ভাত", "নাস্তা", "eat", "food", "lunch", "dinner").any { lower.contains(it) } ->
                ConversationTopic.FOOD
            listOf("ki koro", "ki koros", "ki korc", "kaj", "basto", "busy", "কী কর", "কি কর", "কাজ", "ব্যস্ত", "working", "doing").any { lower.contains(it) } ->
                ConversationTopic.ACTIVITY_WORK
            listOf("koi", "kothay", "basay", "bashay", "কই", "কোথায়", "বাসায়", "where").any { lower.contains(it) } ->
                ConversationTopic.LOCATION
            listOf("ghum", "ratri", "night", "ঘুম", "রাত্রি", "sleep").any { lower.contains(it) } ->
                ConversationTopic.SLEEP
            listOf("basar sobai", "bhabhi", "babu", "ammu", "abbu", "বাসার সবাই", "ভাবি", "বাবু", "family").any { lower.contains(it) } ->
                ConversationTopic.FAMILY
            listOf("call", "phone", "কল", "ফোন").any { lower.contains(it) } ->
                ConversationTopic.CALL
            listOf("kobe", "kokhon", "dekha", "asba", "jaba", "কবে", "কখন", "দেখা", "আসবা", "যাবা", "meet").any { lower.contains(it) } ->
                ConversationTopic.PLAN_MEET
            listOf("kemon", "kmn", "khobor", "obostha", "bhalo", "aito", "eito", "কেমন", "খবর", "অবস্থা", "ভালো").any { lower.contains(it) } ->
                ConversationTopic.WELLBEING
            else -> ConversationTopic.NONE
        }
    }

    fun analyzeConversationThread(
        messages: List<ChatMessage>,
        extraExcludedReplies: Set<String> = emptySet()
    ): ThreadContext {
        val window = messages.takeLast(5)
        val lastIncomingMsg = window.lastOrNull { it.sender == "Incoming" }?.text?.trim()
            ?: window.lastOrNull()?.text?.trim()
            ?: ""

        val prior = if (window.size > 1) window.dropLast(1) else emptyList()
        val prevOwn = HashSet<String>().apply {
            addAll(extraExcludedReplies)
            window.filter { it.sender == "Me" }.forEach { add(it.text.trim()) }
        }

        var script = detectScriptStyle(lastIncomingMsg)
        if (script == null) {
            for (m in prior.reversed()) {
                val s = detectScriptStyle(m.text)
                if (s != null) {
                    script = s
                    break
                }
            }
        }
        val finalScript = script ?: ScriptStyle.BANGLISH

        var pronoun = detectPronounStyle(lastIncomingMsg)
        if (pronoun == null) {
            for (m in prior.reversed()) {
                val p = detectPronounStyle(m.text)
                if (p != null) {
                    pronoun = p
                    break
                }
            }
        }
        val finalPronoun = pronoun ?: PronounStyle.TUMI

        var ongoingTopic = ConversationTopic.NONE
        for (m in prior.reversed()) {
            val t = detectTopicFromText(m.text)
            if (t != ConversationTopic.NONE) {
                ongoingTopic = t
                break
            }
        }

        return ThreadContext(
            windowMessages = window,
            priorMessages = prior,
            lastIncomingMessage = lastIncomingMsg,
            scriptStyle = finalScript,
            pronounStyle = finalPronoun,
            previousTopic = ongoingTopic,
            previousOwnReplies = prevOwn
        )
    }

    private fun pickUniqueReply(
        candidates: List<String>,
        previousOwnReplies: Set<String>,
        seedText: String
    ): String {
        val lowerExcluded = previousOwnReplies.map { it.trim().lowercase() }.toSet()
        val fresh = candidates.filter { it.trim().lowercase() !in lowerExcluded }
        if (fresh.isNotEmpty()) {
            // Deterministic yet message-dependent rotation so different incoming messages pick different items
            val idx = abs(seedText.hashCode() + previousOwnReplies.size * 7) % fresh.size
            return fresh[idx]
        }
        // If all candidates were already used in a long chat, append a natural conversational suffix to make it unique
        val base = candidates[abs(seedText.hashCode()) % candidates.size]
        val suffixes = listOf(" বলো!", " বাই দ্য ওয়ে, সব ঠিকঠাক তো?", " আর কী অবস্থা?", "!", " ব্রো!")
        for (s in suffixes) {
            val modified = base.trimEnd('.', '!', '?') + s
            if (modified.lowercase() !in lowerExcluded) return modified
        }
        return base
    }

    fun buildSmartFallbackReplies(
        messages: List<ChatMessage>,
        extraExcludedReplies: Set<String> = emptySet()
    ): ReplyOptions {
        val ctx = analyzeConversationThread(messages, extraExcludedReplies)
        val lastIncoming = ctx.lastIncomingMessage
        val script = ctx.scriptStyle
        val pronoun = ctx.pronounStyle
        val prevTopic = ctx.previousTopic
        val previousOwn = ctx.previousOwnReplies

        val lower = lastIncoming.lowercase().trim()
        val padded = " " + lower.replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "
        val normalizedShort = padded.trim().replace(Regex("\\s+"), " ")

        fun hasAny(vararg words: String): Boolean {
            return words.any { w ->
                if (w.startsWith(" ") || w.endsWith(" ")) padded.contains(w)
                else lower.contains(w)
            }
        }

        // =========================================================================
        // A. MULTI-MESSAGE CONTEXTUAL FOLLOW-UP RESOLUTION
        // =========================================================================

        // A1. Reciprocal short follow-ups ("tumi?", "tui?", "apni?", "Haa. Tumi?", "তুমি?", "তুই?")
        if (normalizedShort in listOf(
                "tumi", "ar tumi", "tui", "ar tui", "apni", "ar apni",
                "haa tumi", "haa tui", "ha tumi", "ha tui", "ji apni", "haa apni",
                "তুমি", "আর তুমি", "তুই", "আর তুই", "আপনি", "আর আপনি",
                "হ্যাঁ তুমি", "হ্যাঁ তুই", "জি আপনি", "হ্যাঁ আপনি", "you", "and you"
            )
        ) {
            return when (prevTopic) {
                ConversationTopic.FOOD -> when (script) {
                    ScriptStyle.BANGLA -> ReplyOptions(
                        friendly = pickUniqueReply(listOf(
                            if (pronoun == PronounStyle.TUI) "হ্যাঁ দোস্ত, আমিও একটু আগেই ভাত খেয়ে নিলাম!" else "হ্যাঁ, আমিও একটু আগেই খাওয়া শেষ করলাম আলহামদুলিল্লাহ!",
                            "হ্যাঁ আমারও খাওয়া শেষ! এখন একটু বিশ্রাম নিচ্ছি।"
                        ), previousOwn, lastIncoming),
                        polite = "জি আলহামদুলিল্লাহ, আমিও কিছুক্ষণ আগে খেয়ে নিয়েছি।",
                        professional = "জি ধন্যবাদ, আমারও খাওয়া সম্পন্ন হয়েছে।",
                        detectedLanguage = "Bangla (Context: Food)"
                    )
                    ScriptStyle.BANGLISH -> ReplyOptions(
                        friendly = pickUniqueReply(listOf(
                            if (pronoun == PronounStyle.TUI) "Haa dosto, amio ektu agei kheye nilam!" else "Haa, amio ektu agei khawa shesh korlam Alhamdulillah!",
                            "Haa amaro khawa shesh! Ekhon ektu bose achi."
                        ), previousOwn, lastIncoming),
                        polite = "Ji Alhamdulillah, amio kichukhon age kheye niyechi.",
                        professional = "Ji dhonnobad, amaro khawa shesh hoyeche.",
                        detectedLanguage = "Banglish (Context: Food)"
                    )
                    ScriptStyle.ENGLISH -> ReplyOptions(
                        friendly = "Yep, I already ate a little while ago too!",
                        polite = "Yes, I have had my meal as well, thank you!",
                        professional = "Yes, thank you, I have completed my meal as well.",
                        detectedLanguage = "English (Context: Food)"
                    )
                }
                ConversationTopic.ACTIVITY_WORK -> when (script) {
                    ScriptStyle.BANGLA -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "আমিও এইতো বাসায় বসে একটু ফোন দেখছি রে!" else "আমিও এইতো বাসায় বসে একটু বিশ্রাম নিচ্ছি!",
                        polite = "জি, আমিও বাসায় বসে টুকটাক কাজ করছি।",
                        professional = "জি, আমিও বর্তমানে আমার হাতের কাজগুলো গুছিয়ে নিচ্ছি।",
                        detectedLanguage = "Bangla (Context: Activity)"
                    )
                    else -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "Amio eito basay bose ektu rest nicchi re!" else "Amio eito basay bose ektu rest nicchi!",
                        polite = "Ji, amio basay bose ektu kaj korchi.",
                        professional = "Ji, amio bortomane amar hater kaj gulo korchi.",
                        detectedLanguage = "Banglish (Context: Activity)"
                    )
                }
                else -> when (script) {
                    ScriptStyle.BANGLA -> ReplyOptions(
                        friendly = "আলহামদুলিল্লাহ আমিও বেশ ভালো আছি!",
                        polite = "জি আলহামদুলিল্লাহ, আপনার দোয়ায় আমিও ভালো আছি।",
                        professional = "জি ধন্যবাদ, আলহামদুলিল্লাহ আমিও ভালো আছি।",
                        detectedLanguage = "Bangla (Context)"
                    )
                    else -> ReplyOptions(
                        friendly = "Alhamdulillah amio bhalo achi!",
                        polite = "Ji Alhamdulillah, amio bhalo achi.",
                        professional = "Ji dhonnobad, Alhamdulillah amio bhalo achi.",
                        detectedLanguage = "Banglish (Context)"
                    )
                }
            }
        }

        // A2. Follow-up "Na / এখনো না" when the previous 4-5 messages were about Food
        if (normalizedShort in listOf("na", "nah", "na re", "na bhai", "na dosto", "ekhono na", "khai nai", "না", "নাহ", "এখনো না", "খাই নি", "খাইনি", "not yet", "no")) {
            if (prevTopic == ConversationTopic.FOOD || hasAny("khai")) {
                return when (script) {
                    ScriptStyle.BANGLA -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "আরে এখনো খাসনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নে দোস্ত!"
                        else "আরে এখনো খাওনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নাও!",
                        polite = "ওহ আচ্ছা, দেরি না করে সময়মতো খাবারটা খেয়ে নিন।",
                        professional = "অনুগ্রহ করে সময়মতো খাবার গ্রহণ করে নিন, শরীরের যত্ন নেওয়া জরুরি।",
                        detectedLanguage = "Bangla (Context: Food)"
                    )
                    ScriptStyle.BANGLISH -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "Areh ekhono khas nai keno? Deri na kore taratari kheye ne dosto!"
                        else "Areh ekhono khao nai keno? Deri na kore taratari kheye nao!",
                        polite = "Oh accha, deri na kore somoymoto khabar ta kheye nin.",
                        professional = "Onugroho kore somoymoto khabar kheye niben.",
                        detectedLanguage = "Banglish (Context: Food)"
                    )
                    ScriptStyle.ENGLISH -> ReplyOptions(
                        friendly = "Oh, how come you haven't eaten yet? Go grab something to eat soon!",
                        polite = "Oh I see! Please make sure to have your meal soon.",
                        professional = "Please take a moment to have your meal when convenient.",
                        detectedLanguage = "English (Context: Food)"
                    )
                }
            }
        }

        // A3. Clarification / Confusion / Teasing ("tmi ki kotha bujho na", "ki sob bolteco", "ki confirm korba", "ki janabe", "ki bolcho", "মানে কি")
        if (hasAny("kotha bujho", "kotha bujhis", "ki sob bol", "ki boltec", "ki bolcho", "ki bolis", "ki confirm", "ki janab", "mane ki", "pagol naki", "কথা বুঝো", "কী সব বল", "কি সব বল", "কী বলছ", "কি বলছ", "কী জানাব", "কী কনফার্ম", "মানে কী")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "আরে না দোস্ত, ফোনে অন্য একটা কাজ করছিলাম তো তাই খেয়াল করিনি! এবার বল কী বলছিলি?"
                        else "আরে না, আসলে অন্য একটা কাজে একটু অন্যমনস্ক ছিলাম! বলো কী বলছিলে?",
                        "হাহা, সরি ভাই! তাড়াহুড়োয় ভুল মেসেজ চলে গেছে। বলো কী খবর তোমার?",
                        "আরে বুঝতে পেরেছি! একটু ব্যস্ত ছিলাম তো তাই ঠিকমতো লেখার সময় পাইনি।"
                    ), previousOwn, lastIncoming),
                    polite = "দুঃখিত, আমি একটু অন্য কাজে ব্যস্ত থাকায় ঠিকমতো খেয়াল করতে পারিনি। অনুগ্রহ করে আবার বলবেন?",
                    professional = "অনিচ্ছাকৃত ভুল বোঝাবুঝির জন্য দুঃখিত। আপনার মূল বিষয়টি অনুগ্রহ করে জানালে সুবিধা হবে।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Areh na dosto, phone e onno ekta kaj korchilam tai kheyal kori nai! Ebar bol ki bolchili?"
                        else "Areh na, ashole onno ekta kaje ektu busy chilam tai kheyal kori nai! Bolo ki bolchile?",
                        "Haha sorry bhai, tarahuroy ulta-palta type hoye gese! Ekhon bolo ki obostha?",
                        "Areh bujhchi to! Ektu kaje atke chilam tai thikmoto likhte pari nai, bolo ebar!",
                        "Haha na re bhai, matha ektu onno dike chilo! Bolo ki khobor tomar?"
                    ), previousOwn, lastIncoming),
                    polite = "Dukkhito, ami ektu onno kaje basto thakay thikmoto kheyal korte pari nai. Abar bolben?",
                    professional = "Onicchakrito bhul bojhabujhir jonno dukkhito. Apnar bishoyti abar bolle subidha hobe.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        "Haha my bad! I was distracted doing something else on my phone. What were you saying?",
                        "Oops, sorry about that! I was multitasking. Tell me what's up!"
                    ), previousOwn, lastIncoming),
                    polite = "I apologize for the confusion, I was a bit distracted. Could you please say that again?",
                    professional = "Apologies for the confusion. Please let me know how I can assist you.",
                    detectedLanguage = "English"
                )
            }
        }

        // A4. Casual Status Updates ("aito aci", "eito achi", "kono khobor nai", "temon kichu na", "চলছে", "এইতো আছি", "কোনো খবর নাই")
        if (hasAny("aito ac", "eito ach", "eito ac", "aito ach", "kono khobor nai", "khobor nai", "temon kichu na", "cholche", "এইতো আছি", "কোনো খবর নাই", "তেমন কিছু না", "চলছে আরকি")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "যাক ভালো থাকলেই হলো দোস্ত! আজকে সারাদিন কী করলি?"
                        else "যাক আলহামদুলিল্লাহ! আজকে সারাদিন কী করলে বলো?",
                        "এইতো, আমাদেরও একই অবস্থা—দিনকাল একরকম চলে যাচ্ছে আরকি!",
                        "ভালো থাকলেই ভালো! বাসার সবার কী অবস্থা?"
                    ), previousOwn, lastIncoming),
                    polite = "আলহামদুলিল্লাহ, ভালো থাকলেই ভালো। আপনার বাসার সবাই কেমন আছেন?",
                    professional = "জি আলহামদুলিল্লাহ। আপনার সব কাজ ভালোভাবে চলছে আশা করি।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Jak bhalo thaklei holo dosto! Ajke saradin ki korli bol?"
                        else "Jak Alhamdulillah! Ajke saradin ki korla bolo?",
                        "Amaro eki obostha bhai, eirom e cholche dinkal! Basar sobai bhalo to?",
                        "Bhalo thaklei holo! Ekhon ki basay bose acho naki baire?",
                        "Hmm bujhlam! Cha-nasta khaico naki ekhono?"
                    ), previousOwn, lastIncoming),
                    polite = "Alhamdulillah, bhalo thaklei bhalo. Apnar basar sobai kemon achen?",
                    professional = "Ji Alhamdulillah. Asha kori apnar sob kajkomo bhalovabe cholche.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = "Glad to hear you're doing alright! What have you been up to today?",
                    polite = "Glad everything is going well! How is everyone at home?",
                    professional = "Glad to hear that. I hope everything continues to go smoothly.",
                    detectedLanguage = "English"
                )
            }
        }

        // A5. Single-word "Ki" / "Ki?" / "কী?" / "কি?"
        if (normalizedShort in listOf("ki", "kii", "ki re", "ki bhai", "কী", "কি", "কী রে", "কি ভাই", "what")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "কিছু না দোস্ত, এমনিই জিজ্ঞেস করলাম তোর কী অবস্থা!"
                        else "তেমন কিছু না, এমনিই খোঁজ নিচ্ছিলাম তোমার কী খবর!",
                        "বলছিলাম যে আজকে কী করছো এখন?"
                    ), previousOwn, lastIncoming),
                    polite = "জি, বিশেষ কিছু না—আপনি কেমন আছেন সেটাই খোঁজ নিচ্ছিলাম।",
                    professional = "জি, আপনার সাথে কুশল বিনিময় করছিলাম। কোনো প্রয়োজন থাকলে জানাতে পারেন।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Kichu na dosto, emnii khoj nicchilam tor ki obostha!"
                        else "Temon kichu na, emnii jiggesh korchilam tomar ki khobor!",
                        "Bolchilam je ekhon ki korcho basay bose?",
                        "Emnii bhai, dekhlam online acho tai knock dilam!"
                    ), previousOwn, lastIncoming),
                    polite = "Ji, bishesh kichu na—apni kemon achen setai khoj nicchilam.",
                    professional = "Ji, apnar sathe kushol binimoy korchilam.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = "Nothing much, just checking in to see how you're doing!",
                    polite = "Nothing urgent, just checking in to hope you are doing well!",
                    professional = "Just following up with you. Please let me know if you need anything.",
                    detectedLanguage = "English"
                )
            }
        }

        // A6. Follow-up "Kiser kaj? / Ki kaj?"
        if (hasAny("kiser", "ki kaj", "কিসের", "কী কাজ", "কি কাজ") || (prevTopic == ConversationTopic.ACTIVITY_WORK && hasAny("ki ", "keno", "কী ", "কেন"))) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "এইতো নিজের একটা প্রজেক্ট আর বাসার টুকটাক কাজ করছি রে। একটু পরই ফ্রি হবো!"
                        else "এইতো নিজের একটু জরুরি কাজ আর ফোনের কিছু সেটআপ করছিলাম। অল্প কিছুক্ষণের মধ্যেই শেষ হয়ে যাবে!",
                        "বাসার কিছু দরকারি কাজ সেরে নিচ্ছিলাম, প্রায় শেষের দিকেই!"
                    ), previousOwn, lastIncoming),
                    polite = "জি, ব্যক্তিগত ও বাসার কিছু প্রয়োজনীয় কাজ গুছিয়ে নিচ্ছিলাম। কিছুক্ষণের মধ্যেই শেষ হবে।",
                    professional = "বর্তমানে একটি প্রজেক্টের কাজ সম্পন্ন করছি। কাজটি শেষ করেই আপনার সাথে বিস্তারিত কথা বলছি।",
                    detectedLanguage = "Bangla (Context: Work)"
                )
                else -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Eito nijer ekta project ar basar tukitaki kaj korchi re. Ektu porei free hobo!"
                        else "Eito nijer ektu dorkari kaj korchilam. Olpo kichukhoner moddhei shesh hoye jabe!",
                        "Phone e ekta app setup ar basar kichu kaj korchilam, pray shesh!"
                    ), previousOwn, lastIncoming),
                    polite = "Ji, basar o nijer kichu proyojoniyo kaj guchiye nicchilam.",
                    professional = "Bortomane ekti project er kaj sompanno korchi. Shesh korei apnake janacchi.",
                    detectedLanguage = "Banglish (Context: Work)"
                )
            }
        }

        // =========================================================================
        // B. DIRECT INTENT ANALYSIS OF THE LAST MESSAGE
        // =========================================================================

        // 1. SALAM / ISLAMIC GREETING
        if (hasAny("salam", "assalamu", "slm", "সালাম", "আসসালামু")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "ওয়ালাইকুম আসসালাম দোস্ত! কী খবর তোর?" else "ওয়ালাইকুম আসসালাম! কেমন আছো বলো?",
                        "ওয়ালাইকুম আসসালাম ভাই! সব কেমন চলছে?"
                    ), previousOwn, lastIncoming),
                    polite = "ওয়ালাইকুম আসসালাম ওয়া রাহমাতুল্লাহ। আলহামদুলিল্লাহ ভালো আছি, আপনি কেমন আছেন?",
                    professional = "ওয়ালাইকুম আসসালাম। আশা করি ভালো আছেন, বলুন কীভাবে সাহায্য করতে পারি?",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Walaikum Assalam dosto! Tor ki khobor bol?" else "Walaikum Assalam! Kemon acho bolo?",
                        "Walaikum Assalam bhai! Ki obostha tomar?"
                    ), previousOwn, lastIncoming),
                    polite = "Walaikum Assalam Wa Rahmatullah. Alhamdulillah bhalo achi, apni kemon achen?",
                    professional = "Walaikum Assalam. Asha kori bhalo achen, bolun kivabe sahajjo korte pari?",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 2. WHAT DID YOU EAT / MENU
        if (hasAny("ki diye", "ki khaila", "ki khaiso", "ki ranna", "কী দিয়ে", "কি দিয়ে", "কী খাইছ", "কি খাইছ", "কী রান্না")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "ভাত আর মাংস দিয়ে খাইলাম রে। তুই কী দিয়ে খাইলি?" else "ভাত আর মুরগির মাংস দিয়ে খাইলাম। তুমি কী দিয়ে খাইছো?",
                        "আজকে ভাত, ডাল আর ভাজি দিয়ে খেয়েছি। তোমার কী মেনু ছিল?"
                    ), previousOwn, lastIncoming),
                    polite = "জি, ভাত ও মাছ দিয়ে খেয়েছি আলহামদুলিল্লাহ। আপনি কী দিয়ে খেয়েছেন?",
                    professional = "জি ধন্যবাদ, বাসার খাবারই খেয়েছি। আশা করি আপনারও খাওয়া সম্পন্ন হয়েছে।",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Vat ar mangsho diye khailam re. Tui ki diye khaili?" else "Vat ar murgir mangsho diye khailam. Tumi ki diye khaico?",
                        "Ajke vat, dal ar vaji diye kheyechi. Tomar ki menu chilo?"
                    ), previousOwn, lastIncoming),
                    polite = "Ji, vat ar mach diye kheyechi Alhamdulillah. Apni ki diye kheyechen?",
                    professional = "Ji dhonnobad, basar khabar e kheyechi. Asha kori apnaro khawa hoyeche.",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 3. HAVE YOU EATEN / MEAL INQUIRY
        if (hasAny("khaic", "khais", "kheyec", "khawa", "khail", "nasta", "lunch", "dinner", "খাইছ", "খেয়েছ", "খাওয়া", "নাস্তা")) {
            val isNasta = hasAny("nasta", "cha ", "নাস্তা", "চা ")
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (isNasta) "হ্যাঁ, চা-নাস্তা একটু আগেই শেষ করলাম। তুমি নাস্তা করছো?"
                        else if (pronoun == PronounStyle.TUI) "হ্যাঁ দোস্ত, একটু আগেই খাইলাম। তুই খাইছিস?"
                        else "হ্যাঁ, আলহামদুলিল্লাহ একটু আগেই খাইলাম। তুমি খাইছো?",
                        if (pronoun == PronounStyle.TUI) "এইতো কেবল খাওয়া শেষ করলাম। তোর খাওয়া হইছে?"
                        else "এইতো কিছুক্ষণ আগে খাওয়া শেষ করলাম। তোমার খাওয়া দাওয়া হইছে?"
                    ), previousOwn, lastIncoming),
                    polite = if (isNasta) "জি আলহামদুলিল্লাহ, নাস্তা করেছি। আপনি নাস্তা করেছেন?"
                    else "জি আলহামদুলিল্লাহ, আমার খাওয়া হয়েছে। আপনি খেয়েছেন?",
                    professional = "জি ধন্যবাদ, আমার খাওয়া সম্পন্ন হয়েছে। আশা করি আপনিও সময়মতো খেয়েছেন।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (isNasta) "Haa, cha-nasta ektu agei korlam. Tumi nasta korcho?"
                        else if (pronoun == PronounStyle.TUI) "Haa dosto, ektu agei khailam. Tui khaisos?"
                        else "Haa, ektu agei khailam Alhamdulillah. Tumi khaico?",
                        if (pronoun == PronounStyle.TUI) "Eito kebol khawa shesh korlam. Tor khawa hoise?"
                        else "Eito kichukhon age khawa shesh korlam. Tomar khawa hoise?"
                    ), previousOwn, lastIncoming),
                    polite = if (isNasta) "Ji Alhamdulillah, nasta korechi. Apni nasta korechen?"
                    else "Ji Alhamdulillah, amar khawa hoyeche. Apni kheyechen?",
                    professional = "Ji dhonnobad, amar khawa shesh hoyeche. Asha kori apnio kheyechen.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        "Yeah, just finished eating a little while ago! Did you eat?",
                        "Yep, had my meal! What about you, have you eaten yet?"
                    ), previousOwn, lastIncoming),
                    polite = "Yes, I have eaten, thank you for asking! Have you had your meal?",
                    professional = "Yes, thank you. I have already had my meal. I hope you had yours as well.",
                    detectedLanguage = "English"
                )
            }
        }

        // 4. WHAT ARE YOU DOING
        if (hasAny("ki koro", "ki koros", "ki korc", "ki kortes", "ki koris", "কী কর", "কি কর", "what are you doing", "wyd", "whatcha doing")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "এইতো দোস্ত, বাসায় বসে ফোন চাপছি। তুই কী করিস?"
                        else "এইতো বাসায় বসে আছি, একটু ফোন দেখছিলাম। তুমি কী করছো?",
                        if (pronoun == PronounStyle.TUI) "তেমন কিছু না রে, একটু বিশ্রাম নিচ্ছি। তোর কী অবস্থা?"
                        else "এইতো একটু বিশ্রাম নিচ্ছি। তোমার খবর কী বলো?",
                        "বাসায় বসে একটু ইউটিউব দেখছিলাম। তুমি কী করছো এখন?"
                    ), previousOwn, lastIncoming),
                    polite = "জি, এইতো বাসায় একটু কাজ করছিলাম। আপনি কী করছেন এখন?",
                    professional = "বর্তমানে একটি জরুরি কাজ পর্যালোচনা করছি। কোনো বিষয় থাকলে বলতে পারেন।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Eito dosto, basay bose phone chapchi. Tui ki koros?"
                        else "Eito basay bose achi, ektu rest nicchi. Tumi ki korcho?",
                        if (pronoun == PronounStyle.TUI) "Temon kichu na re, ektu kaj korchilam. Tor ki khobor?"
                        else "Eito ektu hater kaj sarchilam. Tomar ki obostha bolo?",
                        "Basay bose ektu phone dekhchilam. Tumi ki korteso ekhon?"
                    ), previousOwn, lastIncoming),
                    polite = "Ji, eito basay ektu kaj korchilam. Apni ki korchen ekhon?",
                    professional = "Bortomane ektu kaje basto achi. Kono proyojon thakle bolte paren.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        "Just chilling at home and checking my phone. What are you up to?",
                        "Nothing much, just taking a short break! What about you?"
                    ), previousOwn, lastIncoming),
                    polite = "I'm just working on a few things at home. How about you?",
                    professional = "I am currently attending to some tasks. Please let me know how I can help you.",
                    detectedLanguage = "English"
                )
            }
        }

        // 5. WHERE ARE YOU
        if (hasAny(" koi ", "koi?", "kothay", "basay naki", "bashay naki", "কই", "কোথায়", "বাসায় নাকি", "where are you", "wya") || lower == "koi") {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "আমি এখন বাসাতেই আছি রে। তুই কই?"
                        else "আমি এখন বাসাতেই আছি। তুমি কোথায়?",
                        "এইতো বাসায় আছি। তুমি কোথায় আছো এখন?"
                    ), previousOwn, lastIncoming),
                    polite = "জি, আমি এখন বাসায় আছি। আপনি কোথায় আছেন?",
                    professional = "জি, আমি বর্তমানে আমার নির্ধারিত স্থানেই আছি। কোনো প্রয়োজন থাকলে জানাতে পারেন।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Ami ekhon basatei achi re. Tui koi?"
                        else "Ami ekhon basay achi. Tumi kothay?",
                        "Eito basay achi bhai. Tumi koi acho ekhon?"
                    ), previousOwn, lastIncoming),
                    polite = "Ji, ami ekhon basay achi. Apni kothay achen?",
                    professional = "Ji, ami bortomane amar sthane achi. Kono dorkar thakle janaben.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = "I'm at home right now. Where are you?",
                    polite = "I am currently at home. Where are you right now?",
                    professional = "I am at my usual location at the moment. Please let me know if you need anything.",
                    detectedLanguage = "English"
                )
            }
        }

        // 6. HOW ARE YOU / WHAT'S UP
        if (hasAny("kemon", "kmn", "ki khobor", "ki obostha", "কেমন", "কী খবর", "কি খবর", "কী অবস্থা", "কি অবস্থা", "how are you", "how r u", "what's up", "whats up")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "আলহামদুলিল্লাহ ভালো আছি দোস্ত! তোর কী খবর বল?"
                        else "আলহামদুলিল্লাহ বেশ ভালো আছি! তোমার কী খবর বলো?",
                        "এইতো আলহামদুলিল্লাহ সব ভালো চলছে। তোমার দিনকাল কেমন যাচ্ছে?"
                    ), previousOwn, lastIncoming),
                    polite = "জি আলহামদুলিল্লাহ, আপনার দোয়ায় ভালো আছি। আপনি কেমন আছেন?",
                    professional = "আলহামদুলিল্লাহ ভালো আছি। আশা করি আপনিও সুস্থ ও ভালো আছেন।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Alhamdulillah bhalo achi dosto! Tor ki khobor bol?"
                        else "Alhamdulillah bhalo achi! Tomar ki khobor bolo?",
                        "Eito Alhamdulillah sob bhalo cholche. Tomar dinkal kemon jacche?",
                        "Alhamdulillah bhalo! Ajke ki korcho saradin?"
                    ), previousOwn, lastIncoming),
                    polite = "Ji Alhamdulillah, bhalo achi. Apni kemon achen?",
                    professional = "Alhamdulillah bhalo achi. Asha kori apnio sustho o bhalo achen.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        "Doing great, Alhamdulillah! How's everything going with you?",
                        "All good on my end! How have you been?"
                    ), previousOwn, lastIncoming),
                    polite = "I am doing well, thank you for asking! How are you doing?",
                    professional = "I am doing well, thank you. I hope everything is going smoothly on your end.",
                    detectedLanguage = "English"
                )
            }
        }

        // 7. SLEEP / LATE NIGHT / GOOD MORNING
        if (hasAny("ghum", "good night", "gn ", "good morning", "gm ", "ঘুম", "শুভ রাত্রি", "শুভ সকাল", "sleep")) {
            val isMorning = hasAny("morning", "gm ", "সকাল")
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = if (isMorning) "শুভ সকাল! ঘুম থেকে উঠলে কখন?"
                    else if (pronoun == PronounStyle.TUI) "এইতো একটু পরেই ঘুমাবো রে। তুই ঘুমাবি না?"
                    else "এইতো আর কিছুক্ষণ পরই ঘুমিয়ে পড়বো। তুমি ঘুমাওনি এখনো?",
                    polite = if (isMorning) "শুভ সকাল! আশা করি আপনার দিনটি সুন্দর কাটবে।"
                    else "জি, কিছুক্ষণের মধ্যেই ঘুমিয়ে পড়বো। শুভ রাত্রি, ভালো থাকবেন।",
                    professional = if (isMorning) "শুভ সকাল। আপনার দিনটি শুভ হোক।"
                    else "শুভ রাত্রি। আগামীকাল কথা হবে ইনশাআল্লাহ।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = if (isMorning) "Good morning! Ghum theke uthla kokhon?"
                    else if (pronoun == PronounStyle.TUI) "Eito ektu porei ghumabo re. Tui ghumabi na?"
                    else "Eito ektu porei ghumabo. Tumi ghumao nai ekhono?",
                    polite = if (isMorning) "Shuvo sokal! Asha kori apnar dinti bhalo katbe."
                    else "Ji, ektu porei ghumiye porbo. Shuvo ratri, bhalo thakben.",
                    professional = if (isMorning) "Good morning. Wishing you a productive day ahead."
                    else "Shuvo ratri. Agamikal kotha hobe InshaAllah.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = if (isMorning) "Good morning! Hope you have an awesome day!"
                    else "Heading to bed pretty soon! Aren't you sleeping yet?",
                    polite = if (isMorning) "Good morning! Wishing you a lovely day ahead."
                    else "Good night! Sleep well and take care.",
                    professional = if (isMorning) "Good morning! Wishing you a great day."
                    else "Good night. We will catch up tomorrow.",
                    detectedLanguage = "English"
                )
            }
        }

        // 8. FAMILY / HOME WELL-BEING
        if (hasAny("basar sobai", "bashar sobai", "bhabhi", "vabi", "babu", "ammu", "abbu", "family", "বাসার সবাই", "ভাবি", "বাবু", "আম্মু", "আব্বু")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = "আলহামদুলিল্লাহ, বাসার সবাই ভালো আছে। তোমাদের বাসার সবাই কেমন আছে?",
                    polite = "জি আলহামদুলিল্লাহ, দোয়ায় বাসার সবাই ভালো আছে। আপনার পরিবারের সবাই কেমন আছেন?",
                    professional = "আলহামদুলিল্লাহ পরিবারের সবাই সুস্থ আছেন। খোঁজ নেওয়ার জন্য আন্তরিক ধন্যবাদ।",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = "Alhamdulillah, basar sobai bhalo ache! Tomader basar sobai kemon ache?",
                    polite = "Ji Alhamdulillah, basar sobai bhalo ache. Apnar poribarer sobai kemon achen?",
                    professional = "Alhamdulillah poribarer sobai sustho achen. Khoj newar jonno onek dhonnobad.",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 9. CALL / PHONE
        if (hasAny("call", "phone", "কল", "ফোন")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = "হ্যাঁ এখন ফ্রি আছি, কল দিতে পারো!",
                    polite = "জি, আমি এখন কথা বলতে পারবো। আপনি চাইলে কল দিতে পারেন।",
                    professional = "জি, আপনি এখন কল করতে পারেন অথবা একটু পর আমিই কল করছি।",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = "Haa ekhon free achi, call dite paro!",
                    polite = "Ji, ami ekhon free achi. Apni chaile call dite paren.",
                    professional = "Ji, apni ekhon call korte paren othoba ektu por ami call dichhi.",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 10. BUSY / FREE / MEETING / WHEN
        if (hasAny("free", "busy", "basto", "kobe", "kokhon", "dekha", "asba", "asbi", "jaba", "jabi", "ফ্রি", "ব্যস্ত", "কবে", "কখন", "দেখা", "আসবা", "যাবা")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "আমি এখন ফ্রি আছি দোস্ত, বল কী প্ল্যান?"
                        else "আমি এখন মোটামুটি ফ্রি আছি, বলো কী প্ল্যান?",
                        "হাতের কাজটা প্রায় শেষ, একটু পরই একদম ফ্রি হয়ে যাবো!"
                    ), previousOwn, lastIncoming),
                    polite = "জি, আমি কিছুক্ষণের মধ্যেই ফ্রি হচ্ছি। বলুন কীভাবে সাহায্য করতে পারি?",
                    professional = "আমি আমার সময়সূচি দেখে খুব দ্রুত আপনাকে জানাচ্ছি।",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Ami ekhon free achi dosto, bol ki plan?"
                        else "Ami ekhon motamuti free achi, bolo ki plan?",
                        "Hater kajta pray shesh, ektu porei free hoye jabo!"
                    ), previousOwn, lastIncoming),
                    polite = "Ji, ami kichukhoner moddhei free hocchi. Bolun ki bishoy?",
                    professional = "Ami amar schedule dekhe khub druto apnake janacchi.",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 11. SHORT GREETINGS
        if (lower in listOf("hy", "hi", "hlw", "hello", "hey", "oi", "oii", "kire", "ki re", "vai", "bhai", "dosto", "হাই", "হ্যালো", "ওই", "কিরে", "ভাই", "দোস্ত") ||
            lower.startsWith("hi ") || lower.startsWith("hlw ") || lower.startsWith("hello ") || lower.startsWith("hey ")
        ) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI || lower.contains("কিরে") || lower.contains("ওই")) "হ্যাঁ দোস্ত বল, কী খবর তোর?"
                        else "হ্যালো! কী খবর, কেমন আছো?",
                        "হ্যাঁ ভাই বলো, কী অবস্থা?"
                    ), previousOwn, lastIncoming),
                    polite = "হ্যালো! কেমন আছেন আপনি? সব ভালো তো?",
                    professional = "হ্যালো! আশা করি ভালো আছেন। বলুন কীভাবে সাহায্য করতে পারি?",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI || lower.contains("kire") || lower.contains("oi")) "Haa dosto bol, ki khobor tor?"
                        else "Hey! Ki khobor bolo, kemon acho?",
                        "Hlw bhai! Ki obostha tomar?",
                        "Haa bolo, kemon cholche sob?"
                    ), previousOwn, lastIncoming),
                    polite = "Hello! Apni kemon achen? Sob bhalo to?",
                    professional = "Hello! Asha kori bhalo achen. Kivabe sahajjo korte pari?",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = pickUniqueReply(listOf(
                        "Hey! What's up? How's it going?",
                        "Hey there! Good to hear from you, what's new?"
                    ), previousOwn, lastIncoming),
                    polite = "Hello! Hope you're doing well. How are things with you?",
                    professional = "Hello! How can I assist you today?",
                    detectedLanguage = "English"
                )
            }
        }

        // 12. SHORT ACKNOWLEDGMENTS ("hmm", "ok", "accha", "thanks")
        if (lower in listOf("hmm", "hm", "humm", "ok", "okay", "k", "accha", "acha", "thik ache", "oh", "ooh", "হুম", "হম", "আচ্ছা", "ওকে", "ঠিক আছে") ||
            hasAny("thank", "dhonnobad", "ধন্যবাদ")
        ) {
            val isThanks = hasAny("thank", "dhonnobad", "ধন্যবাদ")
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = if (isThanks) "আরে ধন্যবাদ দেওয়া লাগবে না! সব ঠিক আছে।"
                    else pickUniqueReply(listOf(
                        "হুম, তারপর বলো আর কী খবর?",
                        "আচ্ছা ঠিক আছে! আজকে কী করছো সারাদিন?",
                        "হুম বুঝলাম! বাসার সবাই ভালো তো?"
                    ), previousOwn, lastIncoming),
                    polite = if (isThanks) "আপনাকেও অসংখ্য ধন্যবাদ! ভালো থাকবেন।"
                    else "জি আচ্ছা, ঠিক আছে। আর কোনো বিষয় থাকলে জানাবেন।",
                    professional = if (isThanks) "আপনাকেও আন্তরিক ধন্যবাদ।"
                    else "জি ধন্যবাদ, বিষয়টি নোট করে রাখা হলো।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = if (isThanks) "Areh dhonnobad dewa lagbe na! Sob thik ache."
                    else pickUniqueReply(listOf(
                        "Hmm, tarpor bolo ar ki khobor?",
                        "Accha thik ache! Ajke ki korla saradin?",
                        "Hmm bujhlam! Ekhon ki basay naki baire?"
                    ), previousOwn, lastIncoming),
                    polite = if (isThanks) "Apnakeo onek dhonnobad! Bhalo thakben."
                    else "Ji accha, thik ache. Ar kichu lagle janaben.",
                    professional = if (isThanks) "Apnakeo antorik dhonnobad."
                    else "Ji thik ache, dhonnobad.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = if (isThanks) "Anytime! Happy to help!"
                    else pickUniqueReply(listOf(
                        "Sounds good! So what else is new with you?",
                        "Cool, got it! How's the rest of your day going?"
                    ), previousOwn, lastIncoming),
                    polite = if (isThanks) "You're very welcome! Have a wonderful day."
                    else "Alright, sounds good! Let me know if you need anything else.",
                    professional = if (isThanks) "You are most welcome. Please reach out anytime."
                    else "Noted, thank you.",
                    detectedLanguage = "English"
                )
            }
        }

        // 13. DIVERSE CONVERSATIONAL POOL (Never repeats, never uses confusing "confirm korchi" lines!)
        val isQuestion = lastIncoming.contains("?") || hasAny(" keno ", " kivabe ", " koto ", " kon ", " ki ", " কেন ", " কীভাবে ", " কত ", " কোন ", " কি ", " কী ", " why ", " how ", " when ", " what ", " where ")

        return when (script) {
            ScriptStyle.BANGLA -> ReplyOptions(
                friendly = pickUniqueReply(
                    if (isQuestion) {
                        if (pronoun == PronounStyle.TUI) listOf(
                            "আরে দোস্ত, এই ব্যাপারটা নিয়েই তো ভাবছিলাম—তুই কী মনে করিস?",
                            "হ্যাঁ রে, এটা আসলেই দরকারি কথা বলেছিস! একটু খুলে বল তো?",
                            "দোস্ত, আমি এখন বাসায় আছি, এই বিষয়টা নিয়ে তোর সাথেই কথা বলবো ভাবছিলাম!",
                            "ভালো কথা মনে করেছিস দোস্ত! তোর কী প্ল্যান এটা নিয়ে?"
                        ) else listOf(
                            "হ্যাঁ, ভালো কথা জিজ্ঞেস করেছো! তুমি কী ভাবছো এটা নিয়ে বলো তো?",
                            "আসলে এই বিষয়টা নিয়ে আমিও ভাবছিলাম। আমাকে আরেকটু খুলে বলো?",
                            "হ্যাঁ বুঝতে পেরেছি তোমার কথাটা! তোমার দিক থেকে কী মনে হয়?",
                            "খুব ভালো পয়েন্ট বলেছো! এটার ব্যাপারে তোমার প্ল্যান কী?"
                        )
                    } else {
                        if (pronoun == PronounStyle.TUI) listOf(
                            "হ্যাঁ দোস্ত, তোর কথাটা একদম ঠিক! তারপর আর কী অবস্থা বল?",
                            "ব্যাপারটা আসলেই তাই রে! আজকে সারাদিন আর কী করলি?",
                            "একদম খাঁটি কথা বলেছিস দোস্ত! এখন কই আছিস তুই?",
                            "বুঝলাম দোস্ত! বাসার সবার কী খবর বল?"
                        ) else listOf(
                            "হ্যাঁ, তোমার কথাটা একদম যৌক্তিক! তারপর আর কী খবর বলো?",
                            "আসলেই তাই! আজকে দিনকাল কেমন কাটছে তোমার?",
                            "বুঝতে পেরেছি! এখন কি বাসায় আছো নাকি বাইরে?",
                            "একদম ঠিক বলেছো! তা চা-নাস্তা খাওয়া হয়েছে তোমার?"
                        )
                    },
                    previousOwn,
                    lastIncoming
                ),
                polite = pickUniqueReply(listOf(
                    "জি, আপনার কথাটি বুঝতে পেরেছি। আপনি একদম ঠিক বলেছেন।",
                    "জি ধন্যবাদ বিষয়টি জানানোর জন্য। আপনার দিনকাল কেমন কাটছে?",
                    "জি, আপনার কথার সাথে আমি সম্পূর্ণ একমত। ভালো থাকবেন।"
                ), previousOwn, lastIncoming),
                professional = pickUniqueReply(listOf(
                    "আপনার বার্তার জন্য ধন্যবাদ। বিষয়টি গুরুত্বের সাথে নোট করে রাখা হলো।",
                    "ধন্যবাদ আপনাকে। এ বিষয়ে কোনো আপডেট থাকলে অবশ্যই জানাবেন।",
                    "জি ধন্যবাদ, আপনার মতামতটি অত্যন্ত গুরুত্বপূর্ণ।"
                ), previousOwn, lastIncoming),
                detectedLanguage = "Bangla"
            )
            ScriptStyle.BANGLISH -> ReplyOptions(
                friendly = pickUniqueReply(
                    if (isQuestion) {
                        if (pronoun == PronounStyle.TUI) listOf(
                            "Areh dosto, ei baparta niyei to vabchilam—tui ki mone koros?",
                            "Haa re, bhalo kotha jiggesh korli! Tui ektu khule bol to?",
                            "Dosto, ami basay achi ekhon, ei bishoyta niye tor ki plan bol?",
                            "Hmm bujhchi tor proshnota! Tor nijer ki mot eita niye?"
                        ) else listOf(
                            "Haa, bhalo kotha jiggesh korcho! Tumi ki vabcho eita niye bolo to?",
                            "Ashole ei baparta niye amio vabchilam! Arektu khule bolo?",
                            "Hmm bujhte perechi tomar kothata! Tomar dik theke ki mone hoy?",
                            "Khub bhalo kotha bolcho! Eitar bapare tomar plan ki bolo?"
                        )
                    } else {
                        if (pronoun == PronounStyle.TUI) listOf(
                            "Haa dosto, tor kothata ekdom thik! Tarpor ar ki obostha bol?",
                            "Baparta asholei tai re! Ajke saradin ar ki korli?",
                            "Ekdom sotti kotha bolsis dosto! Ekhon koi achis tui?",
                            "Bujhlam re dosto! Basar sobar ki khobor bol?"
                        ) else listOf(
                            "Haa, tomar kothata ekdom thik! Tarpor ar ki khobor bolo?",
                            "Asholei tai bhai! Ajke dinkal kemon katche tomar?",
                            "Bujhte perechi! Ekhon ki basay acho naki baire?",
                            "Hmm thik bolcho! Ta cha-nasta khawa hoise tomar?",
                            "Bujhlam tomar kothata! Ekhon ki korteso bose?"
                        )
                    },
                    previousOwn,
                    lastIncoming
                ),
                polite = pickUniqueReply(listOf(
                    "Ji, apnar kothati bujhte perechi. Apni ekdom thik bolechen.",
                    "Ji dhonnobad bishoyti bolbar jonno. Apnar dinkal kemon jacche?",
                    "Ji, apnar kothar sathe ami একমত. Bhalo thakben."
                ), previousOwn, lastIncoming),
                professional = pickUniqueReply(listOf(
                    "Apnar message er jonno dhonnobad. Bishoyti note kore rakhlam.",
                    "Dhonnobad apnake. E bishoye kono update thakle janaben.",
                    "Ji dhonnobad, apnar motamot ti khub e gurotwopurno."
                ), previousOwn, lastIncoming),
                detectedLanguage = "Banglish"
            )
            ScriptStyle.ENGLISH -> ReplyOptions(
                friendly = pickUniqueReply(listOf(
                    "Totally get what you mean! What do you think we should do about it?",
                    "Makes complete sense! How's the rest of your day going?",
                    "That's a really good point! Tell me more about what's on your mind.",
                    "I hear you! Are you at home right now or out?"
                ), previousOwn, lastIncoming),
                polite = pickUniqueReply(listOf(
                    "I completely understand your point, thank you for sharing!",
                    "That makes a lot of sense. Hope you are having a great day!"
                ), previousOwn, lastIncoming),
                professional = pickUniqueReply(listOf(
                    "Thank you for sharing this update. I have noted the details.",
                    "Thank you for your message. Please let me know if there is anything else needed."
                ), previousOwn, lastIncoming),
                detectedLanguage = "English"
            )
        }
    }
}
