package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import org.json.JSONObject
import kotlin.math.abs

object ReplyJsonParser {

    enum class PronounStyle { TUI, TUMI, APNI }
    enum class ScriptStyle { BANGLA, BANGLISH, ENGLISH }
    enum class ConversationTopic {
        NONE, FOOD, ACTIVITY_WORK, LOCATION, WELLBEING, SLEEP, FAMILY, CALL, PLAN_MEET, HEALTH, WEATHER, STUDY
    }

    data class ThreadContext(
        val windowMessages: List<ChatMessage>,
        val priorMessages: List<ChatMessage>,
        val lastIncomingMessage: String,
        val scriptStyle: ScriptStyle,
        val pronounStyle: PronounStyle,
        val previousTopic: ConversationTopic,
        val previousOwnReplies: Set<String>
    )

    fun parseAiReply(rawText: String): String {
        val cleaned = rawText
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()

        val startBrace = cleaned.indexOf('{')
        val endBrace = cleaned.lastIndexOf('}')
        if (startBrace != -1 && endBrace > startBrace) {
            try {
                val obj = JSONObject(cleaned.substring(startBrace, endBrace + 1))
                for (key in listOf("reply", "message", "response", "text", "friendly", "polite", "professional")) {
                    val v = obj.optString(key, "").trim()
                    if (v.isNotEmpty()) return v
                }
            } catch (_: Exception) {
            }
        }
        return cleaned
            .removePrefix("Reply:")
            .removePrefix("reply:")
            .removePrefix("Me:")
            .trim { it == '"' || it == '\'' || it.isWhitespace() }
            .lines()
            .firstOrNull { it.isNotBlank() }
            ?.trim() ?: ""
    }

    fun detectScriptStyle(text: String): ScriptStyle? {
        if (text.isBlank()) return null
        val hasBanglaScript = text.any { it in '\u0980'..'\u09FF' }
        if (hasBanglaScript) return ScriptStyle.BANGLA

        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\s]"), " ") + " "
        val banglishMarkers = listOf(
            " ki ", " kemon ", " kmn ", " kothay ", " koi ", " bhai ", " vai ", " vaia ", " dosto ",
            " ache ", " achi ", " aci ", " acho ", " achen ", " achis ", " korcho ", " koro ", " koros ",
            " koren ", " korteso ", " khaico ", " khaisos ", " khaiso ", " kheyechen ", " khawa ",
            " bhalo ", " valo ", " tumi ", " tmi ", " tui ", " apni ", " amar ", " tomar ", " tor ", " apnar ",
            " haa ", " na ", " nai ", " naki ", " keno ", " kn ", " kobe ", " kokhon ", " kiser ",
            " basay ", " bashay ", " ghum ", " kaj ", " kaje ", " aso ", " asbo ", " jabo ", " jabi ",
            " jaba ", " bol ", " bolo ", " boloto ", " bolen ", " bolteco ", " bolcho ", " bujho ", " janabe ",
            " korba ", " kirbo ", " korbo ", " jiggas ", " jiggesh ", " akta ", " ekta ", " jinis ", " kotha ",
            " kisui ", " kichui ", " kori ", " matro ", " suru ", " shuru ", " din ", " jasce ", " jacche ",
            " alhamdulilha ", " alhamdulillah ", " babu ", " jaan ", " jan ", " shona ", " pakhi ",
            " accha ", " acha ", " aito ", " eito ", " hlw ", " salam ", " assalamu ", " kono ", " sob ",
            " dhonnobad ", " khobor ", " obostha ", " ektu ", " ekhon ", " ar ", " tarpor ", " sotti ",
            " brishti ", " gorom ", " shorir ", " jor ", " matha ", " pora ", " exam ", " class ", " taka "
        )
        if (banglishMarkers.any { lower.contains(it) }) {
            return ScriptStyle.BANGLISH
        }
        return null
    }

    fun detectPronounStyle(text: String): PronounStyle? {
        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "
        val tuiMarkers = listOf(
            " tui ", " tor ", " toke ", " koros ", " koris ", " khaisos ", " khaisis ", " achis ",
            " asis ", " jabi ", " bolis ", " dosto ", " mama ", " তুই ", " তোর ", " তোকে ",
            " করিস ", " খাইছিস ", " আছিস ", " যাবি ", " দোস্ত "
        )
        if (tuiMarkers.any { lower.contains(it) }) return PronounStyle.TUI

        val apniMarkers = listOf(
            " apni ", " apnar ", " apnake ", " koren ", " korchen ", " kheyechen ", " achen ",
            " jaben ", " asben ", " bolun ", " bolen ", " sir ", " ভাইয়া ", " আপু ", " আপনি ", " আপনার ",
            " আপনাকে ", " করেন ", " করছেন ", " খেয়েছেন ", " আছেন ", " যাবেন ", " আসবেন ", " বলুন ", " স্যার "
        )
        if (apniMarkers.any { lower.contains(it) }) return PronounStyle.APNI

        val tumiMarkers = listOf(
            " tumi ", " tmi ", " tomar ", " tomake ", " koro ", " korcho ", " korba ", " boloto ", " bolteco ",
            " bujho ", " khaico ", " khaiso ", " acho ", " jaba ", " asba ", " bolo ", " babu ", " jaan ",
            " তুমি ", " তোমার ", " তোমাকে ", " করো ", " করছো ", " খাইছো ", " আছো ", " বাবু "
        )
        if (tumiMarkers.any { lower.contains(it) }) return PronounStyle.TUMI

        return null
    }

    fun detectTopicFromText(text: String): ConversationTopic {
        val lower = text.lowercase()
        return when {
            listOf("khaic", "khais", "kheyec", "khawa", "vat", "mangsho", "nasta", "খাইছ", "খেয়েছ", "খাওয়া", "ভাত", "নাস্তা", "eat", "food", "lunch", "dinner").any { lower.contains(it) } ->
                ConversationTopic.FOOD
            listOf("ki koro", "ki koros", "ki korc", "kaj", "basto", "busy", "কী কর", "কি কর", "কাজ", "ব্যস্ত", "working", "doing").any { lower.contains(it) } ->
                ConversationTopic.ACTIVITY_WORK
            listOf("koi", "kothay", "basay", "bashay", "কই", "কোথায়", "বাসায়", "where").any { lower.contains(it) } ->
                ConversationTopic.LOCATION
            listOf("ghum", "ratri", "night", "ঘুম", "রাত্রি", "sleep").any { lower.contains(it) } ->
                ConversationTopic.SLEEP
            listOf("basar sobai", "bashar sobai", "bhabhi", "ammu", "abbu", "বাসার সবাই", "ভাবি", "আম্মু", "আব্বু", "family").any { lower.contains(it) } ->
                ConversationTopic.FAMILY
            listOf("call", "phone", "কল", "ফোন").any { lower.contains(it) } ->
                ConversationTopic.CALL
            listOf("kobe", "kokhon", "dekha", "asba", "jaba", "কবে", "কখন", "দেখা", "আসবা", "যাবা", "meet").any { lower.contains(it) } ->
                ConversationTopic.PLAN_MEET
            listOf("shorir", "jor", "matha", "oshustho", "শরীর", "জ্বর", "মাথা", "অসুস্থ", "sick", "fever").any { lower.contains(it) } ->
                ConversationTopic.HEALTH
            listOf("brishti", "gorom", "thanda", "weather", "বৃষ্টি", "গরম", "ঠান্ডা").any { lower.contains(it) } ->
                ConversationTopic.WEATHER
            listOf("pora", "exam", "class", "college", "পড়া", "পরীক্ষা", "ক্লাস").any { lower.contains(it) } ->
                ConversationTopic.STUDY
            listOf("kemon", "kmn", "khobor", "obostha", "bhalo", "valo", "aito", "eito", "jasce", "jacche", "কেমন", "খবর", "অবস্থা", "ভালো").any { lower.contains(it) } ->
                ConversationTopic.WELLBEING
            else -> ConversationTopic.NONE
        }
    }

    fun analyzeConversationThread(
        messages: List<ChatMessage>,
        extraExcludedReplies: Set<String> = emptySet()
    ): ThreadContext {
        val window = messages.takeLast(5)
        val lastIncomingMsg = window.lastOrNull { it.sender == "Incoming" }?.text?.trim()
            ?: window.lastOrNull()?.text?.trim()
            ?: ""

        val prior = if (window.size > 1) window.dropLast(1) else emptyList()
        val prevOwn = HashSet<String>().apply {
            addAll(extraExcludedReplies)
            window.filter { it.sender == "Me" }.forEach { add(it.text.trim()) }
        }

        // Script detection: strictly prefer the script of the latest incoming message!
        var script = detectScriptStyle(lastIncomingMsg)
        if (script == null) {
            // If lastIncoming is pure Latin characters (like "Hy", "Ok", "Babu"), check prior incoming messages
            val hasBanglaChars = lastIncomingMsg.any { it in '\u0980'..'\u09FF' }
            if (!hasBanglaChars) {
                val priorIncomingBanglish = prior.filter { it.sender == "Incoming" }
                    .any { detectScriptStyle(it.text) == ScriptStyle.BANGLISH }
                script = if (priorIncomingBanglish) ScriptStyle.BANGLISH else ScriptStyle.BANGLISH
            } else {
                script = ScriptStyle.BANGLA
            }
        }
        val finalScript = script

        var pronoun = detectPronounStyle(lastIncomingMsg)
        if (pronoun == null) {
            for (m in prior.reversed()) {
                if (m.sender == "Incoming") {
                    val p = detectPronounStyle(m.text)
                    if (p != null) {
                        pronoun = p
                        break
                    }
                }
            }
        }
        val finalPronoun = pronoun ?: PronounStyle.TUMI

        var ongoingTopic = ConversationTopic.NONE
        for (m in prior.reversed()) {
            val t = detectTopicFromText(m.text)
            if (t != ConversationTopic.NONE) {
                ongoingTopic = t
                break
            }
        }

        return ThreadContext(
            windowMessages = window,
            priorMessages = prior,
            lastIncomingMessage = lastIncomingMsg,
            scriptStyle = finalScript,
            pronounStyle = finalPronoun,
            previousTopic = ongoingTopic,
            previousOwnReplies = prevOwn
        )
    }

    private fun pickUniqueReply(
        candidates: List<String>,
        previousOwnReplies: Set<String>,
        seedText: String,
        script: ScriptStyle
    ): String {
        val lowerExcluded = previousOwnReplies.map { it.trim().lowercase() }.toSet()
        val fresh = candidates.filter { it.trim().lowercase() !in lowerExcluded }
        if (fresh.isNotEmpty()) {
            val idx = abs(seedText.hashCode() + previousOwnReplies.size * 7) % fresh.size
            return fresh[idx]
        }
        val base = candidates[abs(seedText.hashCode()) % candidates.size]
        // Script-matched suffixes (NEVER mix Bangla script into Banglish!)
        val suffixes = when (script) {
            ScriptStyle.BANGLA -> listOf(" বলো!", " তা তোমার কী খবর?", " আর কী অবস্থা?")
            ScriptStyle.BANGLISH -> listOf(" bolo!", " ta tomar ki khobor?", " ar ki obostha?")
            ScriptStyle.ENGLISH -> listOf("!", " What about you?", " Tell me!")
        }
        for (s in suffixes) {
            val modified = base.trimEnd('.', '!', '?') + s
            if (modified.lowercase() !in lowerExcluded) return modified
        }
        return base
    }

    fun buildSmartContextualReply(
        messages: List<ChatMessage>,
        extraExcludedReplies: Set<String> = emptySet()
    ): ReplyOptions {
        val ctx = analyzeConversationThread(messages, extraExcludedReplies)
        val lastIncoming = ctx.lastIncomingMessage
        val script = ctx.scriptStyle
        val pronoun = ctx.pronounStyle
        val prevTopic = ctx.previousTopic
        val previousOwn = ctx.previousOwnReplies

        val lower = lastIncoming.lowercase().trim()
        val padded = " " + lower.replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "
        val normalizedShort = padded.trim().replace(Regex("\\s+"), " ")

        fun hasAny(vararg words: String): Boolean {
            return words.any { w ->
                if (w.startsWith(" ") || w.endsWith(" ")) padded.contains(w)
                else lower.contains(w)
            }
        }

        // 1. PRE-QUESTION / PERMISSION TO ASK ("Akta Kotha boloto", "Ami akta jinis jiggas kirbo", "Ekta kotha boli", "Kichu bolbo", "Shuno")
        if (hasAny(
                "akta kotha", "ekta kotha", "kotha boloto", "kotha bolo to", "kotha boli",
                "jinis jiggas", "jinish jiggesh", "jiggas kirbo", "jiggas korbo", "jiggesh korbo",
                "kichu bolbo", "kisu bolbo", "shuno na", "suno na", "একটা কথা", "জিজ্ঞেস করবো", "কিছু বলবো", "শোনো না"
            )
        ) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "হ্যাঁ দোস্ত বল, কী বলবি? শুনছি তো!",
                        "অবশ্যই বল দোস্ত, কী জিজ্ঞেস করবি নিঃসংকোচে বল!"
                    ), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "জি অবশ্যই বলুন, কী জানতে চান?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "হ্যাঁ অবশ্যই বলো, কী বলবে? শুনছি তো!",
                        "হ্যাঁ বলো না, কী জিনিস জিজ্ঞেস করবে? কোনো সমস্যা নেই!",
                        "নিশ্চয়ই বলো, আমি শুনছি!"
                    ), previousOwn, lastIncoming, script)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "Haa dosto bol, ki bolbi? Shunchi to!",
                        "Obosshoi bol dosto, ki jinis jiggesh korbi bol!"
                    ), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "Ji obosshoi bolun, ki jiggesh korben?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "Haa obosshoi bolo, ki bolba? Shunchi to!",
                        "Haa bolo na, ki jinis jiggesh korba? Kono somossa nai!",
                        "Nischoi bolo, ami shunchi to!"
                    ), previousOwn, lastIncoming, script)
                }
                ScriptStyle.ENGLISH -> "Sure, go ahead and ask! I'm listening."
            }
            return ReplyOptions(replyText, "Invite Question")
        }

        // 2. AFFECTIONATE / PARTNER CALL-OUT ("Babu", "Jaan", "Jan", "Shona", "Pakhi", "বাবু", "জান", "সোনা")
        if (normalizedShort in listOf("babu", "jaan", "jan", "shona", "sona", "pakhi", "babuটা", "বাবু", "জান", "সোনা", "পাখি") ||
            hasAny("ki koro babu", "kothay babu", "babu ki koro", "jaan ki koro")
        ) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "হ্যাঁ বাবু বলো, কী করছো এখন?",
                    "বলো বাবু, শুনছি তো! তোমার কী অবস্থা?",
                    "হ্যাঁ বলো, কী খবর তোমার?"
                ), previousOwn, lastIncoming, script)
                else -> pickUniqueReply(listOf(
                    "Haa babu bolo, ki korcho ekhon?",
                    "Bolo babu, shunchi to! Ki obostha tomar?",
                    "Haa bolo jaan, ki korteso ekhon?"
                ), previousOwn, lastIncoming, script)
            }
            return ReplyOptions(replyText, "Affectionate")
        }

        // 3. "NOTHING DONE YET / DAY JUST STARTED" ("Kisui Kori ni....din to matro suru", "Kichu kori nai", "Ekhono kichu kori nai")
        if (hasAny("kisui kori ni", "kichui kori ni", "kichu kori nai", "kisu kori nai", "din to matro", "matro suru", "matro shuru", "কিছুই করিনি", "কিছু করিনি", "দিন তো মাত্র শুরু")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "হ্যাঁ তাও ঠিক, দিন তো কেবল শুরু হলো! সকালের নাস্তা করেছো?",
                    "সত্যিই তো, কেবল সকাল হলো! চা-নাস্তা খাওয়া হয়েছে তোমার?"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    "Haa tao thik, din to kebol shuru holo! Sokaler nasta korcho?",
                    "Sotti e to, din কেবল shuru! Cha-nasta khawa hoise tomar?"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.ENGLISH -> "True, the day just started! Have you had breakfast yet?"
            }
            return ReplyOptions(replyText, "Morning Chat")
        }

        // 4. POSITIVE WELLBEING / DAY GOING WELL ("Jasce alhamdulilha valo", "Alhamdulillah valo", "Valo achi", "Bhalo jacche")
        if (hasAny("jasce", "jacche", "alhamdulilha valo", "alhamdulillah valo", "alhamdulillah bhalo", "valo achi", "bhalo achi", "valo jacche", "ভালো যাচ্ছে", "আলহামদুলিল্লাহ ভালো")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "আলহামদুলিল্লাহ, শুনে ভালো লাগলো! এখন কী করছো?",
                    "যাক আলহামদুলিল্লাহ! নাস্তা বা খাওয়া-দাওয়া হয়েছে তোমার?"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    "Alhamdulillah, shune bhalo laglo! Ekhon ki korcho?",
                    "Jak Alhamdulillah! Khawa-dawa ba nasta hoise tomar?"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.ENGLISH -> "Alhamdulillah, glad to hear that! What are you up to right now?"
            }
            return ReplyOptions(replyText, "Wellbeing Reply")
        }

        // 5. RECIPROCAL SHORT FOLLOW-UPS ("tumi?", "tui?", "apni?", "Haa. Tumi?", "তুমি?", "তুই?")
        if (normalizedShort in listOf(
                "tumi", "ar tumi", "tui", "ar tui", "apni", "ar apni",
                "haa tumi", "haa tui", "ha tumi", "ha tui", "ji apni", "haa apni",
                "তুমি", "আর তুমি", "তুই", "আর তুই", "আপনি", "আর আপনি",
                "হ্যাঁ তুমি", "হ্যাঁ তুই", "জি আপনি", "হ্যাঁ আপনি", "you", "and you"
            )
        ) {
            val replyText = when (prevTopic) {
                ConversationTopic.FOOD -> when (script) {
                    ScriptStyle.BANGLA -> when (pronoun) {
                        PronounStyle.TUI -> pickUniqueReply(listOf("হ্যাঁ দোস্ত, আমিও একটু আগেই ভাত খেয়ে নিলাম!", "হ্যাঁ রে, আমারও খাওয়া শেষ!"), previousOwn, lastIncoming, script)
                        PronounStyle.APNI -> "জি আলহামদুলিল্লাহ, আমিও কিছুক্ষণ আগে খেয়ে নিয়েছি।"
                        PronounStyle.TUMI -> pickUniqueReply(listOf("হ্যাঁ, আমিও একটু আগেই খাওয়া শেষ করলাম আলহামদুলিল্লাহ!", "হ্যাঁ আমারও খাওয়া শেষ! এখন একটু বিশ্রাম নিচ্ছি।"), previousOwn, lastIncoming, script)
                    }
                    ScriptStyle.BANGLISH -> when (pronoun) {
                        PronounStyle.TUI -> pickUniqueReply(listOf("Haa dosto, amio ektu agei kheye nilam!", "Haa re, amaro khawa shesh!"), previousOwn, lastIncoming, script)
                        PronounStyle.APNI -> "Ji Alhamdulillah, amio kichukhon age kheye niyechi."
                        PronounStyle.TUMI -> pickUniqueReply(listOf("Haa, amio ektu agei khawa shesh korlam Alhamdulillah!", "Haa amaro khawa shesh! Ekhon ektu bose achi."), previousOwn, lastIncoming, script)
                    }
                    ScriptStyle.ENGLISH -> "Yep, I already ate a little while ago too!"
                }
                ConversationTopic.ACTIVITY_WORK -> when (script) {
                    ScriptStyle.BANGLA -> when (pronoun) {
                        PronounStyle.TUI -> "আমিও এইতো বাসায় বসে একটু ফোন দেখছি রে!"
                        PronounStyle.APNI -> "জি, আমিও বাসায় বসে টুকটাক কাজ করছি।"
                        PronounStyle.TUMI -> "আমিও এইতো বাসায় বসে একটু বিশ্রাম নিচ্ছি!"
                    }
                    else -> when (pronoun) {
                        PronounStyle.TUI -> "Amio eito basay bose ektu rest nicchi re!"
                        PronounStyle.APNI -> "Ji, amio basay bose ektu kaj korchi."
                        PronounStyle.TUMI -> "Amio eito basay bose ektu rest nicchi!"
                    }
                }
                else -> when (script) {
                    ScriptStyle.BANGLA -> if (pronoun == PronounStyle.APNI) "জি আলহামদুলিল্লাহ, আপনার দোয়ায় আমিও ভালো আছি।" else "আলহামদুলিল্লাহ আমিও বেশ ভালো আছি!"
                    else -> if (pronoun == PronounStyle.APNI) "Ji Alhamdulillah, amio bhalo achi." else "Alhamdulillah amio bhalo achi!"
                }
            }
            return ReplyOptions(replyText, "Context: ${prevTopic.name}")
        }

        // 6. Follow-up "Na / এখনো না" when previous messages were about Food
        if (normalizedShort in listOf("na", "nah", "na re", "na bhai", "na dosto", "ekhono na", "khai nai", "না", "নাহ", "এখনো না", "খাই নি", "খাইনি", "not yet", "no")) {
            if (prevTopic == ConversationTopic.FOOD || hasAny("khai")) {
                val replyText = when (script) {
                    ScriptStyle.BANGLA -> when (pronoun) {
                        PronounStyle.TUI -> "আরে এখনো খাসনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নে দোস্ত!"
                        PronounStyle.APNI -> "ওহ আচ্ছা, দেরি না করে সময়মতো খাবারটা খেয়ে নিন।"
                        PronounStyle.TUMI -> "আরে এখনো খাওনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নাও!"
                    }
                    ScriptStyle.BANGLISH -> when (pronoun) {
                        PronounStyle.TUI -> "Areh ekhono khas nai keno? Deri na kore taratari kheye ne dosto!"
                        PronounStyle.APNI -> "Oh accha, deri na kore somoymoto khabar ta kheye nin."
                        PronounStyle.TUMI -> "Areh ekhono khao nai keno? Deri na kore taratari kheye nao!"
                    }
                    ScriptStyle.ENGLISH -> "Oh, how come you haven't eaten yet? Go grab something to eat soon!"
                }
                return ReplyOptions(replyText, "Context: Food")
            }
        }

        // 7. Clarification / Confusion / Teasing ("tmi ki kotha bujho na", "ki sob bolteco", "ki confirm korba", "ki janabe")
        if (hasAny("kotha bujho", "kotha bujhis", "ki sob bol", "ki boltec", "ki bolcho", "ki bolis", "ki confirm", "ki janab", "mane ki", "pagol naki", "কথা বুঝো", "কী সব বল", "কি সব বল", "কী বলছ", "কি বলছ", "কী জানাব", "কী কনফার্ম", "মানে কী")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "আরে না দোস্ত, ফোনে অন্য একটা কাজ করছিলাম তো তাই খেয়াল করিনি! এবার বল কী বলছিলি?",
                        "হাহা সরি দোস্ত, তাড়াহুড়োয় ভুল মেসেজ চলে গেছে! বল কী খবর তোর?"
                    ), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "দুঃখিত, আমি একটু অন্য কাজে ব্যস্ত থাকায় ঠিকমতো খেয়াল করতে পারিনি। অনুগ্রহ করে আবার বলবেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "আরে না, আসলে অন্য একটা কাজে একটু অন্যমনস্ক ছিলাম! বলো কী বলছিলে?",
                        "হাহা সরি! তাড়াহুড়োয় উল্টাপাল্টা টাইপ হয়ে গেছে। বলো কী অবস্থা তোমার?",
                        "আরে বুঝতে পেরেছি! একটু ব্যস্ত ছিলাম তো তাই ঠিকমতো লেখার সময় পাইনি।"
                    ), previousOwn, lastIncoming, script)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "Areh na dosto, phone e onno ekta kaj korchilam tai kheyal kori nai! Ebar bol ki bolchili?",
                        "Haha sorry dosto, tarahuroy ulta-palta type hoye gese! Bol ki obostha tor?"
                    ), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "Dukkhito, ami ektu onno kaje basto thakay thikmoto kheyal korte pari nai. Abar bolben?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "Areh na, ashole onno ekta kaje ektu busy chilam tai kheyal kori nai! Bolo ki bolchile?",
                        "Haha sorry bhai, tarahuroy ulta-palta type hoye gese! Ekhon bolo ki obostha?",
                        "Areh bujhchi to! Ektu kaje atke chilam tai thikmoto likhte pari nai, bolo ebar!",
                        "Haha na re bhai, matha ektu onno dike chilo! Bolo ki khobor tomar?"
                    ), previousOwn, lastIncoming, script)
                }
                ScriptStyle.ENGLISH -> "Haha my bad! I was distracted doing something else on my phone. What were you saying?"
            }
            return ReplyOptions(replyText, "Clarification")
        }

        // 8. Casual Status Updates ("aito aci", "eito achi", "kono khobor nai", "temon kichu na")
        if (hasAny("aito ac", "eito ach", "eito ac", "aito ach", "kono khobor nai", "khobor nai", "temon kichu na", "cholche", "এইতো আছি", "কোনো খবর নাই", "তেমন কিছু না", "চলছে আরকি")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "এইতো দোস্ত, আমাদেরও একই অবস্থা! এখন কী করছিস?",
                        "যাক ভালো থাকলেই হলো দোস্ত! বাসার সবাই ভালো তো?"
                    ), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "আলহামদুলিল্লাহ, ভালো থাকলেই ভালো। আপনার বাসার সবাই কেমন আছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "এইতো, আমাদেরও একই অবস্থা—সব স্বাভাবিক চলছে! এখন কী করছো?",
                        "ভালো থাকলেই ভালো! বাসার সবার কী অবস্থা?"
                    ), previousOwn, lastIncoming, script)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "Eito dosto, amaro eki obostha! Ekhon ki koros?",
                        "Jak bhalo thaklei holo dosto! Basar sobai bhalo to?"
                    ), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "Alhamdulillah, bhalo thaklei bhalo. Apnar basar sobai kemon achen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "Eito, amaro sob normal e cholche! Ekhon ki korcho?",
                        "Bhalo thaklei holo! Basar sobai bhalo ache to?",
                        "Hmm bujhlam! Cha-nasta ba khawa-dawa hoise tomar?"
                    ), previousOwn, lastIncoming, script)
                }
                ScriptStyle.ENGLISH -> "Same here, everything is going pretty normal! What are you up to right now?"
            }
            return ReplyOptions(replyText, "Status Update")
        }

        // 9. Single-word "Ki" / "Ki?" / "কী?"
        if (normalizedShort in listOf("ki", "kii", "ki re", "ki bhai", "কী", "কি", "কী রে", "কি ভাই", "what")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "কিছু না দোস্ত, এমনিই জিজ্ঞেস করলাম তোর কী অবস্থা!"
                    else "তেমন কিছু না, এমনিই খোঁজ নিচ্ছিলাম তোমার কী খবর!",
                    "বলছিলাম যে এখন কী করছো?"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "Kichu na dosto, emnii khoj nicchilam tor ki obostha!"
                    else "Temon kichu na, emnii jiggesh korchilam tomar ki khobor!",
                    "Bolchilam je ekhon ki korcho basay bose?",
                    "Emnii bhai, dekhlam online acho tai knock dilam!"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.ENGLISH -> "Nothing much, just checking in to see how you're doing!"
            }
            return ReplyOptions(replyText, "Follow-up")
        }

        // 10. Follow-up "Kiser kaj? / Ki kaj?"
        if (hasAny("kiser", "ki kaj", "কিসের", "কী কাজ", "কি কাজ") || (prevTopic == ConversationTopic.ACTIVITY_WORK && hasAny("ki ", "keno", "কী ", "কেন"))) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "এইতো নিজের একটা প্রজেক্ট আর বাসার টুকটাক কাজ করছি রে। একটু পরই ফ্রি হবো!"
                    else "এইতো নিজের একটু জরুরি কাজ আর ফোনের কিছু সেটআপ করছিলাম। অল্প কিছুক্ষণের মধ্যেই শেষ হয়ে যাবে!",
                    "বাসার কিছু দরকারি কাজ সেরে নিচ্ছিলাম, প্রায় শেষের দিকেই!"
                ), previousOwn, lastIncoming, script)
                else -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "Eito nijer ekta project ar basar tukitaki kaj korchi re. Ektu porei free hobo!"
                    else "Eito nijer ektu dorkari kaj korchilam. Olpo kichukhoner moddhei shesh hoye jabe!",
                    "Phone e ekta app setup ar basar kichu kaj korchilam, pray shesh!"
                ), previousOwn, lastIncoming, script)
            }
            return ReplyOptions(replyText, "Work Details")
        }

        // 11. SALAM / ISLAMIC GREETING
        if (hasAny("salam", "assalamu", "slm", "সালাম", "আসসালামু")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> "ওয়ালাইকুম আসসালাম দোস্ত! কী খবর তোর?"
                    PronounStyle.APNI -> "ওয়ালাইকুম আসসালাম ওয়া রাহমাতুল্লাহ। আলহামদুলিল্লাহ ভালো আছি, আপনি কেমন আছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("ওয়ালাইকুম আসসালাম! কেমন আছো বলো?", "ওয়ালাইকুম আসসালাম ভাই! সব কেমন চলছে?"), previousOwn, lastIncoming, script)
                }
                else -> when (pronoun) {
                    PronounStyle.TUI -> "Walaikum Assalam dosto! Tor ki khobor bol?"
                    PronounStyle.APNI -> "Walaikum Assalam Wa Rahmatullah. Alhamdulillah bhalo achi, apni kemon achen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Walaikum Assalam! Kemon acho bolo?", "Walaikum Assalam bhai! Ki obostha tomar?"), previousOwn, lastIncoming, script)
                }
            }
            return ReplyOptions(replyText, "Greeting")
        }

        // 12. WHAT DID YOU EAT / MENU
        if (hasAny("ki diye", "ki khaila", "ki khaiso", "ki ranna", "কী দিয়ে", "কি দিয়ে", "কী খাইছ", "কি খাইছ", "কী রান্না")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("ভাত আর মাংস দিয়ে খাইলাম রে। তুই কী দিয়ে খাইলি?", "আজকে ভাত, ডাল আর ভাজি দিয়ে খেয়েছি। তোর কী মেনু ছিল?"), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "জি, ভাত ও মাছ দিয়ে খেয়েছি আলহামদুলিল্লাহ। আপনি কী দিয়ে খেয়েছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("ভাত আর মুরগির মাংস দিয়ে খাইলাম। তুমি কী দিয়ে খাইছো?", "আজকে ভাত, ডাল আর ভাজি দিয়ে খেয়েছি। তোমার কী মেনু ছিল?"), previousOwn, lastIncoming, script)
                }
                else -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("Vat ar mangsho diye khailam re. Tui ki diye khaili?", "Ajke vat, dal ar vaji diye kheyechi. Tor ki menu chilo?"), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "Ji, vat ar mach diye kheyechi Alhamdulillah. Apni ki diye kheyechen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Vat ar murgir mangsho diye khailam. Tumi ki diye khaico?", "Ajke vat, dal ar vaji diye kheyechi. Tomar ki menu chilo?"), previousOwn, lastIncoming, script)
                }
            }
            return ReplyOptions(replyText, "Meal Menu")
        }

        // 13. HAVE YOU EATEN / MEAL INQUIRY
        if (hasAny("khaic", "khais", "kheyec", "khawa", "khail", "nasta", "lunch", "dinner", "খাইছ", "খেয়েছ", "খাওয়া", "নাস্তা")) {
            val isNasta = hasAny("nasta", "cha ", "নাস্তা", "চা ")
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("হ্যাঁ দোস্ত, একটু আগেই খাইলাম। তুই খাইছিস?", "এইতো কেবল খাওয়া শেষ করলাম। তোর খাওয়া হইছে?"), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> if (isNasta) "জি আলহামদুলিল্লাহ, নাস্তা করেছি। আপনি নাস্তা করেছেন?" else "জি আলহামদুলিল্লাহ, আমার খাওয়া হয়েছে। আপনি খেয়েছেন?"
                    PronounStyle.TUMI -> if (isNasta) "হ্যাঁ, চা-নাস্তা একটু আগেই শেষ করলাম। তুমি নাস্তা করছো?" else pickUniqueReply(listOf("হ্যাঁ, আলহামদুলিল্লাহ একটু আগেই খাইলাম। তুমি খাইছো?", "এইতো কিছুক্ষণ আগে খাওয়া শেষ করলাম। তোমার খাওয়া দাওয়া হইছে?"), previousOwn, lastIncoming, script)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("Haa dosto, ektu agei khailam. Tui khaisos?", "Eito kebol khawa shesh korlam. Tor khawa hoise?"), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> if (isNasta) "Ji Alhamdulillah, nasta korechi. Apni nasta korechen?" else "Ji Alhamdulillah, amar khawa hoyeche. Apni kheyechen?"
                    PronounStyle.TUMI -> if (isNasta) "Haa, cha-nasta ektu agei korlam. Tumi nasta korcho?" else pickUniqueReply(listOf("Haa, ektu agei khailam Alhamdulillah. Tumi khaico?", "Eito kichukhon age khawa shesh korlam. Tomar khawa hoise?"), previousOwn, lastIncoming, script)
                }
                ScriptStyle.ENGLISH -> "Yeah, just finished eating a little while ago! Did you eat?"
            }
            return ReplyOptions(replyText, "Food")
        }

        // 14. WHAT ARE YOU DOING
        if (hasAny("ki koro", "ki koros", "ki korc", "ki kortes", "ki koris", "কী কর", "কি কর", "what are you doing", "wyd", "whatcha doing")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("এইতো দোস্ত, বাসায় বসে ফোন চাপছি। তুই কী করিস?", "তেমন কিছু না রে, একটু বিশ্রাম নিচ্ছি। তোর কী অবস্থা?"), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "জি, এইতো বাসায় একটু কাজ করছিলাম। আপনি কী করছেন এখন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("এইতো বাসায় বসে আছি, একটু ফোন দেখছিলাম। তুমি কী করছো?", "এইতো একটু বিশ্রাম নিচ্ছি। তোমার খবর কী বলো?", "বাসায় বসে একটু ইউটিউব দেখছিলাম। তুমি কী করছো এখন?"), previousOwn, lastIncoming, script)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("Eito dosto, basay bose phone chapchi. Tui ki koros?", "Temon kichu na re, ektu kaj korchilam. Tor ki khobor?"), previousOwn, lastIncoming, script)
                    PronounStyle.APNI -> "Ji, eito basay ektu kaj korchilam. Apni ki korchen ekhon?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Eito basay bose achi, ektu rest nicchi. Tumi ki korcho?", "Eito ektu hater kaj sarchilam. Tomar ki obostha bolo?", "Basay bose ektu phone dekhchilam. Tumi ki korteso ekhon?"), previousOwn, lastIncoming, script)
                }
                ScriptStyle.ENGLISH -> "Just chilling at home and checking my phone. What are you up to?"
            }
            return ReplyOptions(replyText, "Activity")
        }

        // 15. WHERE ARE YOU
        if (hasAny(" koi ", "koi?", "kothay", "basay naki", "bashay naki", "কই", "কোথায়", "বাসায় নাকি", "where are you", "wya") || lower == "koi") {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> "আমি এখন বাসাতেই আছি রে। তুই কই?"
                    PronounStyle.APNI -> "জি, আমি এখন বাসায় আছি। আপনি কোথায় আছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("আমি এখন বাসাতেই আছি। তুমি কোথায়?", "এইতো বাসায় আছি। তুমি কোথায় আছো এখন?"), previousOwn, lastIncoming, script)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> "Ami ekhon basatei achi re. Tui koi?"
                    PronounStyle.APNI -> "Ji, ami ekhon basay achi. Apni kothay achen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Ami ekhon basay achi. Tumi kothay?", "Eito basay achi bhai. Tumi koi acho ekhon?"), previousOwn, lastIncoming, script)
                }
                ScriptStyle.ENGLISH -> "I'm at home right now. Where are you?"
            }
            return ReplyOptions(replyText, "Location")
        }

        // 16. HOW ARE YOU / WHAT'S UP
        if (hasAny("kemon", "kmn", "ki khobor", "ki obostha", "কেমন", "কী খবর", "কি খবর", "কী অবস্থা", "কি অবস্থা", "how are you", "how r u", "what's up", "whats up")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> "আলহামদুলিল্লাহ ভালো আছি দোস্ত! তোর কী খবর বল?"
                    PronounStyle.APNI -> "জি আলহামদুলিল্লাহ, আপনার দোয়ায় ভালো আছি। আপনি কেমন আছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("আলহামদুলিল্লাহ বেশ ভালো আছি! তোমার কী খবর বলো?", "এইতো আলহামদুলিল্লাহ সব ভালো চলছে। তোমার দিনকাল কেমন যাচ্ছে?"), previousOwn, lastIncoming, script)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> "Alhamdulillah bhalo achi dosto! Tor ki khobor bol?"
                    PronounStyle.APNI -> "Ji Alhamdulillah, bhalo achi. Apni kemon achen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Alhamdulillah bhalo achi! Tomar ki khobor bolo?", "Eito Alhamdulillah sob bhalo cholche. Tomar dinkal kemon jacche?"), previousOwn, lastIncoming, script)
                }
                ScriptStyle.ENGLISH -> "Doing great, Alhamdulillah! How's everything going with you?"
            }
            return ReplyOptions(replyText, "Wellbeing")
        }

        // 17. SLEEP / NIGHT / MORNING
        if (hasAny("ghum", "good night", "gn ", "good morning", "gm ", "ঘুম", "শুভ রাত্রি", "শুভ সকাল", "sleep")) {
            val isMorning = hasAny("morning", "gm ", "সকাল")
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (isMorning) "শুভ সকাল! ঘুম থেকে উঠলে কখন?"
                else if (pronoun == PronounStyle.TUI) "এইতো একটু পরেই ঘুমাবো রে। তুই ঘুমাবি না?"
                else if (pronoun == PronounStyle.APNI) "জি, কিছুক্ষণের মধ্যেই ঘুমিয়ে পড়বো। শুভ রাত্রি, ভালো থাকবেন।"
                else "এইতো আর কিছুক্ষণ পরই ঘুমিয়ে পড়বো। তুমি ঘুমাওনি এখনো?"
                ScriptStyle.BANGLISH -> if (isMorning) "Good morning! Ghum theke uthla kokhon?"
                else if (pronoun == PronounStyle.TUI) "Eito ektu porei ghumabo re. Tui ghumabi na?"
                else if (pronoun == PronounStyle.APNI) "Ji, ektu porei ghumiye porbo. Shuvo ratri, bhalo thakben."
                else "Eito ektu porei ghumabo. Tumi ghumao nai ekhono?"
                ScriptStyle.ENGLISH -> if (isMorning) "Good morning! Hope you have an awesome day!" else "Heading to bed pretty soon! Aren't you sleeping yet?"
            }
            return ReplyOptions(replyText, "Sleep/Greeting")
        }

        // 18. FAMILY / HOME WELL-BEING (Only explicit family words, NOT "Babu"!)
        if (hasAny("basar sobai", "bashar sobai", "bhabhi", "vabi", "ammu", "abbu", "family", "বাসার সবাই", "ভাবি", "আম্মু", "আব্বু")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (pronoun == PronounStyle.APNI) "জি আলহামদুলিল্লাহ, দোয়ায় বাসার সবাই ভালো আছে। আপনার পরিবারের সবাই কেমন আছেন?" else "আলহামদুলিল্লাহ, বাসার সবাই ভালো আছে। তোমাদের বাসার সবাই কেমন আছে?"
                else -> if (pronoun == PronounStyle.APNI) "Ji Alhamdulillah, basar sobai bhalo ache. Apnar poribarer sobai kemon achen?" else "Alhamdulillah, basar sobai bhalo ache! Tomader basar sobai kemon ache?"
            }
            return ReplyOptions(replyText, "Family")
        }

        // 19. HEALTH / SICKNESS
        if (hasAny("shorir", "jor", "matha", "oshustho", "batha", "শরীর", "জ্বর", "মাথা", "অসুস্থ", "ব্যথা", "sick", "fever", "headache")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (pronoun == PronounStyle.TUI) "আরে কী বলিস! ওষুধ খাইছিস ঠিকমতো? একটু বিশ্রাম নে দোস্ত।" else "ওহ, এখন শরীর কেমন লাগছে? ঠিকমতো ওষুধ খেয়ে বিশ্রাম নাও।"
                ScriptStyle.BANGLISH -> if (pronoun == PronounStyle.TUI) "Areh ki bolis! Oshudh khaisos thikmoto? Ektu rest ne dosto." else "Oh, ekhon shorir kemon lagche? Thikmoto oshudh kheye rest nao."
                ScriptStyle.ENGLISH -> "Oh no, hope you feel better soon! Make sure to get some rest."
            }
            return ReplyOptions(replyText, "Health")
        }

        // 20. WEATHER / RAIN / HEAT
        if (hasAny("brishti", "gorom", "thanda", "weather", "বৃষ্টি", "গরম", "ঠান্ডা", "রোদ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "হ্যাঁ, আজকের আবহাওয়াটা আসলেই অন্যরকম! তোমাদের ওদিকে কী অবস্থা?"
                ScriptStyle.BANGLISH -> "Haa, ajker weather ta asholei onnorokom! Tomader odike ki obostha?"
                ScriptStyle.ENGLISH -> "Yeah, the weather is really something today! How is it over there?"
            }
            return ReplyOptions(replyText, "Weather")
        }

        // 21. CALL / PHONE
        if (hasAny("call", "phone", "কল", "ফোন")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (pronoun == PronounStyle.APNI) "জি, আমি এখন কথা বলতে পারবো। আপনি চাইলে কল দিতে পারেন।" else "হ্যাঁ এখন ফ্রি আছি, কল দিতে পারো!"
                else -> if (pronoun == PronounStyle.APNI) "Ji, ami ekhon free achi. Apni chaile call dite paren." else "Haa ekhon free achi, call dite paro!"
            }
            return ReplyOptions(replyText, "Call")
        }

        // 22. BUSY / FREE / MEETING / WHEN
        if (hasAny("free", "busy", "basto", "kobe", "kokhon", "dekha", "asba", "asbi", "jaba", "jabi", "ফ্রি", "ব্যস্ত", "কবে", "কখন", "দেখা", "আসবা", "যাবা")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "আমি এখন ফ্রি আছি দোস্ত, বল কী প্ল্যান?"
                    else "আমি এখন মোটামুটি ফ্রি আছি, বলো কী প্ল্যান?",
                    "হাতের কাজটা প্রায় শেষ, একটু পরই একদম ফ্রি হয়ে যাবো!"
                ), previousOwn, lastIncoming, script)
                else -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "Ami ekhon free achi dosto, bol ki plan?"
                    else "Ami ekhon motamuti free achi, bolo ki plan?",
                    "Hater kajta pray shesh, ektu porei free hoye jabo!"
                ), previousOwn, lastIncoming, script)
            }
            return ReplyOptions(replyText, "Plan")
        }

        // 23. SHORT GREETINGS ("hy", "hi", "hlw", "hello", "oi", "kire")
        if (lower in listOf("hy", "hi", "hlw", "hello", "hey", "oi", "oii", "kire", "ki re", "vai", "bhai", "dosto", "হাই", "হ্যালো", "ওই", "কিরে", "ভাই", "দোস্ত") ||
            lower.startsWith("hi ") || lower.startsWith("hlw ") || lower.startsWith("hello ") || lower.startsWith("hey ")
        ) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI || lower.contains("কিরে") || lower.contains("ওই")) "হ্যাঁ দোস্ত বল, কী খবর তোর?"
                    else "হ্যালো! কী খবর, কেমন আছো?",
                    "হ্যাঁ বলো, কী অবস্থা?"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI || lower.contains("kire") || lower.contains("oi")) "Haa dosto bol, ki khobor tor?"
                    else "Hey! Ki khobor bolo, kemon acho?",
                    "Haa bolo, kemon cholche sob?",
                    "Hlw! Ki obostha tomar bolo?"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.ENGLISH -> "Hey! What's up? How's it going?"
            }
            return ReplyOptions(replyText, "Greeting")
        }

        // 24. SHORT ACKNOWLEDGMENTS ("hmm", "ok", "accha", "thanks")
        if (lower in listOf("hmm", "hm", "humm", "ok", "okay", "k", "accha", "acha", "thik ache", "oh", "ooh", "হুম", "হম", "আচ্ছা", "ওকে", "ঠিক আছে") ||
            hasAny("thank", "dhonnobad", "ধন্যবাদ")
        ) {
            val isThanks = hasAny("thank", "dhonnobad", "ধন্যবাদ")
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (isThanks) "আরে ধন্যবাদ দেওয়া লাগবে না! সব ঠিক আছে।"
                else pickUniqueReply(listOf(
                    "হুম, তারপর বলো আর কী খবর?",
                    "আচ্ছা ঠিক আছে! এখন কী করছো?",
                    "হুম বুঝলাম! বাসার সবাই ভালো তো?"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.BANGLISH -> if (isThanks) "Areh dhonnobad dewa lagbe na! Sob thik ache."
                else pickUniqueReply(listOf(
                    "Hmm, tarpor bolo ar ki khobor?",
                    "Accha thik ache! Ekhon ki korcho?",
                    "Hmm bujhlam! Basar sobai bhalo to?"
                ), previousOwn, lastIncoming, script)
                ScriptStyle.ENGLISH -> if (isThanks) "Anytime! Happy to help!" else "Sounds good! So what else is new with you?"
            }
            return ReplyOptions(replyText, "Acknowledgment")
        }

        // 25. SPECIFIC QUESTION WORD ANALYSIS (Why / How / Price)
        if (hasAny(" keno ", " kn ", " কেন ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (pronoun == PronounStyle.TUI) "এমনিই রে দোস্ত! ভাবলাম তোর থেকে একটু শুনি ব্যাপারটা।" else "আসলে তেমন বড় কিছু না, এমনিই জানার জন্য বলছিলাম আরকি!"
                else -> if (pronoun == PronounStyle.TUI) "Emnii re dosto! Vablam tor theke ektu shuni baparta." else "Ashole temon kichu na, emnii janar jonno bolchilam arki!"
            }
            return ReplyOptions(replyText, "Question: Why")
        }

        if (hasAny(" kivabe ", " kemne ", " কীভাবে ", " কেমনে ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "এটা খুব সহজ, একটু চেষ্টা করলেই হয়ে যাবে! আমি তোমাকে দেখিয়ে দেবো।"
                else -> "Eita khub sohoj, ektu try korlei hoye jabe! Ami dekhiye dibo tomake."
            }
            return ReplyOptions(replyText, "Question: How")
        }

        if (hasAny(" koto ", " dam ", " taka ", " কত ", " দাম ", " টাকা ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "দামটা এখন আগের চেয়ে একটু কম-বেশি হতে পারে, তুমি কত বাজেট ভাবছো?"
                else -> "Dam ta ekhon ektu kom-beshi hote pare, tumi koto budget vabcho?"
            }
            return ReplyOptions(replyText, "Question: Price/Amount")
        }

        // 26. ATTENTIVE CONVERSATIONAL CONTINUATION (Never changes subject randomly, never mixes scripts!)
        val isQuestion = lastIncoming.contains("?")
        val replyText = when (script) {
            ScriptStyle.BANGLA -> pickUniqueReply(
                if (isQuestion) {
                    when (pronoun) {
                        PronounStyle.TUI -> listOf(
                            "হ্যাঁ দোস্ত, তুই কী মনে করিস এটা নিয়ে? একটু খুলে বল তো!",
                            "ভালো কথা জিজ্ঞেস করেছিস দোস্ত! তোর নিজের কী প্ল্যান এটা নিয়ে?"
                        )
                        PronounStyle.APNI -> listOf(
                            "জি, আপনি খুব ভালো একটি বিষয় বলেছেন। এ ব্যাপারে আপনার মতামত কী?",
                            "জি বুঝতে পেরেছি। আপনি যেভাবে ভালো মনে করেন সেভাবেই করা যায়।"
                        )
                        PronounStyle.TUMI -> listOf(
                            "হ্যাঁ, ভালো কথা জিজ্ঞেস করেছো! তুমি কী ভাবছো এটা নিয়ে বলো তো?",
                            "হ্যাঁ বুঝতে পেরেছি! এটার ব্যাপারে তোমার নিজের কী মনে হয়?"
                        )
                    }
                } else {
                    when (pronoun) {
                        PronounStyle.TUI -> listOf(
                            "হ্যাঁ দোস্ত, বুঝতে পারছি তোর কথাটা! তারপর আর কী বলছিলি বল?",
                            "হুম বুঝলাম দোস্ত! তা এখন কী করছিস তুই?"
                        )
                        PronounStyle.APNI -> listOf(
                            "জি, আপনার কথাটি বুঝতে পেরেছি।",
                            "জি ধন্যবাদ বিষয়টি জানানোর জন্য।"
                        )
                        PronounStyle.TUMI -> listOf(
                            "হুম বুঝতে পেরেছি তোমার কথাটা! তারপর বলো?",
                            "হ্যাঁ বলো, আমি শুনছি তোমার কথা!",
                            "আচ্ছা বুঝলাম! তারপর আর কী বলছিলে বলো?"
                        )
                    }
                },
                previousOwn,
                lastIncoming,
                script
            )
            ScriptStyle.BANGLISH -> pickUniqueReply(
                if (isQuestion) {
                    when (pronoun) {
                        PronounStyle.TUI -> listOf(
                            "Haa dosto, tui ki mone koros eita niye? Ektu khule bol to!",
                            "Bhalo kotha jiggesh korli dosto! Tor nijer ki plan eita niye?"
                        )
                        PronounStyle.APNI -> listOf(
                            "Ji, apnar bishoyti bujhte perechi. E bapare apnar motamot ki?",
                            "Ji, apni jevabe bhalo mone koren sevabei kora jay."
                        )
                        PronounStyle.TUMI -> listOf(
                            "Haa, bhalo kotha jiggesh korcho! Tumi ki vabcho eita niye bolo to?",
                            "Hmm bujhte perechi! Eitar bapare tomar nijer ki mone hoy bolo?"
                        )
                    }
                } else {
                    when (pronoun) {
                        PronounStyle.TUI -> listOf(
                            "Hmm bujhlam tor kothata dosto! Tarpor ar ki bolchili bol?",
                            "Haa dosto shunchi to, tarpor bol!"
                        )
                        PronounStyle.APNI -> listOf(
                            "Ji, apnar kothati bujhte perechi.",
                            "Ji dhonnobad bishoyti bolbar jonno."
                        )
                        PronounStyle.TUMI -> listOf(
                            "Hmm bujhte perechi tomar kothata! Tarpor bolo?",
                            "Haa bolo, ami shunchi tomar kotha!",
                            "Accha bujhlam! Tarpor ar ki bolchile bolo?"
                        )
                    }
                },
                previousOwn,
                lastIncoming,
                script
            )
            ScriptStyle.ENGLISH -> pickUniqueReply(listOf(
                "I hear you! Tell me more about what's on your mind.",
                "Makes sense! What else were you thinking?"
            ), previousOwn, lastIncoming, script)
        }

        return ReplyOptions(replyText, "${script.name} • ${pronoun.name}")
    }
}
