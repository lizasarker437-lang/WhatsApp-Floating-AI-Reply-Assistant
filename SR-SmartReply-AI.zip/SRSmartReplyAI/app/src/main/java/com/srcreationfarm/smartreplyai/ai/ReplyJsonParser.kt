package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import org.json.JSONObject
import kotlin.math.abs

object ReplyJsonParser {

    enum class PronounStyle { TUI, TUMI, APNI }
    enum class ScriptStyle { BANGLA, BANGLISH, ENGLISH }
    enum class ConversationTopic {
        NONE, FOOD, ACTIVITY_WORK, LOCATION, WELLBEING, SLEEP, FAMILY, CALL, PLAN_MEET, HEALTH, WEATHER, STUDY
    }

    data class ThreadContext(
        val windowMessages: List<ChatMessage>,
        val priorMessages: List<ChatMessage>,
        val lastIncomingMessage: String,
        val scriptStyle: ScriptStyle,
        val pronounStyle: PronounStyle,
        val previousTopic: ConversationTopic,
        val previousOwnReplies: Set<String>,
        val botAlreadyAskedFood: Boolean,
        val botAlreadyAskedActivity: Boolean,
        val botAlreadyAskedWellbeing: Boolean
    )

    fun parseAiReply(rawText: String): String {
        val cleaned = rawText
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()

        val startBrace = cleaned.indexOf('{')
        val endBrace = cleaned.lastIndexOf('}')
        if (startBrace != -1 && endBrace > startBrace) {
            try {
                val obj = JSONObject(cleaned.substring(startBrace, endBrace + 1))
                for (key in listOf("reply", "message", "response", "text", "friendly", "polite", "professional")) {
                    val v = obj.optString(key, "").trim()
                    if (v.isNotEmpty()) return v
                }
            } catch (_: Exception) {
            }
        }
        return cleaned
            .removePrefix("Reply:")
            .removePrefix("reply:")
            .removePrefix("Me:")
            .trim { it == '"' || it == '\'' || it.isWhitespace() }
            .lines()
            .firstOrNull { it.isNotBlank() }
            ?.trim() ?: ""
    }

    fun detectScriptStyle(text: String): ScriptStyle? {
        if (text.isBlank()) return null
        val hasBanglaScript = text.any { it in '\u0980'..'\u09FF' }
        if (hasBanglaScript) return ScriptStyle.BANGLA

        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\s]"), " ") + " "
        val banglishMarkers = listOf(
            " ki ", " kemon ", " kmn ", " kothay ", " koi ", " bhai ", " vai ", " vaia ", " dosto ",
            " ache ", " achi ", " aci ", " acho ", " achen ", " achis ", " korcho ", " korco ", " korci ",
            " koro ", " koros ", " koren ", " korteso ", " khaico ", " khaisos ", " khaiso ", " kheyechen ",
            " khawa ", " bhalo ", " valo ", " tumi ", " tmi ", " tmr ", " tui ", " apni ", " amar ", " tomar ",
            " tor ", " apnar ", " haa ", " na ", " nai ", " naki ", " keno ", " kn ", " kobe ", " kokhon ",
            " kiser ", " basay ", " bashay ", " ghum ", " kaj ", " kaje ", " aso ", " asbo ", " jabo ",
            " jabi ", " jaba ", " bol ", " bolo ", " boloto ", " bollam ", " bolen ", " bolteco ", " bolcho ",
            " bujho ", " janabe ", " korba ", " kirbo ", " korbo ", " korla ", " jiggas ", " jiggesh ",
            " akta ", " ekta ", " jinis ", " kotha ", " kisui ", " kichui ", " kori ", " matro ", " suru ",
            " shuru ", " din ", " jasce ", " jacche ", " alhamdulilha ", " alhamdulillah ", " babu ", " jaan ",
            " jan ", " shona ", " pakhi ", " asole ", " ashole ", " abar ", " nasta ", " accha ", " acha ",
            " aito ", " eito ", " hlw ", " salam ", " assalamu ", " kono ", " sob ", " dhonnobad ", " khobor ",
            " obostha ", " ektu ", " ekhon ", " ar ", " tarpor ", " sotti ", " brishti ", " gorom ", " shorir ",
            " jor ", " matha ", " pora ", " exam ", " class ", " taka "
        )
        if (banglishMarkers.any { lower.contains(it) }) {
            return ScriptStyle.BANGLISH
        }
        return null
    }

    fun detectPronounStyle(text: String): PronounStyle? {
        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "
        val tuiMarkers = listOf(
            " tui ", " tor ", " toke ", " koros ", " koris ", " khaisos ", " khaisis ", " achis ",
            " asis ", " jabi ", " bolis ", " dosto ", " mama ", " তুই ", " তোর ", " তোকে ",
            " করিস ", " খাইছিস ", " আছিস ", " যাবি ", " দোস্ত "
        )
        if (tuiMarkers.any { lower.contains(it) }) return PronounStyle.TUI

        val apniMarkers = listOf(
            " apni ", " apnar ", " apnake ", " koren ", " korchen ", " kheyechen ", " achen ",
            " jaben ", " asben ", " bolun ", " bolen ", " sir ", " ভাইয়া ", " আপু ", " আপনি ", " আপনার ",
            " আপনাকে ", " করেন ", " করছেন ", " খেয়েছেন ", " আছেন ", " যাবেন ", " আসবেন ", " বলুন ", " স্যার "
        )
        if (apniMarkers.any { lower.contains(it) }) return PronounStyle.APNI

        val tumiMarkers = listOf(
            " tumi ", " tmi ", " tmr ", " tomar ", " tomake ", " koro ", " korcho ", " korco ", " korla ",
            " korba ", " boloto ", " bolteco ", " bujho ", " khaico ", " khaiso ", " acho ", " jaba ",
            " asba ", " bolo ", " babu ", " jaan ", " তুমি ", " তোমার ", " তোমাকে ", " করো ", " করছো ",
            " খাইছো ", " আছো ", " বাবু "
        )
        if (tumiMarkers.any { lower.contains(it) }) return PronounStyle.TUMI

        return null
    }

    fun detectTopicFromText(text: String): ConversationTopic {
        val lower = text.lowercase()
        return when {
            listOf("khaic", "khais", "kheyec", "khawa", "vat", "mangsho", "nasta", "খাইছ", "খেয়েছ", "খাওয়া", "ভাত", "নাস্তা", "eat", "food", "lunch", "dinner").any { lower.contains(it) } ->
                ConversationTopic.FOOD
            listOf("ki koro", "ki koros", "ki korc", "kaj", "basto", "busy", "কী কর", "কি কর", "কাজ", "ব্যস্ত", "working", "doing").any { lower.contains(it) } ->
                ConversationTopic.ACTIVITY_WORK
            listOf("koi", "kothay", "basay", "bashay", "কই", "কোথায়", "বাসায়", "where").any { lower.contains(it) } ->
                ConversationTopic.LOCATION
            listOf("ghum", "ratri", "night", "ঘুম", "রাত্রি", "sleep").any { lower.contains(it) } ->
                ConversationTopic.SLEEP
            listOf("basar sobai", "bashar sobai", "bhabhi", "ammu", "abbu", "বাসার সবাই", "ভাবি", "আম্মু", "আব্বু", "family").any { lower.contains(it) } ->
                ConversationTopic.FAMILY
            listOf("call", "phone", "কল", "ফোন").any { lower.contains(it) } ->
                ConversationTopic.CALL
            listOf("kobe", "kokhon", "dekha", "asba", "jaba", "কবে", "কখন", "দেখা", "আসবা", "যাবা", "meet").any { lower.contains(it) } ->
                ConversationTopic.PLAN_MEET
            listOf("shorir", "jor", "matha", "oshustho", "শরীর", "জ্বর", "মাথা", "অসুস্থ", "sick", "fever").any { lower.contains(it) } ->
                ConversationTopic.HEALTH
            listOf("brishti", "gorom", "thanda", "weather", "বৃষ্টি", "গরম", "ঠান্ডা").any { lower.contains(it) } ->
                ConversationTopic.WEATHER
            listOf("pora", "exam", "class", "college", "পড়া", "পরীক্ষা", "ক্লাস").any { lower.contains(it) } ->
                ConversationTopic.STUDY
            listOf("kemon", "kmn", "khobor", "obostha", "bhalo", "valo", "aito", "eito", "jasce", "jacche", "কেমন", "খবর", "অবস্থা", "ভালো").any { lower.contains(it) } ->
                ConversationTopic.WELLBEING
            else -> ConversationTopic.NONE
        }
    }

    fun analyzeConversationThread(
        messages: List<ChatMessage>,
        extraExcludedReplies: Set<String> = emptySet()
    ): ThreadContext {
        val window = messages.takeLast(5)
        val lastIncomingMsg = window.lastOrNull { it.sender == "Incoming" }?.text?.trim()
            ?: window.lastOrNull()?.text?.trim()
            ?: ""

        val prior = if (window.size > 1) window.dropLast(1) else emptyList()
        val ownInWindow = window.filter { it.sender == "Me" }.map { it.text.trim() }
        val prevOwn = HashSet<String>().apply {
            addAll(extraExcludedReplies)
            addAll(ownInWindow)
        }

        // Check what questions our bot ("Me") ALREADY asked in the current chat window
        val ownJoinedLower = ownInWindow.joinToString(" ").lowercase()
        val botAskedFood = listOf("nasta", "khawa", "khaico", "khaisos", "kheyechen", "নাস্তা", "খাওয়া", "খাইছ").any { ownJoinedLower.contains(it) }
        val botAskedActivity = listOf("ki korcho", "ki koros", "ki korteso", "কী করছো", "কী করিস").any { ownJoinedLower.contains(it) }
        val botAskedWellbeing = listOf("kemon acho", "kemon cholche", "ki khobor", "ki obostha", "কেমন আছো", "কী খবর").any { ownJoinedLower.contains(it) }

        var script = detectScriptStyle(lastIncomingMsg)
        if (script == null) {
            val hasBanglaChars = lastIncomingMsg.any { it in '\u0980'..'\u09FF' }
            script = if (hasBanglaChars) ScriptStyle.BANGLA else ScriptStyle.BANGLISH
        }
        val finalScript = script

        var pronoun = detectPronounStyle(lastIncomingMsg)
        if (pronoun == null) {
            for (m in prior.reversed()) {
                if (m.sender == "Incoming") {
                    val p = detectPronounStyle(m.text)
                    if (p != null) {
                        pronoun = p
                        break
                    }
                }
            }
        }
        val finalPronoun = pronoun ?: PronounStyle.TUMI

        var ongoingTopic = ConversationTopic.NONE
        for (m in prior.reversed()) {
            val t = detectTopicFromText(m.text)
            if (t != ConversationTopic.NONE) {
                ongoingTopic = t
                break
            }
        }

        return ThreadContext(
            windowMessages = window,
            priorMessages = prior,
            lastIncomingMessage = lastIncomingMsg,
            scriptStyle = finalScript,
            pronounStyle = finalPronoun,
            previousTopic = ongoingTopic,
            previousOwnReplies = prevOwn,
            botAlreadyAskedFood = botAskedFood,
            botAlreadyAskedActivity = botAskedActivity,
            botAlreadyAskedWellbeing = botAskedWellbeing
        )
    }

    /**
     * Picks a 100% unique reply from candidates.
     * NEVER appends artificial suffixes like "bolo!" to an already used sentence!
     * If all primary candidates were used, selects from the secondary diverse pool.
     */
    private fun pickUniqueReply(
        candidates: List<String>,
        previousOwnReplies: Set<String>,
        seedText: String,
        script: ScriptStyle,
        pronoun: PronounStyle = PronounStyle.TUMI
    ): String {
        val lowerExcluded = previousOwnReplies.map { it.trim().lowercase() }.toSet()
        val fresh = candidates.filter { it.trim().lowercase() !in lowerExcluded }
        if (fresh.isNotEmpty()) {
            val idx = abs(seedText.hashCode() + previousOwnReplies.size * 11) % fresh.size
            return fresh[idx]
        }

        // Secondary large diverse pool of completely distinct sentences (never repeats with a suffix!)
        val backupPool = when (script) {
            ScriptStyle.BANGLA -> when (pronoun) {
                PronounStyle.TUI -> listOf(
                    "হ্যাঁ দোস্ত, বুঝতে পারছি তোর কথাটা! তা আজকে তোর কী প্ল্যান?",
                    "আচ্ছা দোস্ত, শোন—বাসার সবাই ভালো আছে তো?",
                    "তা ঠিক বলেছিস রে! এখন কী বাসাতেই আছিস?",
                    "হুম দোস্ত, তোর কথাই ঠিক! আজকে আবহাওয়াটা দেখছিস?",
                    "বুঝলাম রে! তোর হাতের কাজগুলো সব শেষ হইছে?",
                    "হ্যাঁ রে দোস্ত, আমি শুনছি তোর কথা, বল!",
                    "একদম ঠিক কথা! তা বিকেলে কই থাকবি আজকে?",
                    "আরে হ্যাঁ, আমিও ঠিক এটাই চিন্তা করছিলাম দোস্ত!"
                )
                PronounStyle.APNI -> listOf(
                    "জি, আপনার কথাটি বুঝতে পেরেছি। আপনি একদম ঠিক বলেছেন।",
                    "জি ধন্যবাদ বিষয়টি জানানোর জন্য। আপনার বাসার সবাই ভালো আছেন তো?",
                    "জি, আপনার কথার সাথে আমি সম্পূর্ণ একমত।",
                    "অবশ্যই, আপনি যেভাবে ভালো মনে করেন সেভাবেই হোক।"
                )
                PronounStyle.TUMI -> listOf(
                    "হ্যাঁ, তোমার কথাটা বুঝতে পেরেছি! তা আজকে তোমার কী প্ল্যান?",
                    "আচ্ছা বুঝলাম! তোমার বাসার সবাই ভালো আছে তো?",
                    "তা ঠিক বলেছো! এখন কি বাসাতেই আছো তুমি?",
                    "হুম, তোমার কথাই ঠিক! তোমার হাতের কাজগুলো শেষ হয়েছে?",
                    "হ্যাঁ বলো, আমি মনোযোগ দিয়ে শুনছি তোমার কথা!",
                    "আসলেই তাই! আজকে বিকেলে কী করার চিন্তা করছো?",
                    "একদম খাঁটি কথা বলেছো! তা শরীর-স্বাস্থ্য ভালো আছে তো তোমার?",
                    "হ্যাঁ, আমিও ঠিক এই বিষয়টাই ভাবছিলাম!"
                )
            }
            ScriptStyle.BANGLISH -> when (pronoun) {
                PronounStyle.TUI -> listOf(
                    "Haa dosto, bujhte parchi tor kothata! Ta ajke tor ki plan?",
                    "Accha dosto, basar sobai bhalo ache to?",
                    "Ta thik bolsis re! Ekhon ki basatei achis?",
                    "Hmm dosto, tor kothai thik! Tor hater kaj gulo shesh hoise?",
                    "Haa re dosto, ami shunchi tor kotha, bol!",
                    "Ekdom thik kotha! Ta bikele koi thakbi ajke?",
                    "Areh haa, amio thik eitai chinta korchilam dosto!",
                    "Bujhlam re! Ta ajke ki korbi vabchos?"
                )
                PronounStyle.APNI -> listOf(
                    "Ji, apnar kothati bujhte perechi. Apni ekdom thik bolechen.",
                    "Ji dhonnobad bishoyti bolbar jonno. Apnar basar sobai bhalo achen to?",
                    "Ji, apnar kothar sathe ami sompurno ekmot.",
                    "Obosshoi, apni jevabe bhalo mone koren sevabei hok."
                )
                PronounStyle.TUMI -> listOf(
                    "Haa, tomar kothata bujhte perechi! Ta ajke tomar ki plan?",
                    "Bujhlam tomar kothata! Tomar basar sobai bhalo ache to?",
                    "Ta thik bolcho! Ekhon ki basatei bose acho tumi?",
                    "Hmm, tomar kothai thik! Tomar hater kaj gulo shesh hoyeche?",
                    "Haa bolo, ami monojog diye shunchi tomar kotha!",
                    "Asholei tai! Ajke bikele ki korar chinta korcho?",
                    "Ekdom sotti kotha bolcho! Ta shorir-shasthyo bhalo ache to tomar?",
                    "Haa, amio thik ei bishoytai vabchilam!",
                    "Hmm bujhchi! Ajke weather ta kemon tomader odike?",
                    "Sotti bolcho? Tarpor ki holo bolo to!"
                )
            }
            ScriptStyle.ENGLISH -> listOf(
                "I completely get what you mean! What are your plans for the rest of the day?",
                "That makes total sense! How is everyone at home doing?",
                "I hear you! Are you relaxing at home right now?",
                "True that! By the way, how has your week been going?",
                "Gotcha! Tell me what else is on your mind."
            )
        }

        val freshBackup = backupPool.filter { it.trim().lowercase() !in lowerExcluded }
        if (freshBackup.isNotEmpty()) {
            val idx = abs(seedText.hashCode() + previousOwnReplies.size * 13) % freshBackup.size
            return freshBackup[idx]
        }
        return backupPool[abs(seedText.hashCode() + previousOwnReplies.size) % backupPool.size]
    }

    fun buildSmartContextualReply(
        messages: List<ChatMessage>,
        extraExcludedReplies: Set<String> = emptySet()
    ): ReplyOptions {
        val ctx = analyzeConversationThread(messages, extraExcludedReplies)
        val lastIncoming = ctx.lastIncomingMessage
        val script = ctx.scriptStyle
        val pronoun = ctx.pronounStyle
        val prevTopic = ctx.previousTopic
        val previousOwn = ctx.previousOwnReplies

        val lower = lastIncoming.lowercase().trim()
        val padded = " " + lower.replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "
        val normalizedShort = padded.trim().replace(Regex("\\s+"), " ")

        fun hasAny(vararg words: String): Boolean {
            return words.any { w ->
                if (w.startsWith(" ") || w.endsWith(" ")) padded.contains(w)
                else lower.contains(w)
            }
        }

        // =========================================================================
        // 1. REPEATED QUESTION / "I ALREADY TOLD YOU" COMPLAINT
        // ("Bollam to korci ...abar jiggas korla je", "agei to bollam", "ek kotha koybar")
        // =========================================================================
        if (hasAny(
                "bollam to", "bolcilam to", "bolলাম তো", "বললাম তো", "আগেই তো বললাম", "agei to bollam",
                "abar jiggas", "abar jiggesh", "abar bolla", "আবার জিজ্ঞেস", "কয়বার বলব", "koybar bolbo",
                "ek kotha", "এক কথা"
            )
        ) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "ওহ সরি দোস্ত! উপরের মেসেজটা ঠিকমতো খেয়াল করিনি। তা এখন কী করছিস বল?",
                        "হাহা সরি রে, তাড়াহুড়োয় খেয়াল ছিল না যে আগেই বলেছিস! আজকে কী দিয়ে নাস্তা করলি?"
                    ), previousOwn, lastIncoming, script, pronoun)
                    PronounStyle.APNI -> "ওহ দুঃখিত, আমি আপনার আগের মেসেজটি ঠিকমতো খেয়াল করিনি। এখন কী করছেন আপনি?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "ওহ সরি! আসলে উপরের মেসেজটা ঠিকমতো খেয়াল করিনি। তা এখন কী করছো বলো?",
                        "হাহা সরি, আমার খেয়াল ছিল না যে তুমি আগেই বলেছো! আজকে কী দিয়ে নাস্তা করলে?",
                        "আরে সরি ভাই, তাড়াহুড়োয় খেয়াল করিনি! এখন কী বাসায় বসে আছো?"
                    ), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "Oh sorry dosto! Uporer message ta thikmoto kheyal kori nai. Ta ekhon ki koros bol?",
                        "Haha sorry re, amar kheyal chilo na je agei bolsis! Ajke ki diye nasta korli?"
                    ), previousOwn, lastIncoming, script, pronoun)
                    PronounStyle.APNI -> "Oh dukkhito, ami apnar ager message ti thikmoto kheyal kori nai. Ekhon ki korchen apni?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "Oh sorry! Ashole uporer message ta thikmoto kheyal kori nai. Ta ekhon ki korcho bolo?",
                        "Haha sorry, amar kheyal chilo na je tumi agei bolcho! Ajke ki diye nasta korla?",
                        "Areh sorry, tarahuroy kheyal kori nai! Ekhon ki basay bose acho?"
                    ), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.ENGLISH -> "Oh my bad, I missed that you already mentioned it! What are you up to right now?"
            }
            return ReplyOptions(replyText, "Apology • Attentive")
        }

        // =========================================================================
        // 2. IDENTITY / "WHO ARE YOU?" ("Tmi asole k", "Tumi ke", "Tui ke", "Apni ke", "Bot naki")
        // =========================================================================
        if (hasAny(
                "asole k", "ashole ke", "asole ke", "tmi k", "tumi ke", "tui ke", "apni ke",
                "ke tumi", "ke tui", "ke apni", "porichoy", "chinte parlam na", "chinte parchi na",
                "bot naki", "robot naki", "ai naki", "তুমি আসলে কে", "তুমি কে", "তুই কে", "আপনি কে", "চিনতে পারছি না"
            ) || normalizedShort in listOf("tmi k", "tumi k", "tui k", "k tmi", "k tumi", "ke")
        ) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "আরে দোস্ত আমাকে চিনতে পারছিস না? আমি শাহরিয়ার! মশকরা করছিস নাকি?",
                        "হাহা কী বলিস, এতক্ষণ ধরে কথা বলছি আর এখন জিজ্ঞেস করছিস আমি কে!"
                    ), previousOwn, lastIncoming, script, pronoun)
                    PronounStyle.APNI -> "জি, আমি শাহরিয়ার বলছি। আপনি কি আমাকে চিনতে পারছেন না?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "আরে কী বলছো, আমাকে চিনতে পারছো না? আমি শাহরিয়ার বলছি!",
                        "হাহা মশকরা করছো নাকি? এতক্ষণ তোমার সাথেই তো কথা বলছি!",
                        "আমি শাহরিয়ার! হঠাৎ এই প্রশ্ন করছো কেন বলো তো?"
                    ), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "Areh dosto amake chinte parsis na? Ami Shahriar! Moshkora koros naki?",
                        "Haha ki bolis, etokhon kotha bolchi ar ekhon jiggesh koros ami ke!"
                    ), previousOwn, lastIncoming, script, pronoun)
                    PronounStyle.APNI -> "Ji, ami Shahriar bolchi. Apni ki amake chinte parchen na?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "Areh ki bolcho, amake chinte parcho na? Ami Shahriar bolchi!",
                        "Haha moshkora korcho naki? Etokhon tomar sathei to kotha bolchi!",
                        "Ami Shahriar! Hothat ei proshno korcho keno bolo to?"
                    ), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.ENGLISH -> "Haha what do you mean who am I? It's me, Shahriar! Are you teasing me?"
            }
            return ReplyOptions(replyText, "Identity")
        }

        // =========================================================================
        // 3. PRE-QUESTION / PERMISSION TO ASK ("Akta Kotha boloto", "Ami akta jinis jiggas kirbo")
        // =========================================================================
        if (hasAny(
                "akta kotha", "ekta kotha", "kotha boloto", "kotha bolo to", "kotha boli",
                "jinis jiggas", "jinish jiggesh", "jiggas kirbo", "jiggas korbo", "jiggesh korbo",
                "kichu bolbo", "kisu bolbo", "shuno na", "suno na", "একটা কথা", "জিজ্ঞেস করবো", "কিছু বলবো", "শোনো না"
            )
        ) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "হ্যাঁ দোস্ত বল, কী বলবি? শুনছি তো!",
                        "অবশ্যই বল দোস্ত, কী জিজ্ঞেস করবি নিঃসংকোচে বল!"
                    ), previousOwn, lastIncoming, script, pronoun)
                    PronounStyle.APNI -> "জি অবশ্যই বলুন, কী জানতে চান?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "হ্যাঁ অবশ্যই বলো, কী বলবে? শুনছি তো!",
                        "হ্যাঁ বলো না, কী জিনিস জিজ্ঞেস করবে? কোনো সমস্যা নেই!",
                        "নিশ্চয়ই বলো, আমি শুনছি!"
                    ), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "Haa dosto bol, ki bolbi? Shunchi to!",
                        "Obosshoi bol dosto, ki jinis jiggesh korbi bol!"
                    ), previousOwn, lastIncoming, script, pronoun)
                    PronounStyle.APNI -> "Ji obosshoi bolun, ki jiggesh korben?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "Haa obosshoi bolo, ki bolba? Shunchi to!",
                        "Haa bolo na, ki jinis jiggesh korba? Kono somossa nai!",
                        "Nischoi bolo, ami shunchi to!"
                    ), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.ENGLISH -> "Sure, go ahead and ask! I'm listening."
            }
            return ReplyOptions(replyText, "Invite Question")
        }

        // =========================================================================
        // 4. AFFECTIONATE / PARTNER CALL-OUT ("Babu", "Jaan", "Shona", "Pakhi")
        // =========================================================================
        if (normalizedShort in listOf("babu", "jaan", "jan", "shona", "sona", "pakhi", "বাবু", "জান", "সোনা", "পাখি") ||
            hasAny("ki koro babu", "kothay babu", "babu ki koro", "jaan ki koro")
        ) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "হ্যাঁ বাবু বলো, কী করছো এখন?",
                    "বলো বাবু, শুনছি তো! তোমার কী অবস্থা?",
                    "হ্যাঁ জান বলো, কী খবর তোমার?"
                ), previousOwn, lastIncoming, script, pronoun)
                else -> pickUniqueReply(listOf(
                    "Haa babu bolo, ki korcho ekhon?",
                    "Bolo babu, shunchi to! Ki obostha tomar?",
                    "Haa bolo jaan, ki korteso ekhon?"
                ), previousOwn, lastIncoming, script, pronoun)
            }
            return ReplyOptions(replyText, "Affectionate")
        }

        // =========================================================================
        // 5. "NOTHING DONE YET / DAY JUST STARTED" ("Kisui Kori ni....din to matro suru")
        // =========================================================================
        if (hasAny("kisui kori ni", "kichui kori ni", "kichu kori nai", "kisu kori nai", "din to matro", "matro suru", "matro shuru", "কিছুই করিনি", "কিছু করিনি", "দিন তো মাত্র শুরু")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "হ্যাঁ তাও ঠিক, দিন তো কেবল শুরু হলো! সকালের নাস্তা করেছো?",
                    "সত্যিই তো, কেবল সকাল হলো! চা-নাস্তা খাওয়া হয়েছে তোমার?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    "Haa tao thik, din to kebol shuru holo! Sokaler nasta korcho?",
                    "Sotti e to, din kebol shuru! Cha-nasta khawa hoise tomar?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> "True, the day just started! Have you had breakfast yet?"
            }
            return ReplyOptions(replyText, "Morning Chat")
        }

        // =========================================================================
        // 6. COMPOUND FOOD STATEMENT + QUESTION ("Nasta korci...tmi korco ki", "Khawa hoise, tomar?")
        // OR WHEN BOT ALREADY ASKED ABOUT FOOD! (Never ask "Tumi nasta korcho?" back!)
        // =========================================================================
        val senderAlreadyAte = hasAny(
            "nasta korci", "nasta korechi", "nasta korsi", "khawa hoise", "khawa shesh",
            "khaici", "khaisi", "kheyeci", "kheyechi", "khailam", "নাস্তা করছি", "নাস্তা করেছি", "খাওয়া শেষ", "খেয়েছি", "খাইলাম"
        )
        if (hasAny("khaic", "khais", "kheyec", "khawa", "khail", "nasta", "lunch", "dinner", "খাইছ", "খেয়েছ", "খাওয়া", "নাস্তা")) {
            // Check if it's specifically about menu ("ki diye")
            if (hasAny("ki diye", "ki khaila", "ki khaiso", "ki ranna", "কী দিয়ে", "কি দিয়ে", "কী খাইছ", "কি খাইছ", "কী রান্না")) {
                val replyText = when (script) {
                    ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "ভাত আর মাংস দিয়ে খাইলাম রে। তুই কী দিয়ে খাইলি?" else "ভাত আর মুরগির মাংস দিয়ে খাইলাম। তুমি কী দিয়ে খাইছো?",
                        "আজকে ভাত, ডাল আর ভাজি দিয়ে খেয়েছি। তোমার কী মেনু ছিল?"
                    ), previousOwn, lastIncoming, script, pronoun)
                    else -> pickUniqueReply(listOf(
                        if (pronoun == PronounStyle.TUI) "Vat ar mangsho diye khailam re. Tui ki diye khaili?" else "Vat ar murgir mangsho diye khailam. Tumi ki diye khaico?",
                        "Ajke vat, dal ar vaji diye kheyechi. Tomar ki menu chilo?"
                    ), previousOwn, lastIncoming, script, pronoun)
                }
                return ReplyOptions(replyText, "Meal Menu")
            }

            // If sender ALREADY said they ate (e.g., "Nasta korci...tmi korco ki") OR bot already asked about food earlier:
            // DO NOT ask "Tumi nasta korcho?" again! Answer for yourself and ask what they ate or what they are doing now!
            if (senderAlreadyAte || ctx.botAlreadyAskedFood) {
                val replyText = when (script) {
                    ScriptStyle.BANGLA -> when (pronoun) {
                        PronounStyle.TUI -> pickUniqueReply(listOf(
                            "হ্যাঁ দোস্ত, আমিও একটু আগেই নাস্তা সেরে নিলাম আলহামদুলিল্লাহ! আজকে কী দিয়ে খাইলি?",
                            "আলহামদুলিল্লাহ আমারও খাওয়া শেষ দোস্ত! এখন কী করছিস বসে?"
                        ), previousOwn, lastIncoming, script, pronoun)
                        PronounStyle.APNI -> "জি আলহামদুলিল্লাহ, আমিও কিছুক্ষণ আগে খেয়ে নিয়েছি। এখন কী করছেন আপনি?"
                        PronounStyle.TUMI -> pickUniqueReply(listOf(
                            "হ্যাঁ, আমিও একটু আগেই চা-নাস্তা করে নিলাম আলহামদুলিল্লাহ! আজকে কী দিয়ে নাস্তা করলে?",
                            "আলহামদুলিল্লাহ আমারও খাওয়া শেষ! এখন কী করছো বসে?",
                            "হ্যাঁ আমারও খাওয়া হয়ে গেছে আলহামদুলিল্লাহ! আজকে কী রান্না ছিল তোমাদের?"
                        ), previousOwn, lastIncoming, script, pronoun)
                    }
                    ScriptStyle.BANGLISH -> when (pronoun) {
                        PronounStyle.TUI -> pickUniqueReply(listOf(
                            "Haa dosto, amio ektu agei nasta sere nilam Alhamdulillah! Ajke ki diye khaili?",
                            "Alhamdulillah amaro khawa shesh dosto! Ekhon ki koros bose?"
                        ), previousOwn, lastIncoming, script, pronoun)
                        PronounStyle.APNI -> "Ji Alhamdulillah, amio kichukhon age kheye niyechi. Ekhon ki korchen apni?"
                        PronounStyle.TUMI -> pickUniqueReply(listOf(
                            "Haa, amio ektu agei cha-nasta kore nilam Alhamdulillah! Ajke ki diye nasta korla?",
                            "Alhamdulillah amaro nasta shesh! Ekhon ki korteso bose?",
                            "Haa amaro khawa hoye gese Alhamdulillah! Ajke ki diye khaila tumi?"
                        ), previousOwn, lastIncoming, script, pronoun)
                    }
                    ScriptStyle.ENGLISH -> "Yep, I finished eating a little while ago too! What did you have today?"
                }
                return ReplyOptions(replyText, "Food Answered")
            }

            // Otherwise, sender is asking us first if we ate ("Khaico ki?", "Nasta korcho?")
            val isNasta = hasAny("nasta", "cha ", "নাস্তা", "চা ")
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("হ্যাঁ দোস্ত, একটু আগেই খাইলাম। তুই খাইছিস?", "এইতো কেবল খাওয়া শেষ করলাম। তোর খাওয়া হইছে?"), previousOwn, lastIncoming, script, pronoun)
                    PronounStyle.APNI -> if (isNasta) "জি আলহামদুলিল্লাহ, নাস্তা করেছি। আপনি নাস্তা করেছেন?" else "জি আলহামদুলিল্লাহ, আমার খাওয়া হয়েছে। আপনি খেয়েছেন?"
                    PronounStyle.TUMI -> if (isNasta) "হ্যাঁ, চা-নাস্তা একটু আগেই শেষ করলাম। তুমি নাস্তা করেছো?" else pickUniqueReply(listOf("হ্যাঁ, আলহামদুলিল্লাহ একটু আগেই খাইলাম। তুমি খাইছো?", "এইতো কিছুক্ষণ আগে খাওয়া শেষ করলাম। তোমার খাওয়া দাওয়া হইছে?"), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("Haa dosto, ektu agei khailam. Tui khaisos?", "Eito kebol khawa shesh korlam. Tor khawa hoise?"), previousOwn, lastIncoming, script, pronoun)
                    PronounStyle.APNI -> if (isNasta) "Ji Alhamdulillah, nasta korechi. Apni nasta korechen?" else "Ji Alhamdulillah, amar khawa hoyeche. Apni kheyechen?"
                    PronounStyle.TUMI -> if (isNasta) "Haa, cha-nasta ektu agei korlam. Tumi nasta korcho?" else pickUniqueReply(listOf("Haa, ektu agei khailam Alhamdulillah. Tumi khaico?", "Eito kichukhon age khawa shesh korlam. Tomar khawa hoise?"), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.ENGLISH -> "Yeah, just finished eating a little while ago! Did you eat?"
            }
            return ReplyOptions(replyText, "Food")
        }

        // =========================================================================
        // 7. COMPOUND WELLBEING + RECIPROCAL QUESTION ("Alhamdulilha valo tmr ki obostha", "Valo achi, tumi kemon acho?")
        // =========================================================================
        val hasWellbeingAnswer = hasAny("jasce", "jacche", "alhamdulilha valo", "alhamdulillah valo", "alhamdulillah bhalo", "valo achi", "bhalo achi", "valo jacche", "ভালো যাচ্ছে", "আলহামদুলিল্লাহ ভালো")
        val hasHowAreYouQuestion = hasAny("kemon", "kmn", "ki khobor", "ki obostha", "কেমন", "কী খবর", "কি খবর", "কী অবস্থা", "কি অবস্থা", "how are you", "how r u", "what's up", "whats up")

        if (hasWellbeingAnswer && hasHowAreYouQuestion) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "আলহামদুলিল্লাহ আমিও বেশ ভালো আছি! এখন কী করছো বলো?",
                    "যাক আলহামদুলিল্লাহ, আমারও সব ভালো চলছে! চা-নাস্তা বা খাওয়া হয়েছে তোমার?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    "Alhamdulillah amio bhalo achi! Ekhon ki korcho bolo?",
                    "Jak Alhamdulillah, amaro sob bhalo cholche! Khawa-dawa ba nasta hoise tomar?",
                    "Alhamdulillah amio bhalo achi! Basay bose acho naki baire?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> "Alhamdulillah I'm doing great too! What are you up to right now?"
            }
            return ReplyOptions(replyText, "Wellbeing + Reciprocal")
        }

        if (hasWellbeingAnswer) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "আলহামদুলিল্লাহ, শুনে ভালো লাগলো! এখন কী করছো?",
                    "যাক আলহামদুলিল্লাহ! বাসার সবাই ভালো আছে তো?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    "Alhamdulillah, shune bhalo laglo! Ekhon ki korcho?",
                    "Jak Alhamdulillah! Basar sobai bhalo ache to?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> "Alhamdulillah, glad to hear that! What are you up to right now?"
            }
            return ReplyOptions(replyText, "Wellbeing Reply")
        }

        if (hasHowAreYouQuestion) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> "আলহামদুলিল্লাহ ভালো আছি দোস্ত! তোর কী খবর বল?"
                    PronounStyle.APNI -> "জি আলহামদুলিল্লাহ, আপনার দোয়ায় ভালো আছি। আপনি কেমন আছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("আলহামদুলিল্লাহ বেশ ভালো আছি! তোমার কী খবর বলো?", "এইতো আলহামদুলিল্লাহ সব ভালো চলছে। তোমার দিনকাল কেমন যাচ্ছে?"), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> "Alhamdulillah bhalo achi dosto! Tor ki khobor bol?"
                    PronounStyle.APNI -> "Ji Alhamdulillah, bhalo achi. Apni kemon achen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Alhamdulillah bhalo achi! Tomar ki khobor bolo?", "Eito Alhamdulillah sob bhalo cholche. Tomar dinkal kemon jacche?"), previousOwn, lastIncoming, script, pronoun)
                }
                ScriptStyle.ENGLISH -> "Doing great, Alhamdulillah! How's everything going with you?"
            }
            return ReplyOptions(replyText, "Wellbeing")
        }

        // =========================================================================
        // 8. RECIPROCAL SHORT FOLLOW-UPS ("tumi?", "tui?", "apni?", "Haa. Tumi?")
        // =========================================================================
        if (normalizedShort in listOf(
                "tumi", "ar tumi", "tui", "ar tui", "apni", "ar apni",
                "haa tumi", "haa tui", "ha tumi", "ha tui", "ji apni", "haa apni",
                "তুমি", "আর তুমি", "তুই", "আর তুই", "আপনি", "আর আপনি",
                "হ্যাঁ তুমি", "হ্যাঁ তুই", "জি আপনি", "হ্যাঁ আপনি", "you", "and you"
            )
        ) {
            val replyText = when (prevTopic) {
                ConversationTopic.FOOD -> when (script) {
                    ScriptStyle.BANGLA -> when (pronoun) {
                        PronounStyle.TUI -> pickUniqueReply(listOf("হ্যাঁ দোস্ত, আমিও একটু আগেই ভাত খেয়ে নিলাম!", "হ্যাঁ রে, আমারও খাওয়া শেষ!"), previousOwn, lastIncoming, script, pronoun)
                        PronounStyle.APNI -> "জি আলহামদুলিল্লাহ, আমিও কিছুক্ষণ আগে খেয়ে নিয়েছি।"
                        PronounStyle.TUMI -> pickUniqueReply(listOf("হ্যাঁ, আমিও একটু আগেই খাওয়া শেষ করলাম আলহামদুলিল্লাহ!", "হ্যাঁ আমারও খাওয়া শেষ! এখন একটু বিশ্রাম নিচ্ছি।"), previousOwn, lastIncoming, script, pronoun)
                    }
                    ScriptStyle.BANGLISH -> when (pronoun) {
                        PronounStyle.TUI -> pickUniqueReply(listOf("Haa dosto, amio ektu agei kheye nilam!", "Haa re, amaro khawa shesh!"), previousOwn, lastIncoming, script, pronoun)
                        PronounStyle.APNI -> "Ji Alhamdulillah, amio kichukhon age kheye niyechi."
                        PronounStyle.TUMI -> pickUniqueReply(listOf("Haa, amio ektu agei khawa shesh korlam Alhamdulillah!", "Haa amaro khawa shesh! Ekhon ektu bose achi."), previousOwn, lastIncoming, script, pronoun)
                    }
                    ScriptStyle.ENGLISH -> "Yep, I already ate a little while ago too!"
                }
                ConversationTopic.ACTIVITY_WORK -> when (script) {
                    ScriptStyle.BANGLA -> if (pronoun == PronounStyle.TUI) "আমিও এইতো বাসায় বসে একটু ফোন দেখছি রে!" else "আমিও এইতো বাসায় বসে একটু বিশ্রাম নিচ্ছি!"
                    else -> if (pronoun == PronounStyle.TUI) "Amio eito basay bose ektu rest nicchi re!" else "Amio eito basay bose ektu rest nicchi!"
                }
                else -> when (script) {
                    ScriptStyle.BANGLA -> "আলহামদুলিল্লাহ আমিও বেশ ভালো আছি!"
                    else -> "Alhamdulillah amio bhalo achi!"
                }
            }
            return ReplyOptions(replyText, "Context: ${prevTopic.name}")
        }

        // =========================================================================
        // 9. FOLLOW-UP "Na / এখনো না"
        // =========================================================================
        if (normalizedShort in listOf("na", "nah", "na re", "na bhai", "na dosto", "ekhono na", "khai nai", "না", "নাহ", "এখনো না", "খাই নি", "খাইনি", "not yet", "no")) {
            if (prevTopic == ConversationTopic.FOOD || hasAny("khai")) {
                val replyText = when (script) {
                    ScriptStyle.BANGLA -> if (pronoun == PronounStyle.TUI) "আরে এখনো খাসনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নে দোস্ত!" else "আরে এখনো খাওনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নাও!"
                    ScriptStyle.BANGLISH -> if (pronoun == PronounStyle.TUI) "Areh ekhono khas nai keno? Deri na kore taratari kheye ne dosto!" else "Areh ekhono khao nai keno? Deri na kore taratari kheye nao!"
                    ScriptStyle.ENGLISH -> "Oh, how come you haven't eaten yet? Go grab something to eat soon!"
                }
                return ReplyOptions(replyText, "Context: Food")
            }
        }

        // =========================================================================
        // 10. CLARIFICATION / CONFUSION ("tmi ki kotha bujho na", "ki sob bolteco", "ki confirm korba")
        // =========================================================================
        if (hasAny("kotha bujho", "kotha bujhis", "ki sob bol", "ki boltec", "ki bolcho", "ki bolis", "ki confirm", "ki janab", "mane ki", "pagol naki", "কথা বুঝো", "কী সব বল", "কি সব বল", "কী বলছ", "কি বলছ", "কী জানাব", "কী কনফার্ম", "মানে কী")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "আরে না, আসলে অন্য একটা কাজে একটু অন্যমনস্ক ছিলাম! বলো কী বলছিলে?",
                    "হাহা সরি! তাড়াহুড়োয় উল্টাপাল্টা টাইপ হয়ে গেছে। বলো কী অবস্থা তোমার?",
                    "আরে বুঝতে পেরেছি! একটু ব্যস্ত ছিলাম তো তাই ঠিকমতো লেখার সময় পাইনি।"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    "Areh na, ashole onno ekta kaje ektu busy chilam tai kheyal kori nai! Bolo ki bolchile?",
                    "Haha sorry bhai, tarahuroy ulta-palta type hoye gese! Ekhon bolo ki obostha?",
                    "Areh bujhchi to! Ektu kaje atke chilam tai thikmoto likhte pari nai, bolo ebar!",
                    "Haha na re bhai, matha ektu onno dike chilo! Bolo ki khobor tomar?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> "Haha my bad! I was distracted doing something else on my phone. What were you saying?"
            }
            return ReplyOptions(replyText, "Clarification")
        }

        // =========================================================================
        // 11. CASUAL STATUS UPDATES ("aito aci", "eito achi", "kono khobor nai")
        // =========================================================================
        if (hasAny("aito ac", "eito ach", "eito ac", "aito ach", "kono khobor nai", "khobor nai", "temon kichu na", "cholche", "এইতো আছি", "কোনো খবর নাই", "তেমন কিছু না", "চলছে আরকি")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "এইতো, আমাদেরও একই অবস্থা—সব স্বাভাবিক চলছে! এখন কী করছো?",
                    "ভালো থাকলেই ভালো! বাসার সবার কী অবস্থা?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    "Eito, amaro sob normal e cholche! Ekhon ki korcho?",
                    "Bhalo thaklei holo! Basar sobai bhalo ache to?",
                    "Hmm bujhlam! Ekhon ki basay bose acho naki baire?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> "Same here, everything is going pretty normal! What are you up to right now?"
            }
            return ReplyOptions(replyText, "Status Update")
        }

        // =========================================================================
        // 12. SINGLE-WORD "Ki" / "Ki?"
        // =========================================================================
        if (normalizedShort in listOf("ki", "kii", "ki re", "ki bhai", "কী", "কি", "কী রে", "কি ভাই", "what")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    "তেমন কিছু না, এমনিই খোঁজ নিচ্ছিলাম তোমার কী খবর!",
                    "বলছিলাম যে এখন কী করছো?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    "Temon kichu na, emnii jiggesh korchilam tomar ki khobor!",
                    "Bolchilam je ekhon ki korcho basay bose?",
                    "Emnii bhai, dekhlam online acho tai knock dilam!"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> "Nothing much, just checking in to see how you're doing!"
            }
            return ReplyOptions(replyText, "Follow-up")
        }

        // =========================================================================
        // 13. WHAT ARE YOU DOING ("ki koro", "ki koros", "ki korcho")
        // =========================================================================
        if (hasAny("ki koro", "ki koros", "ki korc", "ki kortes", "ki koris", "কী কর", "কি কর", "what are you doing", "wyd", "whatcha doing")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "এইতো দোস্ত, বাসায় বসে ফোন চাপছি। তুই কী করিস?" else "এইতো বাসায় বসে আছি, একটু ফোন দেখছিলাম। তুমি কী করছো?",
                    "এইতো একটু বিশ্রাম নিচ্ছি। তোমার খবর কী বলো?",
                    "বাসায় বসে একটু ইউটিউব দেখছিলাম। তুমি কী করছো এখন?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "Eito dosto, basay bose phone chapchi. Tui ki koros?" else "Eito basay bose achi, ektu rest nicchi. Tumi ki korcho?",
                    "Eito ektu hater kaj sarchilam. Tomar ki obostha bolo?",
                    "Basay bose ektu phone dekhchilam. Tumi ki korteso ekhon?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> "Just chilling at home and checking my phone. What are you up to?"
            }
            return ReplyOptions(replyText, "Activity")
        }

        // =========================================================================
        // 14. WHERE ARE YOU ("koi", "kothay", "basay naki")
        // =========================================================================
        if (hasAny(" koi ", "koi?", "kothay", "basay naki", "bashay naki", "কই", "কোথায়", "বাসায় নাকি", "where are you", "wya") || lower == "koi") {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf("আমি এখন বাসাতেই আছি। তুমি কোথায়?", "এইতো বাসায় আছি। তুমি কোথায় আছো এখন?"), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf("Ami ekhon basay achi. Tumi kothay?", "Eito basay achi bhai. Tumi koi acho ekhon?"), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> "I'm at home right now. Where are you?"
            }
            return ReplyOptions(replyText, "Location")
        }

        // =========================================================================
        // 15. SALAM / GREETINGS / ACKNOWLEDGMENTS / OTHER INTENTS
        // =========================================================================
        if (hasAny("salam", "assalamu", "slm", "সালাম", "আসসালামু")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf("ওয়ালাইকুম আসসালাম! কেমন আছো বলো?", "ওয়ালাইকুম আসসালাম ভাই! সব কেমন চলছে?"), previousOwn, lastIncoming, script, pronoun)
                else -> pickUniqueReply(listOf("Walaikum Assalam! Kemon acho bolo?", "Walaikum Assalam bhai! Ki obostha tomar?"), previousOwn, lastIncoming, script, pronoun)
            }
            return ReplyOptions(replyText, "Greeting")
        }

        if (lower in listOf("hy", "hi", "hlw", "hello", "hey", "oi", "oii", "kire", "ki re", "vai", "bhai", "dosto", "হাই", "হ্যালো", "ওই", "কিরে", "ভাই", "দোস্ত") ||
            lower.startsWith("hi ") || lower.startsWith("hlw ") || lower.startsWith("hello ") || lower.startsWith("hey ")
        ) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI || lower.contains("কিরে") || lower.contains("ওই")) "হ্যাঁ দোস্ত বল, কী খবর তোর?" else "হ্যালো! কী খবর, কেমন আছো?",
                    "হ্যাঁ বলো, কেমন চলছে সব?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI || lower.contains("kire") || lower.contains("oi")) "Haa dosto bol, ki khobor tor?" else "Haa bolo, kemon cholche sob?",
                    "Hey! Ki khobor bolo, kemon acho?",
                    "Hlw! Ki obostha tomar bolo?"
                ), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> "Hey! What's up? How's it going?"
            }
            return ReplyOptions(replyText, "Greeting")
        }

        if (lower in listOf("hmm", "hm", "humm", "ok", "okay", "k", "accha", "acha", "thik ache", "oh", "ooh", "হুম", "হম", "আচ্ছা", "ওকে", "ঠিক আছে") ||
            hasAny("thank", "dhonnobad", "ধন্যবাদ")
        ) {
            val isThanks = hasAny("thank", "dhonnobad", "ধন্যবাদ")
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (isThanks) "আরে ধন্যবাদ দেওয়া লাগবে না! সব ঠিক আছে।"
                else pickUniqueReply(listOf("হুম, তারপর বলো আর কী খবর?", "আচ্ছা ঠিক আছে! এখন কী করছো?", "হুম বুঝলাম! বাসার সবাই ভালো তো?"), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.BANGLISH -> if (isThanks) "Areh dhonnobad dewa lagbe na! Sob thik ache."
                else pickUniqueReply(listOf("Hmm, tarpor bolo ar ki khobor?", "Accha thik ache! Ekhon ki korcho?", "Hmm bujhlam! Basar sobai bhalo to?"), previousOwn, lastIncoming, script, pronoun)
                ScriptStyle.ENGLISH -> if (isThanks) "Anytime! Happy to help!" else "Sounds good! So what else is new with you?"
            }
            return ReplyOptions(replyText, "Acknowledgment")
        }

        // Disbelief / Surprise ("sotti", "asolei", "tai naki", "ki bolos")
        if (hasAny("sotti", "asolei", "tai naki", "ki bolos", "ki bolo", "সত্যি", "তাই নাকি", "কী বলো")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "হ্যাঁ একদম সত্যি বলছি! বিশ্বাস হচ্ছে না তোমার?"
                else -> "Haa ekdom sotti bolchi!Tomar bisshas hocche na?"
            }
            return ReplyOptions(replyText, "Confirmation")
        }

        // Sad / Tired / Bored ("mon kharap", "vallage na", "bhalo lagche na", "tired", "klanto", "boring")
        if (hasAny("mon kharap", "vallage na", "valuk lage na", "bhalo lagche na", "valo lagce na", "klanto", "tired", "boring", "মন খারাপ", "ভালো লাগছে না", "ক্লান্ত")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "আরে মন খারাপ করছো কেন? কী হয়েছে আমাকে খুলে বলো তো!"
                else -> "Areh mon kharap korcho keno? Ki hoyeche amake khule bolo to!"
            }
            return ReplyOptions(replyText, "Empathy")
        }

        // Wait / Coming ("darao", "wait", "ashchi", "ektu por")
        if (hasAny("darao", "wait", "ashchi", "aschi", "5 min", "দাঁড়াও", "আসছি")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "আচ্ছা ঠিক আছে, কোনো তাড়া নেই—তুমি কাজ সেরে নাও!"
                else -> "Accha thik ache, kono tara nai—tumi kaj sere nao!"
            }
            return ReplyOptions(replyText, "Patience")
        }

        // Specific Questions (Why / How / Price / Sleep / Family / Health / Weather / Call / Plan)
        if (hasAny("ghum", "good night", "gn ", "good morning", "gm ", "ঘুম", "শুভ রাত্রি", "শুভ সকাল", "sleep")) {
            val isMorning = hasAny("morning", "gm ", "সকাল")
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (isMorning) "শুভ সকাল! ঘুম থেকে উঠলে কখন?" else "এইতো আর কিছুক্ষণ পরই ঘুমিয়ে পড়বো। তুমি ঘুমাওনি এখনো?"
                else -> if (isMorning) "Good morning! Ghum theke uthla kokhon?" else "Eito ektu porei ghumabo. Tumi ghumao nai ekhono?"
            }
            return ReplyOptions(replyText, "Sleep/Greeting")
        }

        if (hasAny("basar sobai", "bashar sobai", "bhabhi", "vabi", "ammu", "abbu", "family", "বাসার সবাই", "ভাবি", "আম্মু", "আব্বু")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "আলহামদুলিল্লাহ, বাসার সবাই ভালো আছে। তোমাদের বাসার সবাই কেমন আছে?"
                else -> "Alhamdulillah, basar sobai bhalo ache! Tomader basar sobai kemon ache?"
            }
            return ReplyOptions(replyText, "Family")
        }

        if (hasAny("shorir", "jor", "matha", "oshustho", "batha", "শরীর", "জ্বর", "মাথা", "অসুস্থ", "ব্যথা", "sick", "fever", "headache")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "ওহ, এখন শরীর কেমন লাগছে? ঠিকমতো ওষুধ খেয়ে বিশ্রাম নাও।"
                else -> "Oh, ekhon shorir kemon lagche? Thikmoto oshudh kheye rest nao."
            }
            return ReplyOptions(replyText, "Health")
        }

        if (hasAny("brishti", "gorom", "thanda", "weather", "বৃষ্টি", "গরম", "ঠান্ডা", "রোদ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "হ্যাঁ, আজকের আবহাওয়াটা আসলেই অন্যরকম! তোমাদের ওদিকে কী অবস্থা?"
                else -> "Haa, ajker weather ta asholei onnorokom! Tomader odike ki obostha?"
            }
            return ReplyOptions(replyText, "Weather")
        }

        if (hasAny("call", "phone", "কল", "ফোন")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "হ্যাঁ এখন ফ্রি আছি, কল দিতে পারো!"
                else -> "Haa ekhon free achi, call dite paro!"
            }
            return ReplyOptions(replyText, "Call")
        }

        if (hasAny("free", "busy", "basto", "kobe", "kokhon", "dekha", "asba", "asbi", "jaba", "jabi", "ফ্রি", "ব্যস্ত", "কবে", "কখন", "দেখা", "আসবা", "যাবা")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf("আমি এখন মোটামুটি ফ্রি আছি, বলো কী প্ল্যান?", "হাতের কাজটা প্রায় শেষ, একটু পরই একদম ফ্রি হয়ে যাবো!"), previousOwn, lastIncoming, script, pronoun)
                else -> pickUniqueReply(listOf("Ami ekhon motamuti free achi, bolo ki plan?", "Hater kajta pray shesh, ektu porei free hoye jabo!"), previousOwn, lastIncoming, script, pronoun)
            }
            return ReplyOptions(replyText, "Plan")
        }

        if (hasAny(" keno ", " kn ", " কেন ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "আসলে তেমন বড় কিছু না, এমনিই জানার জন্য বলছিলাম আরকি!"
                else -> "Ashole temon kichu na, emnii janar jonno bolchilam arki!"
            }
            return ReplyOptions(replyText, "Question: Why")
        }

        if (hasAny(" kivabe ", " kemne ", " কীভাবে ", " কেমনে ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "এটা খুব সহজ, একটু চেষ্টা করলেই হয়ে যাবে! আমি তোমাকে দেখিয়ে দেবো।"
                else -> "Eita khub sohoj, ektu try korlei hoye jabe! Ami dekhiye dibo tomake."
            }
            return ReplyOptions(replyText, "Question: How")
        }

        if (hasAny(" koto ", " dam ", " taka ", " কত ", " দাম ", " টাকা ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "দামটা এখন আগের চেয়ে একটু কম-বেশি হতে পারে, তুমি কত বাজেট ভাবছো?"
                else -> "Dam ta ekhon ektu kom-beshi hote pare, tumi koto budget vabcho?"
            }
            return ReplyOptions(replyText, "Question: Price/Amount")
        }

        // =========================================================================
        // 16. LARGE DIVERSE CONVERSATIONAL POOL (Never repeats, never uses suffix hack!)
        // =========================================================================
        val isQuestion = lastIncoming.contains("?") || hasAny(" ki ", " ke ", " k ", " kon ", " kothay ")
        val replyText = when (script) {
            ScriptStyle.BANGLA -> pickUniqueReply(
                if (isQuestion) {
                    listOf(
                        "হ্যাঁ, ভালো কথা জিজ্ঞেস করেছো! তুমি কী ভাবছো এটা নিয়ে বলো তো?",
                        "হ্যাঁ বুঝতে পেরেছি! এটার ব্যাপারে তোমার নিজের কী মনে হয়?",
                        "আসলে এই বিষয়টা নিয়ে আমিও চিন্তা করছিলাম, তুমি একটু খুলে বলো?",
                        "ভালো পয়েন্ট বলেছো! এটার ব্যাপারে তোমার প্ল্যান কী?",
                        "হুম প্রশ্নটা যৌক্তিক! তোমার কী মত এ ব্যাপারে?"
                    )
                } else {
                    listOf(
                        "হুম বুঝতে পেরেছি তোমার কথাটা! তা এখন কী করছো তুমি?",
                        "হ্যাঁ বলো, আমি মনোযোগ দিয়ে শুনছি তোমার কথা!",
                        "তা ঠিক বলেছো! আজকে তোমার দিনকাল কেমন কাটছে?",
                        "আসলেই তাই! তোমার বাসার সবাই ভালো আছে তো?",
                        "হ্যাঁ, তোমার কথাটা একদম যৌক্তিক! এখন কি বাসায় আছো?",
                        "বুঝলাম ব্যাপারটা! তা আজকে বিকেলে কী প্ল্যান তোমার?",
                        "একদম খাঁটি কথা বলেছো! তোমার হাতের কাজগুলো শেষ হয়েছে?"
                    )
                },
                previousOwn,
                lastIncoming,
                script,
                pronoun
            )
            ScriptStyle.BANGLISH -> pickUniqueReply(
                if (isQuestion) {
                    listOf(
                        "Haa, bhalo kotha jiggesh korcho! Tumi ki vabcho eita niye bolo to?",
                        "Hmm bujhte perechi! Eitar bapare tomar nijer ki mone hoy bolo?",
                        "Ashole ei baparta niye amio chinta korchilam, arektu khule bolo?",
                        "Bhalo point bolcho! Eitar bapare tomar plan ki?",
                        "Hmm proshnota khub bhalo! Tomar ki mot e bapare?"
                    )
                } else {
                    listOf(
                        "Hmm bujhte perechi tomar kothata! Ta ekhon ki korcho tumi?",
                        "Haa bolo, ami monojog diye shunchi tomar kotha!",
                        "Ta thik bolcho! Tomar basar sobai bhalo ache to?",
                        "Asholei tai! Ekhon ki basatei bose acho tumi?",
                        "Bujhlam baparta! Ta ajke bikele ki plan tomar?",
                        "Ekdom sotti kotha bolcho! Tomar hater kaj gulo shesh hoyeche?",
                        "Haa, amio thik ei bishoytai chinta korchilam!",
                        "Sotti bolcho? Tarpor ki holo bolo to!"
                    )
                },
                previousOwn,
                lastIncoming,
                script,
                pronoun
            )
            ScriptStyle.ENGLISH -> pickUniqueReply(listOf(
                "I hear you! Tell me more about what's on your mind.",
                "Makes total sense! What else were you thinking?",
                "True that! What are your plans for the rest of the day?",
                "Gotcha! How is everything else going on your end?"
            ), previousOwn, lastIncoming, script, pronoun)
        }

        return ReplyOptions(replyText, "${script.name} • ${pronoun.name}")
    }
}
