package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import org.json.JSONObject

object ReplyJsonParser {

    enum class PronounStyle { TUI, TUMI, APNI }
    enum class ScriptStyle { BANGLA, BANGLISH, ENGLISH }
    enum class ConversationTopic {
        NONE, FOOD, ACTIVITY_WORK, LOCATION, WELLBEING, SLEEP, FAMILY, CALL, PLAN_MEET
    }

    data class ThreadContext(
        val windowMessages: List<ChatMessage>,
        val priorMessages: List<ChatMessage>,
        val lastIncomingMessage: String,
        val scriptStyle: ScriptStyle,
        val pronounStyle: PronounStyle,
        val previousTopic: ConversationTopic,
        val previousOwnReplies: Set<String>
    )

    fun parseGeminiResponse(rawText: String): ReplyOptions {
        val cleaned = rawText
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()

        val startIndex = cleaned.indexOf('{')
        val endIndex = cleaned.lastIndexOf('}')
        if (startIndex == -1 || endIndex == -1 || endIndex <= startIndex) {
            throw IllegalArgumentException("Invalid JSON boundaries in AI response")
        }

        val jsonStr = cleaned.substring(startIndex, endIndex + 1)
        val obj = JSONObject(jsonStr)

        val friendly = obj.optString("friendly", "").trim()
        val polite = obj.optString("polite", "").trim()
        val professional = obj.optString("professional", "").trim()

        if (friendly.isEmpty() && polite.isEmpty() && professional.isEmpty()) {
            throw IllegalArgumentException("Empty reply fields in JSON")
        }

        return ReplyOptions(
            friendly = friendly.ifEmpty { polite },
            polite = polite.ifEmpty { friendly },
            professional = professional.ifEmpty { polite }
        )
    }

    fun parseFastSingleReply(rawText: String, selectedTone: String): String {
        val cleaned = rawText
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()

        if (cleaned.startsWith("{") && cleaned.endsWith("}")) {
            try {
                val obj = JSONObject(cleaned)
                val direct = obj.optString("reply", "").trim()
                if (direct.isNotEmpty()) return direct
                val byTone = obj.optString(selectedTone.lowercase(), "").trim()
                if (byTone.isNotEmpty()) return byTone
            } catch (_: Exception) {
            }
        }
        return cleaned.trim { it == '"' || it.isWhitespace() }.lines().firstOrNull { it.isNotBlank() }?.trim() ?: ""
    }

    fun detectScriptStyle(text: String): ScriptStyle? {
        if (text.isBlank()) return null
        val hasBanglaScript = text.any { it in '\u0980'..'\u09FF' }
        if (hasBanglaScript) return ScriptStyle.BANGLA

        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\s]"), " ") + " "
        val banglishMarkers = listOf(
            " ki ", " kemon ", " kmn ", " kothay ", " koi ", " bhai ", " vai ", " vaia ", " dosto ",
            " ache ", " achi ", " acho ", " achen ", " achis ", " korcho ", " koro ", " koros ",
            " koren ", " korteso ", " khaico ", " khaisos ", " khaiso ", " kheyechen ", " khawa ",
            " bhalo ", " valo ", " tumi ", " tui ", " apni ", " amar ", " tomar ", " tor ", " apnar ",
            " haa ", " na ", " nai ", " naki ", " keno ", " kn ", " kobe ", " kokhon ", " kiser ",
            " basay ", " bashay ", " ghum ", " kaj ", " kaje ", " aso ", " asbo ", " jabo ", " jabi ",
            " jaba ", " bol ", " bolo ", " bolen ", " accha ", " acha ", " hlw ", " salam ", " assalamu ",
            " dhonnobad ", " khobor ", " obostha ", " ektu ", " ekhon ", " ar ", " tarpor ", " sotti "
        )
        if (banglishMarkers.any { lower.contains(it) }) {
            return ScriptStyle.BANGLISH
        }
        return null
    }

    fun detectPronounStyle(text: String): PronounStyle? {
        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "
        val tuiMarkers = listOf(
            " tui ", " tor ", " toke ", " koros ", " koris ", " khaisos ", " khaisis ", " achis ",
            " asis ", " jabi ", " bolis ", " dosto ", " mama ", " তুই ", " তোর ", " তোকে ",
            " করিস ", " খাইছিস ", " আছিস ", " যাবি ", " দোস্ত "
        )
        if (tuiMarkers.any { lower.contains(it) }) return PronounStyle.TUI

        val apniMarkers = listOf(
            " apni ", " apnar ", " apnake ", " koren ", " korchen ", " kheyechen ", " achen ",
            " jaben ", " asben ", " bolun ", " bolen ", " sir ", " ভাইয়া ", " আপু ", " আপনি ", " আপনার ",
            " আপনাকে ", " করেন ", " করছেন ", " খেয়েছেন ", " আছেন ", " যাবেন ", " আসবেন ", " বলুন ", " স্যার "
        )
        if (apniMarkers.any { lower.contains(it) }) return PronounStyle.APNI

        val tumiMarkers = listOf(
            " tumi ", " tomar ", " tomake ", " koro ", " korcho ", " khaico ", " khaiso ", " acho ",
            " jaba ", " asba ", " bolo ", " তুমি ", " তোমার ", " তোমাকে ", " করো ", " করছো ", " খাইছো ", " আছো "
        )
        if (tumiMarkers.any { lower.contains(it) }) return PronounStyle.TUMI

        return null
    }

    fun detectTopicFromText(text: String): ConversationTopic {
        val lower = text.lowercase()
        return when {
            listOf("khaic", "khais", "kheyec", "khawa", "vat", "mangsho", "nasta", "খাইছ", "খেয়েছ", "খাওয়া", "ভাত", "নাস্তা", "eat", "food", "lunch", "dinner").any { lower.contains(it) } ->
                ConversationTopic.FOOD
            listOf("ki koro", "ki koros", "ki korc", "kaj", "basto", "busy", "কী কর", "কি কর", "কাজ", "ব্যস্ত", "working", "doing").any { lower.contains(it) } ->
                ConversationTopic.ACTIVITY_WORK
            listOf("koi", "kothay", "basay", "bashay", "কই", "কোথায়", "বাসায়", "where").any { lower.contains(it) } ->
                ConversationTopic.LOCATION
            listOf("ghum", "ratri", "night", "ঘুম", "রাত্রি", "sleep").any { lower.contains(it) } ->
                ConversationTopic.SLEEP
            listOf("basar sobai", "bhabhi", "babu", "ammu", "abbu", "বাসার সবাই", "ভাবি", "বাবু", "family").any { lower.contains(it) } ->
                ConversationTopic.FAMILY
            listOf("call", "phone", "কল", "ফোন").any { lower.contains(it) } ->
                ConversationTopic.CALL
            listOf("kobe", "kokhon", "dekha", "asba", "jaba", "কবে", "কখন", "দেখা", "আসবা", "যাবা", "meet").any { lower.contains(it) } ->
                ConversationTopic.PLAN_MEET
            listOf("kemon", "kmn", "khobor", "obostha", "bhalo", "কেমন", "খবর", "অবস্থা", "ভালো").any { lower.contains(it) } ->
                ConversationTopic.WELLBEING
            else -> ConversationTopic.NONE
        }
    }

    /**
     * Analyzes the last 4-5 messages to determine conversation history context,
     * established pronoun (Tui/Tumi/Apni), script (Bangla/Banglish/English),
     * ongoing topic, and isolates the very last message for immediate reply.
     */
    fun analyzeConversationThread(messages: List<ChatMessage>): ThreadContext {
        val window = messages.takeLast(5)
        val lastIncomingMsg = window.lastOrNull { it.sender == "Incoming" }?.text?.trim()
            ?: window.lastOrNull()?.text?.trim()
            ?: ""

        val prior = if (window.size > 1) window.dropLast(1) else emptyList()
        val prevOwn = window.filter { it.sender == "Me" }.map { it.text.trim() }.toSet()

        // 1. Script style: prefer last incoming message; if ambiguous, inherit from previous 4 messages
        var script = detectScriptStyle(lastIncomingMsg)
        if (script == null) {
            for (m in prior.reversed()) {
                val s = detectScriptStyle(m.text)
                if (s != null) {
                    script = s
                    break
                }
            }
        }
        val finalScript = script ?: ScriptStyle.ENGLISH

        // 2. Pronoun style: check last incoming first; if not explicit, inherit from the previous 4 messages in the thread!
        var pronoun = detectPronounStyle(lastIncomingMsg)
        if (pronoun == null) {
            for (m in prior.reversed()) {
                val p = detectPronounStyle(m.text)
                if (p != null) {
                    pronoun = p
                    break
                }
            }
        }
        val finalPronoun = pronoun ?: PronounStyle.TUMI

        // 3. Ongoing Topic from the prior 4 messages (crucial for answering short follow-ups at the end!)
        var ongoingTopic = ConversationTopic.NONE
        for (m in prior.reversed()) {
            val t = detectTopicFromText(m.text)
            if (t != ConversationTopic.NONE) {
                ongoingTopic = t
                break
            }
        }

        return ThreadContext(
            windowMessages = window,
            priorMessages = prior,
            lastIncomingMessage = lastIncomingMsg,
            scriptStyle = finalScript,
            pronounStyle = finalPronoun,
            previousTopic = ongoingTopic,
            previousOwnReplies = prevOwn
        )
    }

    private fun pickFreshVariation(candidates: List<String>, previousOwnReplies: Set<String>): String {
        for (c in candidates) {
            if (c !in previousOwnReplies) return c
        }
        return candidates.first()
    }

    fun buildSmartFallbackReplies(messages: List<ChatMessage>): ReplyOptions {
        val ctx = analyzeConversationThread(messages)
        val lastIncoming = ctx.lastIncomingMessage
        val script = ctx.scriptStyle
        val pronoun = ctx.pronounStyle
        val prevTopic = ctx.previousTopic
        val previousOwn = ctx.previousOwnReplies

        val lower = lastIncoming.lowercase().trim()
        val padded = " " + lower.replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "

        fun hasAny(vararg words: String): Boolean {
            return words.any { w ->
                if (w.startsWith(" ") || w.endsWith(" ")) padded.contains(w)
                else lower.contains(w)
            }
        }

        // =========================================================================
        // A. MULTI-MESSAGE CONTEXTUAL FOLLOW-UP RESOLUTION (Analyzing last 4-5 SMS)
        // Handles short last messages like "Tumi?", "Haa khailam", "Na", "Keno?", "Kiser?"
        // =========================================================================

        // A1. Reciprocal short follow-ups ("tumi?", "tui?", "apni?", "ar tumi?", "তুমি?", "তুই?", "হ্যাঁ তুমি?")
        if (lower in listOf("tumi?", "tumi", "ar tumi?", "ar tumi", "tui?", "ar tui?", "apni?", "ar apni?", "তুমি?", "আর তুমি?", "তুই?", "আর তুই?", "আপনি?", "হ্যাঁ তুমি?", "হ্যাঁ তুই?", "haa tumi?", "haa tui?", "you?", "and you?")) {
            return when (prevTopic) {
                ConversationTopic.FOOD -> when (script) {
                    ScriptStyle.BANGLA -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "হ্যাঁ দোস্ত, আমিও একটু আগেই ভাত খেয়ে নিলাম!" else "হ্যাঁ, আমিও একটু আগেই খাওয়া শেষ করলাম আলহামদুলিল্লাহ!",
                        polite = "জি আলহামদুলিল্লাহ, আমিও কিছুক্ষণ আগে খেয়ে নিয়েছি।",
                        professional = "জি ধন্যবাদ, আমারও খাওয়া সম্পন্ন হয়েছে।",
                        detectedLanguage = "Bangla (Context: Food)"
                    )
                    ScriptStyle.BANGLISH -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "Haa dosto, amio ektu agei খেয়ে নিলাম!" else "Haa, amio ektu agei khawa shesh korlam Alhamdulillah!",
                        polite = "Ji Alhamdulillah, amio kichukhon age kheye niyechi.",
                        professional = "Ji dhonnobad, amaro khawa shesh hoyeche.",
                        detectedLanguage = "Banglish (Context: Food)"
                    )
                    ScriptStyle.ENGLISH -> ReplyOptions(
                        friendly = "Yep, I already ate a little while ago too!",
                        polite = "Yes, I have had my meal as well, thank you!",
                        professional = "Yes, thank you, I have completed my meal as well.",
                        detectedLanguage = "English (Context: Food)"
                    )
                }
                ConversationTopic.ACTIVITY_WORK -> when (script) {
                    ScriptStyle.BANGLA -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "আমিও এইতো বাসায় বসে একটু ফোন দেখছি রে!" else "আমিও এইতো বাসায় বসে একটু বিশ্রাম নিচ্ছি!",
                        polite = "জি, আমিও বাসায় বসে টুকটাক কাজ করছি।",
                        professional = "জি, আমিও বর্তমানে আমার হাতের কাজগুলো গুছিয়ে নিচ্ছি।",
                        detectedLanguage = "Bangla (Context: Activity)"
                    )
                    else -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "Amio eito basay bose ektu rest nicchi re!" else "Amio eito basay bose ektu rest nicchi!",
                        polite = "Ji, amio basay bose ektu kaj korchi.",
                        professional = "Ji, amio bortomane amar hater kaj gulo korchi.",
                        detectedLanguage = "Banglish (Context: Activity)"
                    )
                }
                else -> when (script) {
                    ScriptStyle.BANGLA -> ReplyOptions(
                        friendly = "আলহামদুলিল্লাহ আমিও বেশ ভালো আছি!",
                        polite = "জি আলহামদুলিল্লাহ, আপনার দোয়ায় আমিও ভালো আছি।",
                        professional = "জি ধন্যবাদ, আলহামদুলিল্লাহ আমিও ভালো আছি।",
                        detectedLanguage = "Bangla (Context)"
                    )
                    else -> ReplyOptions(
                        friendly = "Alhamdulillah amio bhalo achi!",
                        polite = "Ji Alhamdulillah, amio bhalo achi.",
                        professional = "Ji dhonnobad, Alhamdulillah amio bhalo achi.",
                        detectedLanguage = "Banglish (Context)"
                    )
                }
            }
        }

        // A2. Follow-up "Na / এখনো না" when the previous 4-5 messages were about Food or Sleep
        if (lower in listOf("na", "nah", "na re", "na bhai", "ekhono na", "khai nai", "না", "নাহ", "এখনো না", "খাই নি", "খাইনি", "not yet", "no")) {
            if (prevTopic == ConversationTopic.FOOD || hasAny("khai")) {
                return when (script) {
                    ScriptStyle.BANGLA -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "আরে এখনো খাসনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নে দোস্ত!"
                        else "আরে এখনো খাওনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নাও!",
                        polite = "ওহ আচ্ছা, দেরি না করে সময়মতো খাবারটা খেয়ে নিন।",
                        professional = "অনুগ্রহ করে সময়মতো খাবার গ্রহণ করে নিন, শরীরের যত্ন নেওয়া জরুরি।",
                        detectedLanguage = "Bangla (Context: Food)"
                    )
                    ScriptStyle.BANGLISH -> ReplyOptions(
                        friendly = if (pronoun == PronounStyle.TUI) "Areh ekhono khas nai keno? Deri na kore taratari kheye ne dosto!"
                        else "Areh ekhono khao nai keno? Deri na kore taratari kheye nao!",
                        polite = "Oh accha, deri na kore somoymoto khabar ta kheye nin.",
                        professional = "Onugroho kore somoymoto khabar kheye niben.",
                        detectedLanguage = "Banglish (Context: Food)"
                    )
                    ScriptStyle.ENGLISH -> ReplyOptions(
                        friendly = "Oh, how come you haven't eaten yet? Go grab something to eat soon!",
                        polite = "Oh I see! Please make sure to have your meal soon.",
                        professional = "Please take a moment to have your meal when convenient.",
                        detectedLanguage = "English (Context: Food)"
                    )
                }
            }
        }

        // A3. Follow-up "Kiser kaj? / Ki kaj?" when previous messages mentioned work/activity
        if (hasAny("kiser", "ki kaj", "কিসের", "কী কাজ", "কি কাজ") || (prevTopic == ConversationTopic.ACTIVITY_WORK && hasAny("ki ", "keno", "কী ", "কেন"))) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = if (pronoun == PronounStyle.TUI) "এইতো নিজের একটা প্রজেক্ট আর বাসার টুকটাক কাজ করছি রে। একটু পরই ফ্রি হবো!"
                    else "এইতো নিজের একটু জরুরি কাজ আর ফোনের কিছু সেটআপ করছিলাম। অল্প কিছুক্ষণের মধ্যেই শেষ হয়ে যাবে!",
                    polite = "জি, ব্যক্তিগত ও বাসার কিছু প্রয়োজনীয় কাজ গুছিয়ে নিচ্ছিলাম। কিছুক্ষণের মধ্যেই শেষ হবে।",
                    professional = "বর্তমানে একটি প্রজেক্টের কাজ সম্পন্ন করছি। কাজটি শেষ করেই আপনার সাথে বিস্তারিত কথা বলছি।",
                    detectedLanguage = "Bangla (Context: Work)"
                )
                else -> ReplyOptions(
                    friendly = if (pronoun == PronounStyle.TUI) "Eito nijer ekta project ar basar tukitaki kaj korchi re. Ektu porei free hobo!"
                    else "Eito nijer ektu dorkari kaj korchilam. Olpo kichukhoner moddhei shesh hoye jabe!",
                    polite = "Ji, basar o nijer kichu proyojoniyo kaj guchiye nicchilam.",
                    professional = "Bortomane ekti project er kaj sompanno korchi. Shesh korei apnake janacchi.",
                    detectedLanguage = "Banglish (Context: Work)"
                )
            }
        }

        // =========================================================================
        // B. DIRECT INTENT ANALYSIS OF THE LAST MESSAGE (With Pronoun/Script Mirroring)
        // =========================================================================

        // 1. SALAM / ISLAMIC GREETING
        if (hasAny("salam", "assalamu", "slm", "সালাম", "আসসালামু")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "ওয়ালাইকুম আসসালাম দোস্ত! কী খবর তোর?" else "ওয়ালাইকুম আসসালাম! কেমন আছো বলো?",
                        "ওয়ালাইকুম আসসালাম ভাই! সব কেমন চলছে?"
                    ), previousOwn),
                    polite = "ওয়ালাইকুম আসসালাম ওয়া রাহমাতুল্লাহ। আলহামদুলিল্লাহ ভালো আছি, আপনি কেমন আছেন?",
                    professional = "ওয়ালাইকুম আসসালাম। আশা করি ভালো আছেন, বলুন কীভাবে সাহায্য করতে পারি?",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "Walaikum Assalam dosto! Tor ki khobor bol?" else "Walaikum Assalam! Kemon acho bolo?",
                        "Walaikum Assalam bhai! Ki obostha tomar?"
                    ), previousOwn),
                    polite = "Walaikum Assalam Wa Rahmatullah. Alhamdulillah bhalo achi, apni kemon achen?",
                    professional = "Walaikum Assalam. Asha kori bhalo achen, bolun kivabe sahajjo korte pari?",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 2. WHAT DID YOU EAT / MENU ("ki diye", "ki khaila", "ki khaico", "কী দিয়ে খাইছো")
        if (hasAny("ki diye", "ki khaila", "ki khaiso", "ki ranna", "কী দিয়ে", "কি দিয়ে", "কী খাইছ", "কি খাইছ", "কী রান্না")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "ভাত আর মাংস দিয়ে খাইলাম রে। তুই কী দিয়ে খাইলি?" else "ভাত আর মুরগির মাংস দিয়ে খাইলাম। তুমি কী দিয়ে খাইছো?",
                        "আজকে ভাত, ডাল আর ভাজি দিয়ে খেয়েছি। তোমার কী মেনু ছিল?"
                    ), previousOwn),
                    polite = "জি, ভাত ও মাছ দিয়ে খেয়েছি আলহামদুলিল্লাহ। আপনি কী দিয়ে খেয়েছেন?",
                    professional = "জি ধন্যবাদ, বাসার খাবারই খেয়েছি। আশা করি আপনারও খাওয়া সম্পন্ন হয়েছে।",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "Vat ar mangsho diye khailam re. Tui ki diye khaili?" else "Vat ar murgir mangsho diye khailam. Tumi ki diye khaico?",
                        "Ajke vat, dal ar vaji diye kheyechi. Tomar ki menu chilo?"
                    ), previousOwn),
                    polite = "Ji, vat ar mach diye kheyechi Alhamdulillah. Apni ki diye kheyechen?",
                    professional = "Ji dhonnobad, basar khabar e kheyechi. Asha kori apnaro khawa hoyeche.",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 3. HAVE YOU EATEN / MEAL INQUIRY ("khaico", "khaisos", "kheyechen", "khawa", "nasta", "খাইছো")
        if (hasAny("khaic", "khais", "kheyec", "khawa", "khail", "nasta", "lunch", "dinner", "খাইছ", "খেয়েছ", "খাওয়া", "নাস্তা")) {
            val isNasta = hasAny("nasta", "cha ", "নাস্তা", "চা ")
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (isNasta) "হ্যাঁ, চা-নাস্তা একটু আগেই শেষ করলাম। তুমি নাস্তা করছো?"
                        else if (pronoun == PronounStyle.TUI) "হ্যাঁ দোস্ত, একটু আগেই খাইলাম। তুই খাইছিস?"
                        else "হ্যাঁ, আলহামদুলিল্লাহ একটু আগেই খাইলাম। তুমি খাইছো?",
                        if (pronoun == PronounStyle.TUI) "এইতো কেবল খাওয়া শেষ করলাম। তোর খাওয়া হইছে?"
                        else "এইতো কিছুক্ষণ আগে খাওয়া শেষ করলাম। তোমার খাওয়া দাওয়া হইছে?"
                    ), previousOwn),
                    polite = if (isNasta) "জি আলহামদুলিল্লাহ, নাস্তা করেছি। আপনি নাস্তা করেছেন?"
                    else "জি আলহামদুলিল্লাহ, আমার খাওয়া হয়েছে। আপনি খেয়েছেন?",
                    professional = "জি ধন্যবাদ, আমার খাওয়া সম্পন্ন হয়েছে। আশা করি আপনিও সময়মতো খেয়েছেন।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (isNasta) "Haa, cha-nasta ektu agei korlam. Tumi nasta korcho?"
                        else if (pronoun == PronounStyle.TUI) "Haa dosto, ektu agei khailam. Tui khaisos?"
                        else "Haa, ektu agei khailam Alhamdulillah. Tumi khaico?",
                        if (pronoun == PronounStyle.TUI) "Eito kebol khawa shesh korlam. Tor khawa hoise?"
                        else "Eito kichukhon age khawa shesh korlam. Tomar khawa hoise?"
                    ), previousOwn),
                    polite = if (isNasta) "Ji Alhamdulillah, nasta korechi. Apni nasta korechen?"
                    else "Ji Alhamdulillah, amar khawa hoyeche. Apni kheyechen?",
                    professional = "Ji dhonnobad, amar khawa shesh hoyeche. Asha kori apnio kheyechen.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        "Yeah, just finished eating a little while ago! Did you eat?",
                        "Yep, had my meal! What about you, have you eaten yet?"
                    ), previousOwn),
                    polite = "Yes, I have eaten, thank you for asking! Have you had your meal?",
                    professional = "Yes, thank you. I have already had my meal. I hope you had yours as well.",
                    detectedLanguage = "English"
                )
            }
        }

        // 4. WHAT ARE YOU DOING ("ki koro", "ki koros", "ki korcho", "কী করো", "what are you doing")
        if (hasAny("ki koro", "ki koros", "ki korc", "ki kortes", "ki koris", "কী কর", "কি কর", "what are you doing", "wyd", "whatcha doing")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "এইতো দোস্ত, বাসায় বসে ফোন চাপছি। তুই কী করিস?"
                        else "এইতো বাসায় বসে আছি, একটু ফোন দেখছিলাম। তুমি কী করছো?",
                        if (pronoun == PronounStyle.TUI) "তেমন কিছু না রে, একটু বিশ্রাম নিচ্ছি। তোর কী অবস্থা?"
                        else "এইতো একটু বিশ্রাম নিচ্ছি। তোমার খবর কী বলো?"
                    ), previousOwn),
                    polite = "জি, এইতো বাসায় একটু কাজ করছিলাম। আপনি কী করছেন এখন?",
                    professional = "বর্তমানে একটি জরুরি কাজ পর্যালোচনা করছি। কোনো বিষয় থাকলে বলতে পারেন।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "Eito dosto, basay bose phone chapchi. Tui ki koros?"
                        else "Eito basay bose achi, ektu rest nicchi. Tumi ki korcho?",
                        if (pronoun == PronounStyle.TUI) "Temon kichu na re, ektu kaj korchilam. Tor ki khobor?"
                        else "Eito ektu hater kaj sarchilam. Tomar ki obostha bolo?"
                    ), previousOwn),
                    polite = "Ji, eito basay ektu kaj korchilam. Apni ki korchen ekhon?",
                    professional = "Bortomane ektu kaje basto achi. Kono proyojon thakle bolte paren.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        "Just chilling at home and checking my phone. What are you up to?",
                        "Nothing much, just taking a short break! What about you?"
                    ), previousOwn),
                    polite = "I'm just working on a few things at home. How about you?",
                    professional = "I am currently attending to some tasks. Please let me know how I can help you.",
                    detectedLanguage = "English"
                )
            }
        }

        // 5. WHERE ARE YOU ("koi", "kothay", "basay naki", "কই", "কোথায়")
        if (hasAny(" koi ", "koi?", "kothay", "basay naki", "bashay naki", "কই", "কোথায়", "বাসায় নাকি", "where are you", "wya") || lower == "koi") {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "আমি এখন বাসাতেই আছি রে। তুই কই?"
                        else "আমি এখন বাসাতেই আছি। তুমি কোথায়?",
                        "এইতো বাসায় আছি। কেন, কোনো দরকার ছিল?"
                    ), previousOwn),
                    polite = "জি, আমি এখন বাসায় আছি। আপনি কোথায় আছেন?",
                    professional = "জি, আমি বর্তমানে আমার নির্ধারিত স্থানেই আছি। কোনো প্রয়োজন থাকলে জানাতে পারেন।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "Ami ekhon basatei achi re. Tui koi?"
                        else "Ami ekhon basay achi. Tumi kothay?",
                        "Eito basay achi bhai. Tumi koi acho ekhon?"
                    ), previousOwn),
                    polite = "Ji, ami ekhon basay achi. Apni kothay achen?",
                    professional = "Ji, ami bortomane amar sthane achi. Kono dorkar thakle janaben.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = "I'm at home right now. Where are you?",
                    polite = "I am currently at home. Where are you right now?",
                    professional = "I am at my usual location at the moment. Please let me know if you need anything.",
                    detectedLanguage = "English"
                )
            }
        }

        // 6. HOW ARE YOU / WHAT'S UP ("kemon", "kmn", "ki khobor", "ki obostha", "কেমন")
        if (hasAny("kemon", "kmn", "ki khobor", "ki obostha", "কেমন", "কী খবর", "কি খবর", "কী অবস্থা", "কি অবস্থা", "how are you", "how r u", "what's up", "whats up")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "আলহামদুলিল্লাহ ভালো আছি দোস্ত! তোর কী খবর বল?"
                        else "আলহামদুলিল্লাহ বেশ ভালো আছি! তোমার কী খবর বলো?",
                        "এইতো আলহামদুলিল্লাহ সব ভালো চলছে। তোমার দিনকাল কেমন যাচ্ছে?"
                    ), previousOwn),
                    polite = "জি আলহামদুলিল্লাহ, আপনার দোয়ায় ভালো আছি। আপনি কেমন আছেন?",
                    professional = "আলহামদুলিল্লাহ ভালো আছি। আশা করি আপনিও সুস্থ ও ভালো আছেন।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "Alhamdulillah bhalo achi dosto! Tor ki khobor bol?"
                        else "Alhamdulillah bhalo achi! Tomar ki khobor bolo?",
                        "Eito Alhamdulillah sob bhalo cholche. Tomar dinkal kemon jacche?"
                    ), previousOwn),
                    polite = "Ji Alhamdulillah, bhalo achi. Apni kemon achen?",
                    professional = "Alhamdulillah bhalo achi. Asha kori apnio sustho o bhalo achen.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        "Doing great, Alhamdulillah! How's everything going with you?",
                        "All good on my end! How have you been?"
                    ), previousOwn),
                    polite = "I am doing well, thank you for asking! How are you doing?",
                    professional = "I am doing well, thank you. I hope everything is going smoothly on your end.",
                    detectedLanguage = "English"
                )
            }
        }

        // 7. SLEEP / LATE NIGHT / GOOD MORNING
        if (hasAny("ghum", "good night", "gn ", "good morning", "gm ", "ঘুম", "শুভ রাত্রি", "শুভ সকাল", "sleep")) {
            val isMorning = hasAny("morning", "gm ", "সকাল")
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = if (isMorning) "শুভ সকাল! ঘুম থেকে উঠলে কখন?"
                    else if (pronoun == PronounStyle.TUI) "এইতো একটু পরেই ঘুমাবো রে। তুই ঘুমাবি না?"
                    else "এইতো আর কিছুক্ষণ পরই ঘুমিয়ে পড়বো। তুমি ঘুমাওনি এখনো?",
                    polite = if (isMorning) "শুভ সকাল! আশা করি আপনার দিনটি সুন্দর কাটবে।"
                    else "জি, কিছুক্ষণের মধ্যেই ঘুমিয়ে পড়বো। শুভ রাত্রি, ভালো থাকবেন।",
                    professional = if (isMorning) "শুভ সকাল। আপনার দিনটি শুভ হোক।"
                    else "শুভ রাত্রি। আগামীকাল কথা হবে ইনশাআল্লাহ।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = if (isMorning) "Good morning! Ghum theke uthla kokhon?"
                    else if (pronoun == PronounStyle.TUI) "Eito ektu porei ghumabo re. Tui ghumabi na?"
                    else "Eito ektu porei ghumabo. Tumi ghumao nai ekhono?",
                    polite = if (isMorning) "Shuvo sokal! Asha kori apnar dinti bhalo katbe."
                    else "Ji, ektu porei ghumiye porbo. Shuvo ratri, bhalo thakben.",
                    professional = if (isMorning) "Good morning. Wishing you a productive day ahead."
                    else "Shuvo ratri. Agamikal kotha hobe InshaAllah.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = if (isMorning) "Good morning! Hope you have an awesome day!"
                    else "Heading to bed pretty soon! Aren't you sleeping yet?",
                    polite = if (isMorning) "Good morning! Wishing you a lovely day ahead."
                    else "Good night! Sleep well and take care.",
                    professional = if (isMorning) "Good morning! Wishing you a great day."
                    else "Good night. We will catch up tomorrow.",
                    detectedLanguage = "English"
                )
            }
        }

        // 8. FAMILY / HOME WELL-BEING
        if (hasAny("basar sobai", "bashar sobai", "bhabhi", "vabi", "babu", "ammu", "abbu", "family", "বাসার সবাই", "ভাবি", "বাবু", "আম্মু", "আব্বু")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = "আলহামদুলিল্লাহ, বাসার সবাই ভালো আছে। তোমাদের বাসার সবাই কেমন আছে?",
                    polite = "জি আলহামদুলিল্লাহ, দোয়ায় বাসার সবাই ভালো আছে। আপনার পরিবারের সবাই কেমন আছেন?",
                    professional = "আলহামদুলিল্লাহ পরিবারের সবাই সুস্থ আছেন। খোঁজ নেওয়ার জন্য আন্তরিক ধন্যবাদ।",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = "Alhamdulillah, basar sobai bhalo ache! Tomader basar sobai kemon ache?",
                    polite = "Ji Alhamdulillah, basar sobai bhalo ache. Apnar poribarer sobai kemon achen?",
                    professional = "Alhamdulillah poribarer sobai sustho achen. Khoj newar jonno onek dhonnobad.",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 9. CALL / PHONE
        if (hasAny("call", "phone", "কল", "ফোন")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = "হ্যাঁ এখন ফ্রি আছি, কল দিতে পারো!",
                    polite = "জি, আমি এখন কথা বলতে পারবো। আপনি চাইলে কল দিতে পারেন।",
                    professional = "জি, আপনি এখন কল করতে পারেন অথবা একটু পর আমিই কল করছি।",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = "Haa ekhon free achi, call dite paro!",
                    polite = "Ji, ami ekhon free achi. Apni chaile call dite paren.",
                    professional = "Ji, apni ekhon call korte paren othoba ektu por ami call dichhi.",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 10. BUSY / FREE / MEETING / WHEN
        if (hasAny("free", "busy", "basto", "kobe", "kokhon", "dekha", "asba", "asbi", "jaba", "jabi", "ফ্রি", "ব্যস্ত", "কবে", "কখন", "দেখা", "আসবা", "যাবা")) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "হ্যাঁ দোস্ত, হাতের কাজটা সেরেই তোকে জানাচ্ছি!"
                        else "এইতো হাতের কাজটা শেষ করেই তোমাকে জানাচ্ছি!",
                        "আমি এখন মোটামুটি ফ্রি আছি, বলো কী প্ল্যান?"
                    ), previousOwn),
                    polite = "জি, হাতের কাজটি শেষ করেই আমি আপনাকে সময়টা কনফার্ম করছি।",
                    professional = "আমি আমার সময়সূচি দেখে খুব দ্রুত আপনাকে নিশ্চিত করছি।",
                    detectedLanguage = "Bangla"
                )
                else -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI) "Haa dosto, hater kajta shesh korei toke janacchi!"
                        else "Eito hater kajta shesh korei tomake janacchi!",
                        "Ami ekhon motamuti free achi, bolo ki plan?"
                    ), previousOwn),
                    polite = "Ji, hater kajti shesh korei ami apnake confirm korchi.",
                    professional = "Ami amar schedule dekhe khub druto apnake janacchi.",
                    detectedLanguage = "Banglish"
                )
            }
        }

        // 11. SHORT GREETINGS ("hy", "hi", "hlw", "hello", "oi", "kire")
        if (lower in listOf("hy", "hi", "hlw", "hello", "hey", "oi", "oii", "kire", "ki re", "vai", "bhai", "dosto", "হাই", "হ্যালো", "ওই", "কিরে", "ভাই", "দোস্ত") ||
            lower.startsWith("hi ") || lower.startsWith("hlw ") || lower.startsWith("hello ") || lower.startsWith("hey ")
        ) {
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI || lower.contains("কিরে") || lower.contains("ওই")) "হ্যাঁ দোস্ত বল, কী খবর তোর?"
                        else "হ্যালো! কী খবর, কেমন আছো?",
                        "হ্যাঁ ভাই বলো, কী অবস্থা?"
                    ), previousOwn),
                    polite = "হ্যালো! কেমন আছেন আপনি? সব ভালো তো?",
                    professional = "হ্যালো! আশা করি ভালো আছেন। বলুন কীভাবে সাহায্য করতে পারি?",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        if (pronoun == PronounStyle.TUI || lower.contains("kire") || lower.contains("oi")) "Haa dosto bol, ki khobor tor?"
                        else "Hey! Ki khobor bolo, kemon acho?",
                        "Hlw bhai! Ki obostha tomar?"
                    ), previousOwn),
                    polite = "Hello! Apni kemon achen? Sob bhalo to?",
                    professional = "Hello! Asha kori bhalo achen. Kivabe sahajjo korte pari?",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = pickFreshVariation(listOf(
                        "Hey! What's up? How's it going?",
                        "Hey there! Good to hear from you, what's new?"
                    ), previousOwn),
                    polite = "Hello! Hope you're doing well. How are things with you?",
                    professional = "Hello! How can I assist you today?",
                    detectedLanguage = "English"
                )
            }
        }

        // 12. SHORT ACKNOWLEDGMENTS ("hmm", "ok", "accha", "thanks")
        if (lower in listOf("hmm", "hm", "humm", "ok", "okay", "k", "accha", "acha", "thik ache", "oh", "ooh", "হুম", "হম", "আচ্ছা", "ওকে", "ঠিক আছে") ||
            hasAny("thank", "dhonnobad", "ধন্যবাদ")
        ) {
            val isThanks = hasAny("thank", "dhonnobad", "ধন্যবাদ")
            return when (script) {
                ScriptStyle.BANGLA -> ReplyOptions(
                    friendly = if (isThanks) "আরে ধন্যবাদ দেওয়া লাগবে না! সব ঠিক আছে।"
                    else pickFreshVariation(listOf(
                        "হুম, তারপর বলো আর কী খবর?",
                        "আচ্ছা ঠিক আছে! আর সব কেমন চলছে?"
                    ), previousOwn),
                    polite = if (isThanks) "আপনাকেও অসংখ্য ধন্যবাদ! ভালো থাকবেন।"
                    else "জি আচ্ছা, ঠিক আছে। আর কোনো বিষয় থাকলে জানাবেন।",
                    professional = if (isThanks) "আপনাকেও আন্তরিক ধন্যবাদ।"
                    else "জি ধন্যবাদ, বিষয়টি নোট করে রাখা হলো।",
                    detectedLanguage = "Bangla"
                )
                ScriptStyle.BANGLISH -> ReplyOptions(
                    friendly = if (isThanks) "Areh dhonnobad dewa lagbe na! Sob thik ache."
                    else pickFreshVariation(listOf(
                        "Hmm, tarpor bolo ar ki khobor?",
                        "Accha thik ache! Ar sob kemon cholche?"
                    ), previousOwn),
                    polite = if (isThanks) "Apnakeo onek dhonnobad! Bhalo thakben."
                    else "Ji accha, thik ache. Ar kichu lagle janaben.",
                    professional = if (isThanks) "Apnakeo antorik dhonnobad."
                    else "Ji thik ache, dhonnobad.",
                    detectedLanguage = "Banglish"
                )
                ScriptStyle.ENGLISH -> ReplyOptions(
                    friendly = if (isThanks) "Anytime! Happy to help!"
                    else pickFreshVariation(listOf(
                        "Sounds good! So what else is new with you?",
                        "Cool, got it!"
                    ), previousOwn),
                    polite = if (isThanks) "You're very welcome! Have a wonderful day."
                    else "Alright, sounds good! Let me know if you need anything else.",
                    professional = if (isThanks) "You are most welcome. Please reach out anytime."
                    else "Noted, thank you.",
                    detectedLanguage = "English"
                )
            }
        }

        // 13. DYNAMIC CONTEXTUAL MIRRORING FOR ANY OTHER QUESTION OR STATEMENT
        val isQuestion = lastIncoming.contains("?") || hasAny("keno", "kivabe", "koto", "kon", "ki ", "কেন", "কীভাবে", "কত", "কোন", "কি ", "কী ", "why", "how", "when", "what", "where")

        return when (script) {
            ScriptStyle.BANGLA -> ReplyOptions(
                friendly = pickFreshVariation(listOf(
                    if (isQuestion) {
                        if (pronoun == PronounStyle.TUI) "হ্যাঁ দোস্ত, তোর কথাটা ঠিকই আছে—আমি একটু দেখেই তোকে পুরোটা বলছি!"
                        else "হ্যাঁ, তুমি যেটা জিজ্ঞেস করেছো সেটা আমি একটু কনফার্ম হয়েই তোমাকে বলছি!"
                    } else {
                        if (pronoun == PronounStyle.TUI) "একদম ঠিক বলেছিস দোস্ত! আমিও সেটাই ভাবছিলাম।"
                        else "হ্যাঁ একদম ঠিক বলেছো! তারপর আর কী অবস্থা বলো?"
                    },
                    if (pronoun == PronounStyle.TUI) "বুঝছি দোস্ত, ব্যাপারটা আসলেই তাই। তোর কী মত?"
                    else "বুঝতে পেরেছি তোমার কথাটা। একদম ঠিকই বলেছো!"
                ), previousOwn),
                polite = if (isQuestion) "জি, আপনার প্রশ্নটি বুঝতে পেরেছি। আমি বিষয়টি একটু জেনে আপনাকে সঠিক তথ্যটা জানাচ্ছি।"
                else "জি, আপনি একদম ঠিক বলেছেন। আপনার কথার সাথে আমি একমত।",
                professional = if (isQuestion) "আপনার প্রশ্নের জন্য ধন্যবাদ। আমি বিস্তারিত যাচাই করে দ্রুত আপনাকে জানাচ্ছি।"
                else "বিষয়টি জানানোর জন্য ধন্যবাদ। আমি এটি গুরুত্বের সাথে দেখছি।",
                detectedLanguage = "Bangla"
            )
            ScriptStyle.BANGLISH -> ReplyOptions(
                friendly = pickFreshVariation(listOf(
                    if (isQuestion) {
                        if (pronoun == PronounStyle.TUI) "Haa dosto, tui jeta jiggesh korli oita ami ektu dekhei toke bolchi!"
                        else "Haa, tumi jeta bolla oita ami ektu dekhei tomake confirm korchi!"
                    } else {
                        if (pronoun == PronounStyle.TUI) "Ekdom thik bolsis dosto! Amio oitai vabchilam."
                        else "Haa ekdom thik bolcho bhai! Tarpor ar ki khobor bolo?"
                    },
                    if (pronoun == PronounStyle.TUI) "Bujhchi re, baparta asholei tai. Tor ki mot?"
                    else "Bujhte perechi tomar kothata, ekdom thik bolcho!"
                ), previousOwn),
                polite = if (isQuestion) "Ji, apnar bishoyti bujhte perechi. Ami ektu jenei apnake sothik ta janacchi."
                else "Ji, apni ekdom thik bolechen. Dhonnobad bishoyti bolbar jonno.",
                professional = if (isQuestion) "Apnar proshner jonno dhonnobad. Ami bishoyti dekhe druto apnake update dichhi."
                else "Bishoyti jananor jonno dhonnobad. Ami eti note kore rakhlam.",
                detectedLanguage = "Banglish"
            )
            ScriptStyle.ENGLISH -> ReplyOptions(
                friendly = pickFreshVariation(listOf(
                    if (isQuestion) "Good question! Let me check on that real quick and let you know."
                    else "Totally agree with you on that! How's everything else going?",
                    "Makes complete sense! Thanks for letting me know."
                ), previousOwn),
                polite = if (isQuestion) "That's a great question—let me check the details and get right back to you."
                else "I completely understand, thank you for sharing that with me!",
                professional = if (isQuestion) "Thank you for asking. I will verify the details and get back to you shortly."
                else "Thank you for the update. I have noted this and will follow up accordingly.",
                detectedLanguage = "English"
            )
        }
    }
}
