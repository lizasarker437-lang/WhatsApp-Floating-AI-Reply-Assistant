# SR SmartReply AI ProGuard Rules
-keep class com.srcreationfarm.smartreplyai.model.** { *; }
-keepclassmembers class * extends android.accessibilityservice.AccessibilityService {
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent);
    public void onInterrupt();
}
