# মোবাইল ফোন দিয়ে GitHub থেকে APK তৈরি করার সম্পূর্ণ গাইড

আপনি কম্পিউটার বা Android Studio ছাড়াই মোবাইল ফোনের ব্রাউজার দিয়ে নিচের ধাপগুলো অনুসরণ করে APK তৈরি করতে পারবেন:

### ধাপ ১: GitHub-এ নতুন Repository তৈরি করুন
1. আপনার ফোনের Chrome ব্রাউজারে [github.com](https://github.com) খুলে লগইন করুন।
2. ডান পাশের ওপরের **`+`** আইকনে ট্যাপ করে **New repository** নির্বাচন করুন।
3. Repository name দিন (যেমন: `SR-SmartReply-AI`), **Public** বা **Private** সিলেক্ট করে **Create repository** চাপুন।

### ধাপ ২: ফাইল আপলোড করুন (সবচেয়ে সহজ মোবাইল পদ্ধতি)
1. আপনার নতুন Repository পেজে **uploading an existing file** লিংকে ট্যাপ করুন।
2. প্রথমে ডাউনলোড করা **`SR-SmartReply-AI-Source.zip`** ফাইলটি আপলোড করে **Commit changes** চাপুন।
3. এরপর Repository-তে **Add file > Create new file** চাপুন।
4. ফাইলের নামের ঘরে হুবহু লিখুন: `.github/workflows/build-apk.yml` (স্ল্যাশ `/` লিখলেই ফোল্ডার তৈরি হয়ে যাবে)।
5. ডাউনলোড করা **`build-apk.yml`** ফাইলের সম্পূর্ণ লেখা কপি করে নিচের এডিটরে পেস্ট করুন এবং **Commit changes** চাপুন।

### ধাপ ৩: APK বিল্ড ও ডাউনলোড করুন
1. Commit করার সাথে সাথেই উপরের **Actions** ট্যাবে গিয়ে দেখবেন **Build Android APK (SR SmartReply AI)** চালু হয়েছে।
2. ২-৩ মিনিট পর সবুজ টিক চিহ্ন (✓) আসলে সেটিতে ট্যাপ করুন।
3. নিচে **Artifacts** সেকশন থেকে **`SR-SmartReply-AI-Debug-APK`** ডাউনলোড করে ZIP আনজিপ করলেই আপনার APK পেয়ে যাবেন!

### ধাপ ৪: ফোনে ইনস্টল ও Accessibility চালু করা
1. APK ইনস্টল করার পর **Phone Settings > Apps > SR SmartReply AI** খুলুন।
2. ওপরের ডান কোণায় **তিন ডট (⋮)** মেনুতে ট্যাপ করে **Allow restricted settings** চালু করুন।
3. এরপর **Settings > Accessibility > Downloaded Apps** থেকে **SR SmartReply AI** অন করুন এবং অ্যাপের ভেতর আপনার **Gemini API Key** সেভ করুন।
