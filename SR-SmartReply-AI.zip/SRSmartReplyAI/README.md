# SR SmartReply AI — Floating WhatsApp AI Reply Assistant

**Developer:** Shahriar Rahman  
**Brand:** SR Creation Farm  
**YouTube:** [@SRCreation-farm](https://www.youtube.com/@SRCreation-farm)  
**Facebook:** [SR Creation Farm](https://fb.com/srcreation.farm)  
**Version:** 1.0.0 (`com.srcreationfarm.smartreplyai`)

## Overview
**SR SmartReply AI** is a native Android Accessibility-based floating assistant designed for personal and experimental productivity on WhatsApp and WhatsApp Business. When WhatsApp is open, a draggable floating AI button appears on screen. Tapping it scans visible chat messages directly from the display and generates 3 human-like reply options (**Friendly**, **Polite**, and **Professional**) in **Bangla**, **English**, or **Banglish**.

## Key Features
1. **Draggable Floating AI Orb (`TYPE_ACCESSIBILITY_OVERLAY`):** Appears automatically over WhatsApp (`com.whatsapp`) and WhatsApp Business (`com.whatsapp.w4b`) without requiring separate overlay permissions.
2. **Direct Display Chat Scanner:** Reads visible incoming and outgoing messages directly via `AccessibilityService` (`canRetrieveWindowContent="true"`).
3. **3 Human-Like Reply Styles:** Generates **Friendly**, **Polite**, and **Professional** replies using **Google Gemini 2.5 Flash**, plus an automatic **Offline/Demo Fallback** mode when no API key is configured.
4. **Bangla + English + Banglish Support:** Automatically detects script and language style and replies naturally.
5. **One-Tap Auto-Send or Copy:** Tap any reply card to insert it into WhatsApp's text box and automatically press Send (configurable), or long-press to copy to clipboard.
6. **9 Premium Color Themes + Light/Dark/System Modes:** Midnight Gold, Ocean Blue, Emerald Green, Royal Purple, Sunset Coral, Graphite Cyan, Rose Quartz, Arctic Mint, and Light Day.
7. **Local SQLite Reply History:** Searchable, persistent history with one-tap copy, delete, and clear controls.

## Required Permissions & Setup
- **Accessibility Service (`BIND_ACCESSIBILITY_SERVICE`):** Required to detect when WhatsApp is open, read visible chat bubbles on tap, and insert/send selected replies.
- **Internet (`INTERNET`):** Required to call the Google Gemini API.
- **Android 13+ / MIUI / HyperOS Note:** For sideloaded APKs, open **Phone Settings > Apps > SR SmartReply AI > ⋮ (Top-Right Menu) > Allow restricted settings** before toggling on Accessibility Service.
