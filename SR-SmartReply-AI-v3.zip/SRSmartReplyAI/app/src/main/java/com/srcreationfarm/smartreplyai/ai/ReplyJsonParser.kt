package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import org.json.JSONObject
import kotlin.math.abs

object ReplyJsonParser {

    enum class PronounStyle { TUI, TUMI, APNI }
    enum class ScriptStyle { BANGLA, BANGLISH, ENGLISH }
    enum class ConversationTopic {
        NONE, FOOD, ACTIVITY_WORK, LOCATION, WELLBEING, SLEEP, FAMILY, CALL, PLAN_MEET, HEALTH, WEATHER, STUDY
    }

    data class ThreadContext(
        val windowMessages: List<ChatMessage>,
        val priorMessages: List<ChatMessage>,
        val lastIncomingMessage: String,
        val scriptStyle: ScriptStyle,
        val pronounStyle: PronounStyle,
        val previousTopic: ConversationTopic,
        val previousOwnReplies: Set<String>
    )

    fun parseAiReply(rawText: String): String {
        val cleaned = rawText
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()

        val startBrace = cleaned.indexOf('{')
        val endBrace = cleaned.lastIndexOf('}')
        if (startBrace != -1 && endBrace > startBrace) {
            try {
                val obj = JSONObject(cleaned.substring(startBrace, endBrace + 1))
                for (key in listOf("reply", "message", "response", "text", "friendly", "polite", "professional")) {
                    val v = obj.optString(key, "").trim()
                    if (v.isNotEmpty()) return v
                }
            } catch (_: Exception) {
            }
        }
        return cleaned.trim { it == '"' || it.isWhitespace() }.lines().firstOrNull { it.isNotBlank() }?.trim() ?: ""
    }

    fun detectScriptStyle(text: String): ScriptStyle? {
        if (text.isBlank()) return null
        val hasBanglaScript = text.any { it in '\u0980'..'\u09FF' }
        if (hasBanglaScript) return ScriptStyle.BANGLA

        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\s]"), " ") + " "
        val banglishMarkers = listOf(
            " ki ", " kemon ", " kmn ", " kothay ", " koi ", " bhai ", " vai ", " vaia ", " dosto ",
            " ache ", " achi ", " aci ", " acho ", " achen ", " achis ", " korcho ", " koro ", " koros ",
            " koren ", " korteso ", " khaico ", " khaisos ", " khaiso ", " kheyechen ", " khawa ",
            " bhalo ", " valo ", " tumi ", " tmi ", " tui ", " apni ", " amar ", " tomar ", " tor ", " apnar ",
            " haa ", " na ", " nai ", " naki ", " keno ", " kn ", " kobe ", " kokhon ", " kiser ",
            " basay ", " bashay ", " ghum ", " kaj ", " kaje ", " aso ", " asbo ", " jabo ", " jabi ",
            " jaba ", " bol ", " bolo ", " bolen ", " bolteco ", " bolcho ", " bujho ", " janabe ", " korba ",
            " accha ", " acha ", " aito ", " eito ", " hlw ", " salam ", " assalamu ", " kono ", " sob ",
            " dhonnobad ", " khobor ", " obostha ", " ektu ", " ekhon ", " ar ", " tarpor ", " sotti ",
            " brishti ", " gorom ", " shorir ", " jor ", " matha ", " pora ", " exam ", " class ", " taka "
        )
        if (banglishMarkers.any { lower.contains(it) }) {
            return ScriptStyle.BANGLISH
        }
        return null
    }

    fun detectPronounStyle(text: String): PronounStyle? {
        val lower = " " + text.lowercase().replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "
        val tuiMarkers = listOf(
            " tui ", " tor ", " toke ", " koros ", " koris ", " khaisos ", " khaisis ", " achis ",
            " asis ", " jabi ", " bolis ", " dosto ", " mama ", " শালা ", " তুই ", " তোর ", " তোকে ",
            " করিস ", " খাইছিস ", " আছিস ", " যাবি ", " দোস্ত "
        )
        if (tuiMarkers.any { lower.contains(it) }) return PronounStyle.TUI

        val apniMarkers = listOf(
            " apni ", " apnar ", " apnake ", " koren ", " korchen ", " kheyechen ", " achen ",
            " jaben ", " asben ", " bolun ", " bolen ", " sir ", " ভাইয়া ", " আপু ", " আপনি ", " আপনার ",
            " আপনাকে ", " করেন ", " করছেন ", " খেয়েছেন ", " আছেন ", " যাবেন ", " আসবেন ", " বলুন ", " স্যার "
        )
        if (apniMarkers.any { lower.contains(it) }) return PronounStyle.APNI

        val tumiMarkers = listOf(
            " tumi ", " tmi ", " tomar ", " tomake ", " koro ", " korcho ", " korba ", " bolteco ", " bujho ",
            " khaico ", " khaiso ", " acho ", " jaba ", " asba ", " bolo ", " তুমি ", " তোমার ", " তোমাকে ",
            " করো ", " করছো ", " খাইছো ", " আছো "
        )
        if (tumiMarkers.any { lower.contains(it) }) return PronounStyle.TUMI

        return null
    }

    fun detectTopicFromText(text: String): ConversationTopic {
        val lower = text.lowercase()
        return when {
            listOf("khaic", "khais", "kheyec", "khawa", "vat", "mangsho", "nasta", "খাইছ", "খেয়েছ", "খাওয়া", "ভাত", "নাস্তা", "eat", "food", "lunch", "dinner").any { lower.contains(it) } ->
                ConversationTopic.FOOD
            listOf("ki koro", "ki koros", "ki korc", "kaj", "basto", "busy", "কী কর", "কি কর", "কাজ", "ব্যস্ত", "working", "doing").any { lower.contains(it) } ->
                ConversationTopic.ACTIVITY_WORK
            listOf("koi", "kothay", "basay", "bashay", "কই", "কোথায়", "বাসায়", "where").any { lower.contains(it) } ->
                ConversationTopic.LOCATION
            listOf("ghum", "ratri", "night", "ঘুম", "রাত্রি", "sleep").any { lower.contains(it) } ->
                ConversationTopic.SLEEP
            listOf("basar sobai", "bhabhi", "babu", "ammu", "abbu", "বাসার সবাই", "ভাবি", "বাবু", "family").any { lower.contains(it) } ->
                ConversationTopic.FAMILY
            listOf("call", "phone", "কল", "ফোন").any { lower.contains(it) } ->
                ConversationTopic.CALL
            listOf("kobe", "kokhon", "dekha", "asba", "jaba", "কবে", "কখন", "দেখা", "আসবা", "যাবা", "meet").any { lower.contains(it) } ->
                ConversationTopic.PLAN_MEET
            listOf("shorir", "jor", "matha", "oshustho", "শরীর", "জ্বর", "মাথা", "অসুস্থ", "sick", "fever").any { lower.contains(it) } ->
                ConversationTopic.HEALTH
            listOf("brishti", "gorom", "thanda", "weather", "বৃষ্টি", "গরম", "ঠান্ডা").any { lower.contains(it) } ->
                ConversationTopic.WEATHER
            listOf("pora", "exam", "class", "college", "পড়া", "পরীক্ষা", "ক্লাস").any { lower.contains(it) } ->
                ConversationTopic.STUDY
            listOf("kemon", "kmn", "khobor", "obostha", "bhalo", "aito", "eito", "কেমন", "খবর", "অবস্থা", "ভালো").any { lower.contains(it) } ->
                ConversationTopic.WELLBEING
            else -> ConversationTopic.NONE
        }
    }

    fun analyzeConversationThread(
        messages: List<ChatMessage>,
        extraExcludedReplies: Set<String> = emptySet()
    ): ThreadContext {
        val window = messages.takeLast(5)
        val lastIncomingMsg = window.lastOrNull { it.sender == "Incoming" }?.text?.trim()
            ?: window.lastOrNull()?.text?.trim()
            ?: ""

        val prior = if (window.size > 1) window.dropLast(1) else emptyList()
        val prevOwn = HashSet<String>().apply {
            addAll(extraExcludedReplies)
            window.filter { it.sender == "Me" }.forEach { add(it.text.trim()) }
        }

        var script = detectScriptStyle(lastIncomingMsg)
        if (script == null) {
            for (m in prior.reversed()) {
                val s = detectScriptStyle(m.text)
                if (s != null) {
                    script = s
                    break
                }
            }
        }
        val finalScript = script ?: ScriptStyle.BANGLISH

        var pronoun = detectPronounStyle(lastIncomingMsg)
        if (pronoun == null) {
            for (m in prior.reversed()) {
                val p = detectPronounStyle(m.text)
                if (p != null) {
                    pronoun = p
                    break
                }
            }
        }
        val finalPronoun = pronoun ?: PronounStyle.TUMI

        var ongoingTopic = ConversationTopic.NONE
        for (m in prior.reversed()) {
            val t = detectTopicFromText(m.text)
            if (t != ConversationTopic.NONE) {
                ongoingTopic = t
                break
            }
        }

        return ThreadContext(
            windowMessages = window,
            priorMessages = prior,
            lastIncomingMessage = lastIncomingMsg,
            scriptStyle = finalScript,
            pronounStyle = finalPronoun,
            previousTopic = ongoingTopic,
            previousOwnReplies = prevOwn
        )
    }

    private fun pickUniqueReply(
        candidates: List<String>,
        previousOwnReplies: Set<String>,
        seedText: String
    ): String {
        val lowerExcluded = previousOwnReplies.map { it.trim().lowercase() }.toSet()
        val fresh = candidates.filter { it.trim().lowercase() !in lowerExcluded }
        if (fresh.isNotEmpty()) {
            val idx = abs(seedText.hashCode() + previousOwnReplies.size * 7) % fresh.size
            return fresh[idx]
        }
        val base = candidates[abs(seedText.hashCode()) % candidates.size]
        val suffixes = listOf(" বলো!", " তা তোমার কী খবর?", " আর কী অবস্থা?", "!")
        for (s in suffixes) {
            val modified = base.trimEnd('.', '!', '?') + s
            if (modified.lowercase() !in lowerExcluded) return modified
        }
        return base
    }

    /**
     * Generates a single, realistic, context-adaptive reply based purely on the incoming SMS
     * and the last 4-5 messages of conversation context (no Friendly/Polite/Pro divisions).
     */
    fun buildSmartContextualReply(
        messages: List<ChatMessage>,
        extraExcludedReplies: Set<String> = emptySet()
    ): ReplyOptions {
        val ctx = analyzeConversationThread(messages, extraExcludedReplies)
        val lastIncoming = ctx.lastIncomingMessage
        val script = ctx.scriptStyle
        val pronoun = ctx.pronounStyle
        val prevTopic = ctx.previousTopic
        val previousOwn = ctx.previousOwnReplies

        val lower = lastIncoming.lowercase().trim()
        val padded = " " + lower.replace(Regex("[^a-z0-9\\u0980-\\u09FF\\s]"), " ") + " "
        val normalizedShort = padded.trim().replace(Regex("\\s+"), " ")

        fun hasAny(vararg words: String): Boolean {
            return words.any { w ->
                if (w.startsWith(" ") || w.endsWith(" ")) padded.contains(w)
                else lower.contains(w)
            }
        }

        // 1. Reciprocal short follow-ups ("tumi?", "tui?", "apni?", "Haa. Tumi?", "তুমি?", "তুই?")
        if (normalizedShort in listOf(
                "tumi", "ar tumi", "tui", "ar tui", "apni", "ar apni",
                "haa tumi", "haa tui", "ha tumi", "ha tui", "ji apni", "haa apni",
                "তুমি", "আর তুমি", "তুই", "আর তুই", "আপনি", "আর আপনি",
                "হ্যাঁ তুমি", "হ্যাঁ তুই", "জি আপনি", "হ্যাঁ আপনি", "you", "and you"
            )
        ) {
            val replyText = when (prevTopic) {
                ConversationTopic.FOOD -> when (script) {
                    ScriptStyle.BANGLA -> when (pronoun) {
                        PronounStyle.TUI -> pickUniqueReply(listOf("হ্যাঁ দোস্ত, আমিও একটু আগেই ভাত খেয়ে নিলাম!", "হ্যাঁ রে, আমারও খাওয়া শেষ!"), previousOwn, lastIncoming)
                        PronounStyle.APNI -> "জি আলহামদুলিল্লাহ, আমিও কিছুক্ষণ আগে খেয়ে নিয়েছি।"
                        PronounStyle.TUMI -> pickUniqueReply(listOf("হ্যাঁ, আমিও একটু আগেই খাওয়া শেষ করলাম আলহামদুলিল্লাহ!", "হ্যাঁ আমারও খাওয়া শেষ! এখন একটু বিশ্রাম নিচ্ছি।"), previousOwn, lastIncoming)
                    }
                    ScriptStyle.BANGLISH -> when (pronoun) {
                        PronounStyle.TUI -> pickUniqueReply(listOf("Haa dosto, amio ektu agei kheye nilam!", "Haa re, amaro khawa shesh!"), previousOwn, lastIncoming)
                        PronounStyle.APNI -> "Ji Alhamdulillah, amio kichukhon age kheye niyechi."
                        PronounStyle.TUMI -> pickUniqueReply(listOf("Haa, amio ektu agei khawa shesh korlam Alhamdulillah!", "Haa amaro khawa shesh! Ekhon ektu bose achi."), previousOwn, lastIncoming)
                    }
                    ScriptStyle.ENGLISH -> "Yep, I already ate a little while ago too!"
                }
                ConversationTopic.ACTIVITY_WORK -> when (script) {
                    ScriptStyle.BANGLA -> when (pronoun) {
                        PronounStyle.TUI -> "আমিও এইতো বাসায় বসে একটু ফোন দেখছি রে!"
                        PronounStyle.APNI -> "জি, আমিও বাসায় বসে টুকটাক কাজ করছি।"
                        PronounStyle.TUMI -> "আমিও এইতো বাসায় বসে একটু বিশ্রাম নিচ্ছি!"
                    }
                    else -> when (pronoun) {
                        PronounStyle.TUI -> "Amio eito basay bose ektu rest nicchi re!"
                        PronounStyle.APNI -> "Ji, amio basay bose ektu kaj korchi."
                        PronounStyle.TUMI -> "Amio eito basay bose ektu rest nicchi!"
                    }
                }
                else -> when (script) {
                    ScriptStyle.BANGLA -> if (pronoun == PronounStyle.APNI) "জি আলহামদুলিল্লাহ, আপনার দোয়ায় আমিও ভালো আছি।" else "আলহামদুলিল্লাহ আমিও বেশ ভালো আছি!"
                    else -> if (pronoun == PronounStyle.APNI) "Ji Alhamdulillah, amio bhalo achi." else "Alhamdulillah amio bhalo achi!"
                }
            }
            return ReplyOptions(replyText, "Context: ${prevTopic.name}")
        }

        // 2. Follow-up "Na / এখনো না" when previous messages were about Food
        if (normalizedShort in listOf("na", "nah", "na re", "na bhai", "na dosto", "ekhono na", "khai nai", "না", "নাহ", "এখনো না", "খাই নি", "খাইনি", "not yet", "no")) {
            if (prevTopic == ConversationTopic.FOOD || hasAny("khai")) {
                val replyText = when (script) {
                    ScriptStyle.BANGLA -> when (pronoun) {
                        PronounStyle.TUI -> "আরে এখনো খাসনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নে দোস্ত!"
                        PronounStyle.APNI -> "ওহ আচ্ছা, দেরি না করে সময়মতো খাবারটা খেয়ে নিন।"
                        PronounStyle.TUMI -> "আরে এখনো খাওনি কেন? দেরি না করে তাড়াতাড়ি খেয়ে নাও!"
                    }
                    ScriptStyle.BANGLISH -> when (pronoun) {
                        PronounStyle.TUI -> "Areh ekhono khas nai keno? Deri na kore taratari kheye ne dosto!"
                        PronounStyle.APNI -> "Oh accha, deri na kore somoymoto khabar ta kheye nin."
                        PronounStyle.TUMI -> "Areh ekhono khao nai keno? Deri na kore taratari kheye nao!"
                    }
                    ScriptStyle.ENGLISH -> "Oh, how come you haven't eaten yet? Go grab something to eat soon!"
                }
                return ReplyOptions(replyText, "Context: Food")
            }
        }

        // 3. Clarification / Confusion / Teasing ("tmi ki kotha bujho na", "ki sob bolteco", "ki confirm korba", "ki janabe")
        if (hasAny("kotha bujho", "kotha bujhis", "ki sob bol", "ki boltec", "ki bolcho", "ki bolis", "ki confirm", "ki janab", "mane ki", "pagol naki", "কথা বুঝো", "কী সব বল", "কি সব বল", "কী বলছ", "কি বলছ", "কী জানাব", "কী কনফার্ম", "মানে কী")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "আরে না দোস্ত, ফোনে অন্য একটা কাজ করছিলাম তো তাই খেয়াল করিনি! এবার বল কী বলছিলি?",
                        "হাহা সরি দোস্ত, তাড়াহুড়োয় ভুল মেসেজ চলে গেছে! বল কী খবর তোর?"
                    ), previousOwn, lastIncoming)
                    PronounStyle.APNI -> "দুঃখিত, আমি একটু অন্য কাজে ব্যস্ত থাকায় ঠিকমতো খেয়াল করতে পারিনি। অনুগ্রহ করে আবার বলবেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "আরে না, আসলে অন্য একটা কাজে একটু অন্যমনস্ক ছিলাম! বলো কী বলছিলে?",
                        "হাহা সরি! তাড়াহুড়োয় উল্টাপাল্টা টাইপ হয়ে গেছে। বলো কী অবস্থা তোমার?",
                        "আরে বুঝতে পেরেছি! একটু ব্যস্ত ছিলাম তো তাই ঠিকমতো লেখার সময় পাইনি।"
                    ), previousOwn, lastIncoming)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "Areh na dosto, phone e onno ekta kaj korchilam tai kheyal kori nai! Ebar bol ki bolchili?",
                        "Haha sorry dosto, tarahuroy ulta-palta type hoye gese! Bol ki obostha tor?"
                    ), previousOwn, lastIncoming)
                    PronounStyle.APNI -> "Dukkhito, ami ektu onno kaje basto thakay thikmoto kheyal korte pari nai. Abar bolben?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "Areh na, ashole onno ekta kaje ektu busy chilam tai kheyal kori nai! Bolo ki bolchile?",
                        "Haha sorry bhai, tarahuroy ulta-palta type hoye gese! Ekhon bolo ki obostha?",
                        "Areh bujhchi to! Ektu kaje atke chilam tai thikmoto likhte pari nai, bolo ebar!",
                        "Haha na re bhai, matha ektu onno dike chilo! Bolo ki khobor tomar?"
                    ), previousOwn, lastIncoming)
                }
                ScriptStyle.ENGLISH -> "Haha my bad! I was distracted doing something else on my phone. What were you saying?"
            }
            return ReplyOptions(replyText, "Clarification")
        }

        // 4. Casual Status Updates ("aito aci", "eito achi", "kono khobor nai", "temon kichu na")
        if (hasAny("aito ac", "eito ach", "eito ac", "aito ach", "kono khobor nai", "khobor nai", "temon kichu na", "cholche", "এইতো আছি", "কোনো খবর নাই", "তেমন কিছু না", "চলছে আরকি")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "যাক ভালো থাকলেই হলো দোস্ত! আজকে সারাদিন কী করলি?",
                        "আমাদেরও একই অবস্থা রে দোস্ত! এখন কই আছিস?"
                    ), previousOwn, lastIncoming)
                    PronounStyle.APNI -> "আলহামদুলিল্লাহ, ভালো থাকলেই ভালো। আপনার বাসার সবাই কেমন আছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "যাক আলহামদুলিল্লাহ! আজকে সারাদিন কী করলে বলো?",
                        "এইতো, আমাদেরও একই অবস্থা—দিনকাল একরকম চলে যাচ্ছে আরকি!",
                        "ভালো থাকলেই ভালো! বাসার সবার কী অবস্থা?"
                    ), previousOwn, lastIncoming)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf(
                        "Jak bhalo thaklei holo dosto! Ajke saradin ki korli bol?",
                        "Amaro eki obostha re dosto! Ekhon ki basay naki baire?"
                    ), previousOwn, lastIncoming)
                    PronounStyle.APNI -> "Alhamdulillah, bhalo thaklei bhalo. Apnar basar sobai kemon achen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf(
                        "Jak Alhamdulillah! Ajke saradin ki korla bolo?",
                        "Amaro eki obostha bhai, eirom e cholche dinkal! Basar sobai bhalo to?",
                        "Bhalo thaklei holo! Ekhon ki basay bose acho naki baire?",
                        "Hmm bujhlam! Cha-nasta khaico naki ekhono?"
                    ), previousOwn, lastIncoming)
                }
                ScriptStyle.ENGLISH -> "Glad to hear you're doing alright! What have you been up to today?"
            }
            return ReplyOptions(replyText, "Status Update")
        }

        // 5. Single-word "Ki" / "Ki?" / "কী?"
        if (normalizedShort in listOf("ki", "kii", "ki re", "ki bhai", "কী", "কি", "কী রে", "কি ভাই", "what")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "কিছু না দোস্ত, এমনিই জিজ্ঞেস করলাম তোর কী অবস্থা!"
                    else "তেমন কিছু না, এমনিই খোঁজ নিচ্ছিলাম তোমার কী খবর!",
                    "বলছিলাম যে আজকে কী করছো এখন?"
                ), previousOwn, lastIncoming)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "Kichu na dosto, emnii khoj nicchilam tor ki obostha!"
                    else "Temon kichu na, emnii jiggesh korchilam tomar ki khobor!",
                    "Bolchilam je ekhon ki korcho basay bose?",
                    "Emnii bhai, dekhlam online acho tai knock dilam!"
                ), previousOwn, lastIncoming)
                ScriptStyle.ENGLISH -> "Nothing much, just checking in to see how you're doing!"
            }
            return ReplyOptions(replyText, "Follow-up")
        }

        // 6. Follow-up "Kiser kaj? / Ki kaj?"
        if (hasAny("kiser", "ki kaj", "কিসের", "কী কাজ", "কি কাজ") || (prevTopic == ConversationTopic.ACTIVITY_WORK && hasAny("ki ", "keno", "কী ", "কেন"))) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "এইতো নিজের একটা প্রজেক্ট আর বাসার টুকটাক কাজ করছি রে। একটু পরই ফ্রি হবো!"
                    else "এইতো নিজের একটু জরুরি কাজ আর ফোনের কিছু সেটআপ করছিলাম। অল্প কিছুক্ষণের মধ্যেই শেষ হয়ে যাবে!",
                    "বাসার কিছু দরকারি কাজ সেরে নিচ্ছিলাম, প্রায় শেষের দিকেই!"
                ), previousOwn, lastIncoming)
                else -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "Eito nijer ekta project ar basar tukitaki kaj korchi re. Ektu porei free hobo!"
                    else "Eito nijer ektu dorkari kaj korchilam. Olpo kichukhoner moddhei shesh hoye jabe!",
                    "Phone e ekta app setup ar basar kichu kaj korchilam, pray shesh!"
                ), previousOwn, lastIncoming)
            }
            return ReplyOptions(replyText, "Work Details")
        }

        // 7. SALAM / ISLAMIC GREETING
        if (hasAny("salam", "assalamu", "slm", "সালাম", "আসসালামু")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> "ওয়ালাইকুম আসসালাম দোস্ত! কী খবর তোর?"
                    PronounStyle.APNI -> "ওয়ালাইকুম আসসালাম ওয়া রাহমাতুল্লাহ। আলহামদুলিল্লাহ ভালো আছি, আপনি কেমন আছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("ওয়ালাইকুম আসসালাম! কেমন আছো বলো?", "ওয়ালাইকুম আসসালাম ভাই! সব কেমন চলছে?"), previousOwn, lastIncoming)
                }
                else -> when (pronoun) {
                    PronounStyle.TUI -> "Walaikum Assalam dosto! Tor ki khobor bol?"
                    PronounStyle.APNI -> "Walaikum Assalam Wa Rahmatullah. Alhamdulillah bhalo achi, apni kemon achen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Walaikum Assalam! Kemon acho bolo?", "Walaikum Assalam bhai! Ki obostha tomar?"), previousOwn, lastIncoming)
                }
            }
            return ReplyOptions(replyText, "Greeting")
        }

        // 8. WHAT DID YOU EAT / MENU
        if (hasAny("ki diye", "ki khaila", "ki khaiso", "ki ranna", "কী দিয়ে", "কি দিয়ে", "কী খাইছ", "কি খাইছ", "কী রান্না")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("ভাত আর মাংস দিয়ে খাইলাম রে। তুই কী দিয়ে খাইলি?", "আজকে ভাত, ডাল আর ভাজি দিয়ে খেয়েছি। তোর কী মেনু ছিল?"), previousOwn, lastIncoming)
                    PronounStyle.APNI -> "জি, ভাত ও মাছ দিয়ে খেয়েছি আলহামদুলিল্লাহ। আপনি কী দিয়ে খেয়েছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("ভাত আর মুরগির মাংস দিয়ে খাইলাম। তুমি কী দিয়ে খাইছো?", "আজকে ভাত, ডাল আর ভাজি দিয়ে খেয়েছি। তোমার কী মেনু ছিল?"), previousOwn, lastIncoming)
                }
                else -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("Vat ar mangsho diye khailam re. Tui ki diye khaili?", "Ajke vat, dal ar vaji diye kheyechi. Tor ki menu chilo?"), previousOwn, lastIncoming)
                    PronounStyle.APNI -> "Ji, vat ar mach diye kheyechi Alhamdulillah. Apni ki diye kheyechen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Vat ar murgir mangsho diye khailam. Tumi ki diye khaico?", "Ajke vat, dal ar vaji diye kheyechi. Tomar ki menu chilo?"), previousOwn, lastIncoming)
                }
            }
            return ReplyOptions(replyText, "Meal Menu")
        }

        // 9. HAVE YOU EATEN / MEAL INQUIRY
        if (hasAny("khaic", "khais", "kheyec", "khawa", "khail", "nasta", "lunch", "dinner", "খাইছ", "খেয়েছ", "খাওয়া", "নাস্তা")) {
            val isNasta = hasAny("nasta", "cha ", "নাস্তা", "চা ")
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("হ্যাঁ দোস্ত, একটু আগেই খাইলাম। তুই খাইছিস?", "এইতো কেবল খাওয়া শেষ করলাম। তোর খাওয়া হইছে?"), previousOwn, lastIncoming)
                    PronounStyle.APNI -> if (isNasta) "জি আলহামদুলিল্লাহ, নাস্তা করেছি। আপনি নাস্তা করেছেন?" else "জি আলহামদুলিল্লাহ, আমার খাওয়া হয়েছে। আপনি খেয়েছেন?"
                    PronounStyle.TUMI -> if (isNasta) "হ্যাঁ, চা-নাস্তা একটু আগেই শেষ করলাম। তুমি নাস্তা করছো?" else pickUniqueReply(listOf("হ্যাঁ, আলহামদুলিল্লাহ একটু আগেই খাইলাম। তুমি খাইছো?", "এইতো কিছুক্ষণ আগে খাওয়া শেষ করলাম। তোমার খাওয়া দাওয়া হইছে?"), previousOwn, lastIncoming)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("Haa dosto, ektu agei khailam. Tui khaisos?", "Eito kebol khawa shesh korlam. Tor khawa hoise?"), previousOwn, lastIncoming)
                    PronounStyle.APNI -> if (isNasta) "Ji Alhamdulillah, nasta korechi. Apni nasta korechen?" else "Ji Alhamdulillah, amar khawa hoyeche. Apni kheyechen?"
                    PronounStyle.TUMI -> if (isNasta) "Haa, cha-nasta ektu agei korlam. Tumi nasta korcho?" else pickUniqueReply(listOf("Haa, ektu agei khailam Alhamdulillah. Tumi khaico?", "Eito kichukhon age khawa shesh korlam. Tomar khawa hoise?"), previousOwn, lastIncoming)
                }
                ScriptStyle.ENGLISH -> "Yeah, just finished eating a little while ago! Did you eat?"
            }
            return ReplyOptions(replyText, "Food")
        }

        // 10. WHAT ARE YOU DOING
        if (hasAny("ki koro", "ki koros", "ki korc", "ki kortes", "ki koris", "কী কর", "কি কর", "what are you doing", "wyd", "whatcha doing")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("এইতো দোস্ত, বাসায় বসে ফোন চাপছি। তুই কী করিস?", "তেমন কিছু না রে, একটু বিশ্রাম নিচ্ছি। তোর কী অবস্থা?"), previousOwn, lastIncoming)
                    PronounStyle.APNI -> "জি, এইতো বাসায় একটু কাজ করছিলাম। আপনি কী করছেন এখন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("এইতো বাসায় বসে আছি, একটু ফোন দেখছিলাম। তুমি কী করছো?", "এইতো একটু বিশ্রাম নিচ্ছি। তোমার খবর কী বলো?", "বাসায় বসে একটু ইউটিউব দেখছিলাম। তুমি কী করছো এখন?"), previousOwn, lastIncoming)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> pickUniqueReply(listOf("Eito dosto, basay bose phone chapchi. Tui ki koros?", "Temon kichu na re, ektu kaj korchilam. Tor ki khobor?"), previousOwn, lastIncoming)
                    PronounStyle.APNI -> "Ji, eito basay ektu kaj korchilam. Apni ki korchen ekhon?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Eito basay bose achi, ektu rest nicchi. Tumi ki korcho?", "Eito ektu hater kaj sarchilam. Tomar ki obostha bolo?", "Basay bose ektu phone dekhchilam. Tumi ki korteso ekhon?"), previousOwn, lastIncoming)
                }
                ScriptStyle.ENGLISH -> "Just chilling at home and checking my phone. What are you up to?"
            }
            return ReplyOptions(replyText, "Activity")
        }

        // 11. WHERE ARE YOU
        if (hasAny(" koi ", "koi?", "kothay", "basay naki", "bashay naki", "কই", "কোথায়", "বাসায় নাকি", "where are you", "wya") || lower == "koi") {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> "আমি এখন বাসাতেই আছি রে। তুই কই?"
                    PronounStyle.APNI -> "জি, আমি এখন বাসায় আছি। আপনি কোথায় আছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("আমি এখন বাসাতেই আছি। তুমি কোথায়?", "এইতো বাসায় আছি। তুমি কোথায় আছো এখন?"), previousOwn, lastIncoming)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> "Ami ekhon basatei achi re. Tui koi?"
                    PronounStyle.APNI -> "Ji, ami ekhon basay achi. Apni kothay achen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Ami ekhon basay achi. Tumi kothay?", "Eito basay achi bhai. Tumi koi acho ekhon?"), previousOwn, lastIncoming)
                }
                ScriptStyle.ENGLISH -> "I'm at home right now. Where are you?"
            }
            return ReplyOptions(replyText, "Location")
        }

        // 12. HOW ARE YOU / WHAT'S UP
        if (hasAny("kemon", "kmn", "ki khobor", "ki obostha", "কেমন", "কী খবর", "কি খবর", "কী অবস্থা", "কি অবস্থা", "how are you", "how r u", "what's up", "whats up")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> when (pronoun) {
                    PronounStyle.TUI -> "আলহামদুলিল্লাহ ভালো আছি দোস্ত! তোর কী খবর বল?"
                    PronounStyle.APNI -> "জি আলহামদুলিল্লাহ, আপনার দোয়ায় ভালো আছি। আপনি কেমন আছেন?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("আলহামদুলিল্লাহ বেশ ভালো আছি! তোমার কী খবর বলো?", "এইতো আলহামদুলিল্লাহ সব ভালো চলছে। তোমার দিনকাল কেমন যাচ্ছে?"), previousOwn, lastIncoming)
                }
                ScriptStyle.BANGLISH -> when (pronoun) {
                    PronounStyle.TUI -> "Alhamdulillah bhalo achi dosto! Tor ki khobor bol?"
                    PronounStyle.APNI -> "Ji Alhamdulillah, bhalo achi. Apni kemon achen?"
                    PronounStyle.TUMI -> pickUniqueReply(listOf("Alhamdulillah bhalo achi! Tomar ki khobor bolo?", "Eito Alhamdulillah sob bhalo cholche. Tomar dinkal kemon jacche?", "Alhamdulillah bhalo! Ajke ki korcho saradin?"), previousOwn, lastIncoming)
                }
                ScriptStyle.ENGLISH -> "Doing great, Alhamdulillah! How's everything going with you?"
            }
            return ReplyOptions(replyText, "Wellbeing")
        }

        // 13. SLEEP / NIGHT / MORNING
        if (hasAny("ghum", "good night", "gn ", "good morning", "gm ", "ঘুম", "শুভ রাত্রি", "শুভ সকাল", "sleep")) {
            val isMorning = hasAny("morning", "gm ", "সকাল")
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (isMorning) "শুভ সকাল! ঘুম থেকে উঠলে কখন?"
                else if (pronoun == PronounStyle.TUI) "এইতো একটু পরেই ঘুমাবো রে। তুই ঘুমাবি না?"
                else if (pronoun == PronounStyle.APNI) "জি, কিছুক্ষণের মধ্যেই ঘুমিয়ে পড়বো। শুভ রাত্রি, ভালো থাকবেন।"
                else "এইতো আর কিছুক্ষণ পরই ঘুমিয়ে পড়বো। তুমি ঘুমাওনি এখনো?"
                ScriptStyle.BANGLISH -> if (isMorning) "Good morning! Ghum theke uthla kokhon?"
                else if (pronoun == PronounStyle.TUI) "Eito ektu porei ghumabo re. Tui ghumabi na?"
                else if (pronoun == PronounStyle.APNI) "Ji, ektu porei ghumiye porbo. Shuvo ratri, bhalo thakben."
                else "Eito ektu porei ghumabo. Tumi ghumao nai ekhono?"
                ScriptStyle.ENGLISH -> if (isMorning) "Good morning! Hope you have an awesome day!" else "Heading to bed pretty soon! Aren't you sleeping yet?"
            }
            return ReplyOptions(replyText, "Sleep/Greeting")
        }

        // 14. FAMILY / HOME WELL-BEING
        if (hasAny("basar sobai", "bashar sobai", "bhabhi", "vabi", "babu", "ammu", "abbu", "family", "বাসার সবাই", "ভাবি", "বাবু", "আম্মু", "আব্বু")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (pronoun == PronounStyle.APNI) "জি আলহামদুলিল্লাহ, দোয়ায় বাসার সবাই ভালো আছে। আপনার পরিবারের সবাই কেমন আছেন?" else "আলহামদুলিল্লাহ, বাসার সবাই ভালো আছে। তোমাদের বাসার সবাই কেমন আছে?"
                else -> if (pronoun == PronounStyle.APNI) "Ji Alhamdulillah, basar sobai bhalo ache. Apnar poribarer sobai kemon achen?" else "Alhamdulillah, basar sobai bhalo ache! Tomader basar sobai kemon ache?"
            }
            return ReplyOptions(replyText, "Family")
        }

        // 15. HEALTH / SICKNESS ("shorir kharap", "jor", "matha batha", "শরীর খারাপ", "জ্বর", "মাথা ব্যথা")
        if (hasAny("shorir", "jor", "matha", "oshustho", "batha", "শরীর", "জ্বর", "মাথা", "অসুস্থ", "ব্যথা", "sick", "fever", "headache")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (pronoun == PronounStyle.TUI) "আরে কী বলিস! ওষুধ খাইছিস ঠিকমতো? একটু বিশ্রাম নে দোস্ত।" else "ওহ, এখন শরীর কেমন লাগছে? ঠিকমতো ওষুধ খেয়ে বিশ্রাম নাও।"
                ScriptStyle.BANGLISH -> if (pronoun == PronounStyle.TUI) "Areh ki bolis! Oshudh khaisos thikmoto? Ektu rest ne dosto." else "Oh, ekhon shorir kemon lagche? Thikmoto oshudh kheye rest nao."
                ScriptStyle.ENGLISH -> "Oh no, hope you feel better soon! Make sure to get some rest."
            }
            return ReplyOptions(replyText, "Health")
        }

        // 16. WEATHER / RAIN / HEAT ("brishti", "gorom", "thanda", "বৃষ্টি", "গরম", "ঠান্ডা")
        if (hasAny("brishti", "gorom", "thanda", "weather", "বৃষ্টি", "গরম", "ঠান্ডা", "রোদ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "হ্যাঁ, আজকের আবহাওয়াটা আসলেই অন্যরকম! তোমাদের ওদিকে কী অবস্থা?"
                ScriptStyle.BANGLISH -> "Haa, ajker weather ta asholei onnorokom! Tomader odike ki obostha?"
                ScriptStyle.ENGLISH -> "Yeah, the weather is really something today! How is it over there?"
            }
            return ReplyOptions(replyText, "Weather")
        }

        // 17. CALL / PHONE
        if (hasAny("call", "phone", "কল", "ফোন")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (pronoun == PronounStyle.APNI) "জি, আমি এখন কথা বলতে পারবো। আপনি চাইলে কল দিতে পারেন।" else "হ্যাঁ এখন ফ্রি আছি, কল দিতে পারো!"
                else -> if (pronoun == PronounStyle.APNI) "Ji, ami ekhon free achi. Apni chaile call dite paren." else "Haa ekhon free achi, call dite paro!"
            }
            return ReplyOptions(replyText, "Call")
        }

        // 18. BUSY / FREE / MEETING / WHEN
        if (hasAny("free", "busy", "basto", "kobe", "kokhon", "dekha", "asba", "asbi", "jaba", "jabi", "ফ্রি", "ব্যস্ত", "কবে", "কখন", "দেখা", "আসবা", "যাবা")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "আমি এখন ফ্রি আছি দোস্ত, বল কী প্ল্যান?"
                    else "আমি এখন মোটামুটি ফ্রি আছি, বলো কী প্ল্যান?",
                    "হাতের কাজটা প্রায় শেষ, একটু পরই একদম ফ্রি হয়ে যাবো!"
                ), previousOwn, lastIncoming)
                else -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI) "Ami ekhon free achi dosto, bol ki plan?"
                    else "Ami ekhon motamuti free achi, bolo ki plan?",
                    "Hater kajta pray shesh, ektu porei free hoye jabo!"
                ), previousOwn, lastIncoming)
            }
            return ReplyOptions(replyText, "Plan")
        }

        // 19. LAUGHTER / JOKES ("haha", "hehe", "lol", "হাহা")
        if (hasAny("haha", "hehe", "lol", "lmao", "হাহা", "হিহি")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "হাহা, আসলেই মজার ব্যাপার! তারপর বলো আর কী খবর?"
                ScriptStyle.BANGLISH -> "Haha, asholei mojar bapar! Tarpor bolo ar ki khobor?"
                ScriptStyle.ENGLISH -> "Haha true! So what else is going on?"
            }
            return ReplyOptions(replyText, "Humor")
        }

        // 20. SHORT GREETINGS ("hy", "hi", "hlw", "hello", "oi", "kire")
        if (lower in listOf("hy", "hi", "hlw", "hello", "hey", "oi", "oii", "kire", "ki re", "vai", "bhai", "dosto", "হাই", "হ্যালো", "ওই", "কিরে", "ভাই", "দোস্ত") ||
            lower.startsWith("hi ") || lower.startsWith("hlw ") || lower.startsWith("hello ") || lower.startsWith("hey ")
        ) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI || lower.contains("কিরে") || lower.contains("ওই")) "হ্যাঁ দোস্ত বল, কী খবর তোর?"
                    else "হ্যালো! কী খবর, কেমন আছো?",
                    "হ্যাঁ ভাই বলো, কী অবস্থা?"
                ), previousOwn, lastIncoming)
                ScriptStyle.BANGLISH -> pickUniqueReply(listOf(
                    if (pronoun == PronounStyle.TUI || lower.contains("kire") || lower.contains("oi")) "Haa dosto bol, ki khobor tor?"
                    else "Hey! Ki khobor bolo, kemon acho?",
                    "Hlw bhai! Ki obostha tomar?",
                    "Haa bolo, kemon cholche sob?"
                ), previousOwn, lastIncoming)
                ScriptStyle.ENGLISH -> "Hey! What's up? How's it going?"
            }
            return ReplyOptions(replyText, "Greeting")
        }

        // 21. SHORT ACKNOWLEDGMENTS ("hmm", "ok", "accha", "thanks")
        if (lower in listOf("hmm", "hm", "humm", "ok", "okay", "k", "accha", "acha", "thik ache", "oh", "ooh", "হুম", "হম", "আচ্ছা", "ওকে", "ঠিক আছে") ||
            hasAny("thank", "dhonnobad", "ধন্যবাদ")
        ) {
            val isThanks = hasAny("thank", "dhonnobad", "ধন্যবাদ")
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (isThanks) "আরে ধন্যবাদ দেওয়া লাগবে না! সব ঠিক আছে।"
                else pickUniqueReply(listOf(
                    "হুম, তারপর বলো আর কী খবর?",
                    "আচ্ছা ঠিক আছে! আজকে কী করছো সারাদিন?",
                    "হুম বুঝলাম! বাসার সবাই ভালো তো?"
                ), previousOwn, lastIncoming)
                ScriptStyle.BANGLISH -> if (isThanks) "Areh dhonnobad dewa lagbe na! Sob thik ache."
                else pickUniqueReply(listOf(
                    "Hmm, tarpor bolo ar ki khobor?",
                    "Accha thik ache! Ajke ki korla saradin?",
                    "Hmm bujhlam! Ekhon ki basay naki baire?"
                ), previousOwn, lastIncoming)
                ScriptStyle.ENGLISH -> if (isThanks) "Anytime! Happy to help!" else "Sounds good! So what else is new with you?"
            }
            return ReplyOptions(replyText, "Acknowledgment")
        }

        // 22. SPECIFIC QUESTION WORD ANALYSIS (Why / How / Price / Who)
        if (hasAny(" keno ", " kn ", " কেন ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> if (pronoun == PronounStyle.TUI) "এমনিই রে দোস্ত! ভাবলাম তোর থেকে একটু শুনি ব্যাপারটা।" else "আসলে তেমন বড় কিছু না, এমনিই জানার জন্য বলছিলাম আরকি!"
                else -> if (pronoun == PronounStyle.TUI) "Emnii re dosto! Vablam tor theke ektu shuni baparta." else "Ashole temon kichu na, emnii janar jonno bolchilam arki!"
            }
            return ReplyOptions(replyText, "Question: Why")
        }

        if (hasAny(" kivabe ", " kemne ", " কীভাবে ", " কেমনে ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "এটা খুব সহজ, একটু চেষ্টা করলেই হয়ে যাবে! আমি তোমাকে দেখিয়ে দেবো।"
                else -> "Eita khub sohoj bhai, ektu try korlei hoye jabe! Ami দেখিয়ে dibo tomake."
            }
            return ReplyOptions(replyText, "Question: How")
        }

        if (hasAny(" koto ", " dam ", " taka ", " কত ", " দাম ", " টাকা ")) {
            val replyText = when (script) {
                ScriptStyle.BANGLA -> "দামটা এখন আগের চেয়ে একটু কম-বেশি হতে পারে, তুমি কত বাজেট ভাবছো?"
                else -> "Dam ta ekhon ektu kom-beshi hote pare, tumi koto budget vabcho?"
            }
            return ReplyOptions(replyText, "Question: Price/Amount")
        }

        // 23. NATURAL CONVERSATIONAL FALLBACK (Tailored to Pronoun & Script, Never Repeats)
        val isQuestion = lastIncoming.contains("?")
        val replyText = when (script) {
            ScriptStyle.BANGLA -> pickUniqueReply(
                if (isQuestion) {
                    when (pronoun) {
                        PronounStyle.TUI -> listOf(
                            "আরে দোস্ত, এই ব্যাপারটা নিয়েই তো ভাবছিলাম—তুই কী মনে করিস?",
                            "হ্যাঁ রে, ভালো কথা জিজ্ঞেস করেছিস! তোর নিজের কী প্ল্যান এটা নিয়ে?",
                            "দোস্ত, আমি এখন বাসায় আছি, এই বিষয়টা নিয়ে তোর সাথেই কথা বলবো ভাবছিলাম!",
                            "বুঝলাম তোর প্রশ্নটা! তুই আরেকটু খুলে বল তো দোস্ত?"
                        )
                        PronounStyle.APNI -> listOf(
                            "জি, আপনি খুব ভালো একটি বিষয় জানতে চেয়েছেন। আপনার নিজের মতামত কী এ ব্যাপারে?",
                            "জি বুঝতে পেরেছি আপনার কথাটি। আপনি যেভাবে ভালো মনে করেন সেভাবেই করা যায়।"
                        )
                        PronounStyle.TUMI -> listOf(
                            "হ্যাঁ, ভালো কথা জিজ্ঞেস করেছো! তুমি কী ভাবছো এটা নিয়ে বলো তো?",
                            "আসলে এই বিষয়টা নিয়ে আমিও ভাবছিলাম। আমাকে আরেকটু খুলে বলো?",
                            "হ্যাঁ বুঝতে পেরেছি তোমার কথাটা! তোমার দিক থেকে কী মনে হয়?",
                            "খুব ভালো পয়েন্ট বলেছো! এটার ব্যাপারে তোমার প্ল্যান কী?"
                        )
                    }
                } else {
                    when (pronoun) {
                        PronounStyle.TUI -> listOf(
                            "হ্যাঁ দোস্ত, তোর কথাটা একদম ঠিক! তারপর আর কী অবস্থা বল?",
                            "ব্যাপারটা আসলেই তাই রে! আজকে সারাদিন আর কী করলি?",
                            "একদম খাঁটি কথা বলেছিস দোস্ত! এখন কই আছিস তুই?",
                            "বুঝলাম দোস্ত! বাসার সবার কী খবর বল?"
                        )
                        PronounStyle.APNI -> listOf(
                            "জি, আপনার কথাটি বুঝতে পেরেছি। আপনি একদম ঠিক বলেছেন।",
                            "জি ধন্যবাদ বিষয়টি জানানোর জন্য। আপনার দিনকাল কেমন কাটছে?"
                        )
                        PronounStyle.TUMI -> listOf(
                            "হ্যাঁ, তোমার কথাটা একদম যৌক্তিক! তারপর আর কী খবর বলো?",
                            "আসলেই তাই! আজকে দিনকাল কেমন কাটছে তোমার?",
                            "বুঝতে পেরেছি! এখন কি বাসায় আছো নাকি বাইরে?",
                            "একদম ঠিক বলেছো! তা চা-নাস্তা খাওয়া হয়েছে তোমার?"
                        )
                    }
                },
                previousOwn,
                lastIncoming
            )
            ScriptStyle.BANGLISH -> pickUniqueReply(
                if (isQuestion) {
                    when (pronoun) {
                        PronounStyle.TUI -> listOf(
                            "Areh dosto, ei baparta niyei to vabchilam—tui ki mone koros?",
                            "Haa re, bhalo kotha jiggesh korli! Tui ektu khule bol to?",
                            "Dosto, ami basay achi ekhon, ei bishoyta niye tor ki plan bol?",
                            "Hmm bujhchi tor proshnota! Tor nijer ki mot eita niye?"
                        )
                        PronounStyle.APNI -> listOf(
                            "Ji, apnar bishoyti bujhte perechi. Apni jevabe bhalo mone koren sevabei kora jay.",
                            "Ji, khub bhalo kotha bolechen. E bapare apnar motamot ki?"
                        )
                        PronounStyle.TUMI -> listOf(
                            "Haa, bhalo kotha jiggesh korcho! Tumi ki vabcho eita niye bolo to?",
                            "Ashole ei baparta niye amio vabchilam! Arektu khule bolo?",
                            "Hmm bujhte perechi tomar kothata! Tomar dik theke ki mone hoy?",
                            "Khub bhalo kotha bolcho! Eitar bapare tomar plan ki bolo?"
                        )
                    }
                } else {
                    when (pronoun) {
                        PronounStyle.TUI -> listOf(
                            "Haa dosto, tor kothata ekdom thik! Tarpor ar ki obostha bol?",
                            "Baparta asholei tai re! Ajke saradin ar ki korli?",
                            "Ekdom sotti kotha bolsis dosto! Ekhon koi achis tui?",
                            "Bujhlam re dosto! Basar sobar ki khobor bol?"
                        )
                        PronounStyle.APNI -> listOf(
                            "Ji, apnar kothati bujhte perechi. Apni ekdom thik bolechen.",
                            "Ji dhonnobad bishoyti bolbar jonno. Apnar dinkal kemon jacche?"
                        )
                        PronounStyle.TUMI -> listOf(
                            "Haa, tomar kothata ekdom thik! Tarpor ar ki khobor bolo?",
                            "Asholei tai bhai! Ajke dinkal kemon katche tomar?",
                            "Bujhte perechi! Ekhon ki basay acho naki baire?",
                            "Hmm thik bolcho! Ta cha-nasta khawa hoise tomar?",
                            "Bujhlam tomar kothata! Ekhon ki korteso bose?"
                        )
                    }
                },
                previousOwn,
                lastIncoming
            )
            ScriptStyle.ENGLISH -> pickUniqueReply(listOf(
                "Totally get what you mean! What do you think we should do about it?",
                "Makes complete sense! How's the rest of your day going?",
                "That's a really good point! Tell me more about what's on your mind.",
                "I hear you! Are you at home right now or out?"
            ), previousOwn, lastIncoming)
        }

        return ReplyOptions(replyText, "${script.name} • ${pronoun.name}")
    }
}
