package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class GeminiReplyClient {

    private val geminiModels = listOf(
        "gemini-2.0-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.5-flash",
        "gemini-1.5-flash"
    )

    /**
     * Generates ONE hyper-realistic, message-driven reply based purely on the last 4-5 messages
     * and the exact words, emotion, pronoun, and script of the latest incoming SMS.
     * No artificial Friendly/Polite/Professional categories!
     */
    suspend fun generateContextualReply(
        apiKey: String,
        messages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String> = emptySet()
    ): ReplyOptions = withContext(Dispatchers.IO) {
        val windowMessages = messages.takeLast(5)
        if (windowMessages.isEmpty()) {
            return@withContext ReplyOptions("", "Empty")
        }

        val allExcluded = HashSet<String>().apply {
            addAll(excludedReplies)
            windowMessages.filter { it.sender == "Me" }.forEach { add(it.text.trim()) }
        }

        val prompt = buildMessageDrivenPrompt(windowMessages, languagePreference, allExcluded)

        // 1. Try Google Gemini API if API Key is configured
        if (apiKey.isNotBlank()) {
            for (modelName in geminiModels) {
                try {
                    val rawResponse = executeGeminiPost(
                        apiKey = apiKey,
                        modelName = modelName,
                        prompt = prompt,
                        maxOutputTokens = 240,
                        connectTimeoutMs = 4000,
                        readTimeoutMs = 5000,
                        useJsonMime = true
                    ) ?: executeGeminiPost(
                        apiKey = apiKey,
                        modelName = modelName,
                        prompt = prompt,
                        maxOutputTokens = 240,
                        connectTimeoutMs = 4000,
                        readTimeoutMs = 5000,
                        useJsonMime = false
                    )
                    if (!rawResponse.isNullOrBlank()) {
                        val parsed = ReplyJsonParser.parseAiReply(rawResponse)
                        if (parsed.isNotBlank() && !isDuplicateReply(parsed, allExcluded)) {
                            return@withContext ReplyOptions(parsed, "Gemini AI • Adaptive")
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }

        // 2. Built-in Free Cloud AI (Works with ZERO API Key!)
        val cloudAiReply = callBuiltInFreeCloudAi(windowMessages, languagePreference, allExcluded)
        if (!cloudAiReply.isNullOrBlank() && !isDuplicateReply(cloudAiReply, allExcluded)) {
            return@withContext ReplyOptions(cloudAiReply, "Cloud AI • Adaptive")
        }

        // 3. Smart Context-Driven Local Engine (Non-repeating, message-specific)
        ReplyJsonParser.buildSmartContextualReply(windowMessages, allExcluded)
    }

    private fun isDuplicateReply(candidate: String, excluded: Set<String>): Boolean {
        val normCandidate = candidate.trim().lowercase()
        return excluded.any { it.trim().lowercase() == normCandidate }
    }

    private fun executeGeminiPost(
        apiKey: String,
        modelName: String,
        prompt: String,
        maxOutputTokens: Int,
        connectTimeoutMs: Int,
        readTimeoutMs: Int,
        useJsonMime: Boolean
    ): String? {
        val endpoint =
            "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val url = URL(endpoint)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
            doOutput = true
        }

        val genConfig = JSONObject().apply {
            put("temperature", 0.75)
            put("maxOutputTokens", maxOutputTokens)
            if (useJsonMime) {
                put("responseMimeType", "application/json")
            }
            if (modelName.startsWith("gemini-2.5")) {
                put("thinkingConfig", JSONObject().apply {
                    put("thinkingBudget", 0)
                })
            }
        }

        val payload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("generationConfig", genConfig)
        }

        OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
            writer.write(payload.toString())
            writer.flush()
        }

        val responseCode = connection.responseCode
        val stream = if (responseCode in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream
        }

        val responseBody = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use {
            it.readText()
        }
        connection.disconnect()

        if (responseCode !in 200..299) {
            return null
        }

        val root = JSONObject(responseBody)
        val parts = root
            .getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")

        for (i in 0 until parts.length()) {
            val partObj = parts.getJSONObject(i)
            if (!partObj.optBoolean("thought", false) && partObj.has("text")) {
                val txt = partObj.getString("text").trim()
                if (txt.isNotEmpty()) return txt
            }
        }
        return null
    }

    private fun callBuiltInFreeCloudAi(
        windowMessages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String>
    ): String? {
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val historyFormatted = windowMessages.mapIndexed { i, m ->
            val tag = if (i == windowMessages.lastIndex) "[LATEST SMS TO REPLY]" else "[#${i + 1}]"
            "$tag ${m.sender}: ${m.text}"
        }.joinToString("\n")
        val avoidStr = excludedReplies.take(12).joinToString(" | ")

        val systemMsg = listOf(
            "You are a real Bangladeshi person chatting naturally on WhatsApp.",
            "Read the last ${windowMessages.size} messages and write ONLY 1 realistic, human reply that directly responds to the exact words and meaning of [LATEST SMS TO REPLY]: \"$lastIncoming\".",
            "CRITICAL RULES:",
            "1. PURE MESSAGE-DRIVEN REALISM: Do NOT use artificial templates or vague lines like 'I will confirm later' or 'I will let you know soon'. Answer or react to \"$lastIncoming\" directly, naturally, and specifically like a real human.",
            "2. EXACT LANGUAGE & SCRIPT MATCHING (Preference: $languagePreference): If \"$lastIncoming\" is in Banglish (Romanized Bangla), reply in natural Bangladeshi Banglish. If Bangla script, reply in natural spoken Bangla. If English, reply in casual English.",
            "3. AUTOMATIC TONE & PRONOUN MATCHING: Infer the relationship and tone directly from the message. If they use 'tui/tor/dosto', reply in 'tui' style. If 'tumi/tmi/tomar', reply in 'tumi' style. If 'apni/apnar', reply in respectful 'apni' style.",
            "4. NEVER REPEAT any of these previous replies: [$avoidStr].",
            "5. Output ONLY the raw reply text (1 short, natural WhatsApp sentence, no quotes, no JSON)."
        ).joinToString("\n")

        // Method A: Fast OpenAI-compatible POST
        try {
            val url = URL("https://text.pollinations.ai/openai")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                connectTimeout = 4200
                readTimeout = 5200
                doOutput = true
            }

            val body = JSONObject().apply {
                put("model", "openai")
                put("temperature", 0.78)
                put("seed", (System.currentTimeMillis() % 100000).toInt())
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "system")
                        put("content", systemMsg)
                    })
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", "Recent Chat:\n$historyFormatted\n\nReply directly to \"$lastIncoming\":")
                    })
                })
            }

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body.toString())
                writer.flush()
            }

            if (conn.responseCode in 200..299) {
                val resp = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
                conn.disconnect()
                val root = JSONObject(resp)
                val content = root
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim()
                val cleaned = ReplyJsonParser.parseAiReply(content)
                if (cleaned.isNotBlank()) return cleaned
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {
        }

        // Method B: Direct GET Cloud AI fallback
        try {
            val compactPrompt = "$systemMsg\nChat:\n$historyFormatted\nReply:"
            val encoded = URLEncoder.encode(compactPrompt, "UTF-8")
            val seed = (System.currentTimeMillis() % 100000).toInt()
            val url = URL("https://text.pollinations.ai/$encoded?model=openai&seed=$seed")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 5000
            }
            if (conn.responseCode in 200..299) {
                val resp = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
                conn.disconnect()
                val cleaned = ReplyJsonParser.parseAiReply(resp)
                if (cleaned.isNotBlank()) return cleaned
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {
        }

        return null
    }

    private fun buildMessageDrivenPrompt(
        windowMessages: List<ChatMessage>,
        languagePreference: String,
        excludedReplies: Set<String>
    ): String {
        val lastIncoming = windowMessages.lastOrNull { it.sender == "Incoming" }?.text
            ?: windowMessages.last().text
        val historyFormatted = windowMessages.mapIndexed { i, m ->
            val tag = if (i == windowMessages.lastIndex) "[LATEST TARGET SMS]" else "[Context #${i + 1}]"
            "$tag ${m.sender}: ${m.text}"
        }.joinToString("\n")

        val avoidList = if (excludedReplies.isEmpty()) "None" else excludedReplies.take(12).joinToString(" | ")

        return listOf(
            "You are a real human chatting on WhatsApp in Bangladesh.",
            "Analyze the last ${windowMessages.size} messages below and write ONE immediate, realistic, natural reply that directly answers or reacts to the [LATEST TARGET SMS]: \"$lastIncoming\".",
            "",
            "STRICT CONVERSATIONAL RULES:",
            "1. PURE SMS-DRIVEN REALISM: Do NOT use pre-set categories. Infer the exact emotion, seriousness, humor, or intimacy directly from \"$lastIncoming\" and the preceding messages. Directly answer what they asked or said.",
            "2. EXACT LANGUAGE & PRONOUN MIRRORING (Preference: $languagePreference):",
            "   - Match the exact script (Banglish -> natural Bangladeshi Banglish; Bangla script -> natural spoken Bangla; English -> natural English).",
            "   - Mirror the exact pronoun used by the sender: 'tui/tor/dosto' (তুই), 'tumi/tmi/tomar' (তুমি), or 'apni/apnar' (আপনি).",
            "3. NO GENERIC EVASIONS: Never say 'I will confirm later' or 'I will let you know in a bit' unless the context specifically asks for a schedule.",
            "4. ZERO REPETITION: NEVER repeat any of these previously sent replies: [$avoidList].",
            "5. LENGTH: 1 to 2 short, natural WhatsApp sentences.",
            "",
            "Last ${windowMessages.size} Messages in Chat:",
            historyFormatted,
            "",
            "Return ONLY a JSON object with a single key \"reply\":",
            "{\"reply\": \"Your single realistic human reply\"}"
        ).joinToString("\n")
    }
}
