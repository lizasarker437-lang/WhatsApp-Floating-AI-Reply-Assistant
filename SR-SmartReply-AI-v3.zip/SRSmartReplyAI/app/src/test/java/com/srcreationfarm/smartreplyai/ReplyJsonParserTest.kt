package com.srcreationfarm.smartreplyai

import com.srcreationfarm.smartreplyai.ai.ReplyJsonParser
import com.srcreationfarm.smartreplyai.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReplyJsonParserTest {

    @Test
    fun parseAiReply_extractsReplyCleanly() {
        val raw = "{\"reply\": \"Haa dosto, ektu agei khailam. Tui khaisos?\"}"
        val reply = ReplyJsonParser.parseAiReply(raw)
        assertEquals("Haa dosto, ektu agei khailam. Tui khaisos?", reply)
    }

    @Test
    fun buildSmartContextualReply_adaptsDirectlyToMessageAndContext() {
        val fiveMessageThread = listOf(
            ChatMessage("Incoming", "Kire dosto ki koros?"),
            ChatMessage("Me", "Eito basay bose achi re. Tui?"),
            ChatMessage("Incoming", "Dupure ভাত khaisos?"),
            ChatMessage("Me", "Haa ektu agei khailam. Tui khaisos?"),
            ChatMessage("Incoming", "Na")
        )

        val ctx = ReplyJsonParser.analyzeConversationThread(fiveMessageThread)
        assertEquals(ReplyJsonParser.PronounStyle.TUI, ctx.pronounStyle)
        assertEquals(ReplyJsonParser.ConversationTopic.FOOD, ctx.previousTopic)

        val result = ReplyJsonParser.buildSmartContextualReply(fiveMessageThread)
        assertTrue(result.reply.contains("khas", ignoreCase = true) || result.reply.contains("kheye", ignoreCase = true))
    }

    @Test
    fun buildSmartContextualReply_neverRepeatsRepliesAcrossSequence() {
        val incomingSequence = listOf(
            "Tmi ki Kotha bujho na",
            "Ki janabe",
            "Ki",
            "Aito aci",
            "Kono khobor nai",
            "Ki confirm korba",
            "Ki sob bolteco"
        )
        val sentReplies = mutableSetOf<String>()
        val chatHistory = mutableListOf<ChatMessage>()

        for (inc in incomingSequence) {
            chatHistory.add(ChatMessage("Incoming", inc))
            val reply = ReplyJsonParser.buildSmartContextualReply(chatHistory.takeLast(5), sentReplies).reply
            assertTrue("Duplicate reply generated: $reply", reply !in sentReplies)
            sentReplies.add(reply)
            chatHistory.add(ChatMessage("Me", reply))
        }
        assertEquals(incomingSequence.size, sentReplies.size)
    }
}
