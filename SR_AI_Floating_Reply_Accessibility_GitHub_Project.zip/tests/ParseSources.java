import javax.tools.JavaCompiler;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaFileObject;
import com.sun.source.util.JavacTask;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

/** Parses Java syntax without Android classpath. Not a type-check or APK compilation. */
public class ParseSources {
    public static void main(String[] args) throws Exception {
        File source=new File(args[0]);
        File[] src=source.listFiles((d,n)->n.endsWith(".java"));
        if(src==null || src.length<5)throw new IllegalStateException("No Java sources");
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> issues=new DiagnosticCollector<>();
        try(StandardJavaFileManager fm=compiler.getStandardFileManager(issues,null,null)) {
            Iterable<? extends JavaFileObject> fs=fm.getJavaFileObjectsFromFiles(Arrays.asList(src));
            JavacTask parser=(JavacTask)compiler.getTask(null,fm,issues,
                Arrays.asList("-proc:none","--release","17"),null,fs);
            parser.parse();
        }
        if(!issues.getDiagnostics().isEmpty()) {
            issues.getDiagnostics().forEach(System.err::println);
            throw new IllegalStateException("Java syntax parsing failed");
        }
        System.out.println("PASS Java parser: "+src.length+" Android source files");
    }
}
