#!/usr/bin/env python3
"""Offline checks; never misrepresents itself as a device / Gradle build."""
from pathlib import Path
import xml.etree.ElementTree as ET
import subprocess
import tempfile
import sys
import shutil
import yaml

root = Path(__file__).resolve().parents[1]
java_dir = root / 'app/src/main/java/com/srcreationfarm/aireply'
for path in (root/'settings.gradle', root/'build.gradle', root/'app/build.gradle',
             root/'.github/workflows/build.yml', root/'README.md'):
    assert path.exists(), f'Missing {path}'
for path in root.rglob('*.xml'):
    ET.parse(path)
    print('PASS XML:',path.relative_to(root))
for path in java_dir.glob('*.java'):
    content=path.read_text()
    assert content.startswith('package com.srcreationfarm.aireply;'), path
    assert content.count('{')==content.count('}'), path
    print('PASS Java structural:',path.relative_to(root))
with (root/'.github/workflows/build.yml').open() as f:
    workflow=yaml.load(f,yaml.BaseLoader)
assert workflow['jobs']['build']['steps']
assert 'assembleDebug' in (root/'.github/workflows/build.yml').read_text()
assert '8.9.2' in (root/'build.gradle').read_text()
assert '8.11.1' in (root/'.github/workflows/build.yml').read_text()
assert '35' in (root/'app/build.gradle').read_text()
assert 'BIND_ACCESSIBILITY_SERVICE' in (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'isAccessibilityTool="true"' not in (root/'app/src/main/res/xml/accessibility_service_config.xml').read_text()
print('PASS Workflow / Android config')
with tempfile.TemporaryDirectory() as t:
    test_path=Path(t)/'ReplyRulesTest.java'
    test_path.write_text('''import com.srcreationfarm.aireply.ReplyRules;
public class ReplyRulesTest {
  private static void check(boolean value) { if(!value) throw new AssertionError(); }
  public static void main(String[] args) {
    check(ReplyRules.allowlisted("Rahim, My Test Number", " rahim "));
    check(!ReplyRules.allowlisted("Rahim", "Karim"));
    check(!ReplyRules.allowlisted("", "Rahim"));
    check(ReplyRules.sensitive("আমাকে বিকাশে টাকা পাঠাও"));
    check(ReplyRules.sensitive("Send OTP 1234"));
    check(!ReplyRules.sensitive("আজ কেমন আছো?"));
    check(ReplyRules.suitable("Hi there!"));
    check(!ReplyRules.suitable(""));
    check(!ReplyRules.suitable("x".repeat(1300)));
    System.out.println("PASS 9 rule tests");
  }
}''')
    subprocess.run(['javac','-d',t,str(java_dir/'ReplyRules.java'),str(test_path)],check=True)
    subprocess.run(['java','-cp',t,'ReplyRulesTest'],check=True)
    subprocess.run(['javac','-d',t,str(root/'tests/ParseSources.java')],check=True)
    subprocess.run(['java','-cp',t,'ParseSources',str(java_dir)],check=True)
print('PASS offline test suite. NOTE: Android SDK compilation and real-device test not run.')
