package com.srcreationfarm.aireply;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Experimental, user-visible, opt-in UI assistant. Only reads nodes belonging to WhatsApp
 * while the app is on screen. No hidden-data extraction, screen-capture permission or bypass.
 * Changes in WhatsApp UI can break heuristics. Auto is OFF by default and allowlist-only.
 */
public final class WhatsAppAccessibilityService extends AccessibilityService {
    private static final String WA = "com.whatsapp";
    private static final String WAB = "com.whatsapp.w4b";
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String,String> bottomSeen = new HashMap<>();
    private final Map<String,Long> lastSentAt = new HashMap<>();
    private Prefs prefs;
    private WindowManager wm;
    private WindowManager.LayoutParams layout;
    private LinearLayout overlay, panel;
    private ScrollView panelScroll;
    private long lastScrollAt;
    private TextView indicator, detected, state;
    private Button toggle, friendlyBtn, politeBtn, professionalBtn;
    private EditText draft;
    private boolean overlayVisible, panelOpen, requestInFlight;
    private long generation;
    private ChatMessage shown;
    private Suggestions suggestions;
    private String style = "friendly";
    private int screenW, screenH;
    private final Runnable scanTask = () -> scan(false,false);

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        prefs=new Prefs(this);
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        android.util.DisplayMetrics metrics=getResources().getDisplayMetrics();
        screenW=metrics.widthPixels; screenH=metrics.heightPixels;
        AccessibilityServiceInfo info=getServiceInfo();
        if (info!=null) { info.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                |AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;setServiceInfo(info); }
        createOverlay();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event==null || wm==null || prefs==null) return;
        if(event.getEventType()==AccessibilityEvent.TYPE_VIEW_SCROLLED) lastScrollAt=System.currentTimeMillis();
        main.removeCallbacks(scanTask);
        main.postDelayed(scanTask,240);
    }

    @Override public void onInterrupt() { /* Platform interrupt; no action. */ }
    @Override public void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (wm!=null && overlay!=null && overlayVisible) {
            try {wm.removeViewImmediate(overlay);} catch(Exception ignored){}
        }
        super.onDestroy();
    }

    private static boolean isWhatsApp(String p) {return WA.equals(p)||WAB.equals(p);}
    private AccessibilityNodeInfo whatsappRoot() {
        // Prefer interactive window roots so our accessibility overlay never replaces the target.
        try {
            List<AccessibilityWindowInfo> windows=getWindows();
            if(windows!=null) for(AccessibilityWindowInfo win:windows) {
                if(win.getType()==AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue;
                AccessibilityNodeInfo root=win.getRoot();
                if(root!=null && root.getPackageName()!=null && isWhatsApp(root.getPackageName().toString()))
                    return root;
            }
        } catch(Exception ignored){}
        AccessibilityNodeInfo root=getRootInActiveWindow();
        return root!=null && root.getPackageName()!=null && isWhatsApp(root.getPackageName().toString()) ? root:null;
    }

    private void scan(boolean forced, boolean regenerate) {
        if(prefs==null || !prefs.enabled()) {setOverlayVisible(false);return;}
        AccessibilityNodeInfo root=whatsappRoot();
        if(root==null) {
            setOverlayVisible(false);
            bottomSeen.clear();
            return;
        }
        setOverlayVisible(true);
        ChatMessage candidate=capture(root);
        if(candidate==null) {if(forced)showStatus("No readable message found. Open a text chat.");return;}
        String chat=candidate.chatTitle;
        String prior=bottomSeen.put(chat,candidate.fingerprint);
        // An already open or newly opened chat is a baseline. Don't auto-reply to history.
        boolean isNew=prior!=null && !prior.equals(candidate.fingerprint);
        if (!candidate.incoming || (!candidate.strong && !forced)) {
            if(forced) {
                shown=candidate; suggestions=null;
                showMessage(candidate);
                showStatus("This may not be an incoming text bubble. Auto reply skipped.");
            }
            return;
        }
        if (!forced && !isNew) return;
        if (!forced && requestInFlight) return;
        shown=candidate; suggestions=null;showMessage(candidate);
        if(!prefs.consent()) {showStatus("Cloud consent is OFF. Enable it in app settings.");return;}
        if(!prefs.hasKey()) {showStatus("Save your API key in app settings.");return;}
        boolean allowed=prefs.auto() && !forced && System.currentTimeMillis()-lastScrollAt>1500 && autoAllowed(candidate);
        // Manual mode prepares suggestions, but never sends without a tap.
        if(!forced && !allowed && prefs.auto()) {
            showStatus("Manual suggestions only (chat not allowlisted / safety rule).");
        }
        requestAi(candidate,allowed);
    }

    private boolean autoAllowed(ChatMessage c) {
        if(!c.incoming || !c.strong || !c.chatTrusted || !ReplyRules.allowlisted(prefs.allowlist(),c.chatTitle)
            || !ReplyRules.suitable(c.text) || ReplyRules.sensitive(c.text)) return false;
        Long last=lastSentAt.get(c.chatTitle);
        return last==null || System.currentTimeMillis()-last>=60_000;
    }

    private void requestAi(ChatMessage c,boolean auto) {
        if(requestInFlight) {showStatus("AI is processing an earlier message.");return;}
        requestInFlight=true;
        long token=++generation;
        showStatus("Generating AI replies…");
        AiClient.generate(this,c.text,(reply,error) -> {
            requestInFlight=false;
            if(token!=generation || shown==null || !shown.fingerprint.equals(c.fingerprint))return;
            if(error!=null) {showStatus(error);return;}
            suggestions=reply;
            chooseStyle(prefs.style());
            if(auto && prefs.auto() && prefs.enabled() && prefs.consent()
                && autoAllowed(c) && currentStillMatches(c)) {
                String response=reply.chosen(prefs.style());
                if (sendIntoWhatsApp(response,true)) {
                    lastSentAt.put(c.chatTitle,System.currentTimeMillis());
                    showStatus("Auto send was triggered. WhatsApp delivery not confirmed.");
                } else showStatus("Auto-send unavailable. Please use Send manually.");
            } else showStatus("3 replies ready. Choose a style, edit, then tap Send.");
        });
    }

    private boolean currentStillMatches(ChatMessage c) {
        AccessibilityNodeInfo root=whatsappRoot();
        ChatMessage now=root==null?null:capture(root);
        return now!=null && c.fingerprint.equals(now.fingerprint) && c.chatTitle.equals(now.chatTitle);
    }

    private boolean sendIntoWhatsApp(String content,boolean auto) {
        if(content==null || content.trim().isEmpty() || shown==null) return false;
        if(!currentStillMatches(shown)) {showStatus("Chat changed. Scan again.");return false;}
        final ChatMessage target=shown;
        final String reply=content.trim();
        AccessibilityNodeInfo root=whatsappRoot();
        if(root==null)return false;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();flatten(root,nodes,0);
        AccessibilityNodeInfo composer=null;
        for(AccessibilityNodeInfo n:nodes){
            if(!n.isVisibleToUser() || !n.isEditable())continue;
            Rect r=bounds(n);
            if(r.centerY()<screenH*.65f)continue;
            String id=id(n);
            if(id.contains("entry")||id.contains("input")||id.contains("message")||id.contains("compose"))
                composer=n;
        }
        if(composer==null) {showStatus("WhatsApp composer not accessible on this version.");return false;}
        // Preserve any message the user started typing; never overwrite personal work.
        if(!str(composer.getText()).trim().isEmpty()) {showStatus("Composer already has text. Clear it first.");return false;}
        Bundle args=new Bundle();args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,reply);
        if(!composer.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args)) {
            showStatus("WhatsApp refused to insert text.");return false;
        }
        showStatus("Text inserted. Looking for WhatsApp Send button…");
        // Many WhatsApp versions show the Send button ONLY after the composer has text.
        main.postDelayed(()->{
            if(!prefs.enabled() || !target.chatTitle.equals(shown==null?"":shown.chatTitle)
                || !currentStillMatches(target)) {showStatus("Chat changed; not sending.");return;}
            AccessibilityNodeInfo currentRoot=whatsappRoot();
            if(currentRoot==null)return;
            ArrayList<AccessibilityNodeInfo> current=new ArrayList<>();flatten(currentRoot,current,0);
            boolean composerHasText=false;
            AccessibilityNodeInfo send=null;
            for(AccessibilityNodeInfo n:current){
                if(!n.isVisibleToUser())continue;
                Rect r=bounds(n);
                if(r.centerY()<screenH*.65f)continue;
                String id=id(n),desc=str(n.getContentDescription());
                if(n.isEditable() && reply.equals(str(n.getText()))) composerHasText=true;
                if(n.isClickable() && ((id.contains("send")&&!id.contains("resend"))
                    ||desc.equalsIgnoreCase("send")||desc.equalsIgnoreCase("পাঠান")))send=n;
            }
            if(!composerHasText){showStatus("Composer changed; send cancelled.");return;}
            if(send!=null && send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                showStatus("WhatsApp Send clicked. Message delivery is not verified.");
            } else showStatus("Couldn't click Send. Text remains in WhatsApp for manual sending.");
        },350);
        bottomSeen.put(target.chatTitle,target.fingerprint);
        return true; // Text inserted and a delayed send attempt scheduled, not confirmed delivery.
    }

    private ChatMessage capture(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();flatten(root,nodes,0);
        String title="";boolean trusted=false;
        for(AccessibilityNodeInfo n:nodes){
            Rect r=bounds(n);String id=id(n),text=str(n.getText()).trim();
            if(!n.isVisibleToUser()||text.isEmpty()||r.centerY()>screenH*.2f)continue;
            if(id.contains("conversation_contact_name")||id.contains("conversation_title")
                ||id.contains("conversation_toolbar_title")||id.contains("conversation_contact")) {
                title=text;trusted=true;break;
            }
        }
        if(title.isEmpty()) {
            for(AccessibilityNodeInfo n:nodes){
                Rect r=bounds(n);String id=id(n),t=str(n.getText()).trim();
                if(n.isVisibleToUser() && r.centerY()<screenH*.18f && t.length()>1
                    && (id.contains("toolbar_title")||id.contains("title"))
                    && !t.equalsIgnoreCase("WhatsApp")) {title=t;break;}
            }
        }
        if(title.isEmpty()) title="Unknown chat";
        ChatMessage best=null;
        for(AccessibilityNodeInfo n:nodes) {
            if(!n.isVisibleToUser()||n.isEditable())continue;
            String t=str(n.getText()).trim();
            if(t.length()<2||t.length()>1200)continue;
            Rect r=bounds(n);
            if(r.centerY()<screenH*.19f||r.centerY()>screenH*.86f || r.width()<dp(9))continue;
            String id=id(n);
            boolean strong=id.contains("message_text")||id.contains("conversation_text_row")
                ||id.contains("conversation_text")||id.contains("text_message")
                ||id.contains("message_content")||id.contains("message_body");
            if(!strong)continue;
            int left=r.left,right=screenW-r.right;
            boolean incoming=prefs.incomingRight()?left>right+dp(28):right>left+dp(28);
            String signature=title+"|"+t+"|"+incoming+"|"+r.top;
            ChatMessage cm=new ChatMessage(title,t,signature,incoming,strong,trusted,r.centerY());
            if(best==null || cm.y>best.y)best=cm;
        }
        if(best!=null) return best;
        // Best-effort fallback: manual scan only. Unidentified generic text is NEVER
        // automatically sent to AI or WhatsApp without a user-initiated SCAN.
        for(AccessibilityNodeInfo n:nodes) {
            if(!n.isVisibleToUser()||n.isEditable()) continue;
            String t=str(n.getText()).trim();
            Rect r=bounds(n);
            if(t.length()<2||t.length()>1200||t.matches("[0-9: .APMapm]+")
                || r.centerY()<screenH*.19f||r.centerY()>screenH*.86f)continue;
            if(n.getClassName()==null||!n.getClassName().toString().contains("TextView"))continue;
            boolean incoming=prefs.incomingRight()
                ? r.left>screenW-r.right+dp(28) : screenW-r.right>r.left+dp(28);
            String fp=title+"|"+t+"|"+incoming+"|"+r.top;
            ChatMessage cm=new ChatMessage(title,t,fp,incoming,false,trusted,r.centerY());
            if(best==null||cm.y>best.y)best=cm;
        }
        return best;
    }

    private void flatten(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> into,int depth) {
        if(n==null||depth>32||into.size()>900)return;
        into.add(n);
        for(int i=0;i<n.getChildCount()&&into.size()<=900;i++) flatten(n.getChild(i),into,depth+1);
    }
    private Rect bounds(AccessibilityNodeInfo n){Rect r=new Rect();n.getBoundsInScreen(r);return r;}
    private static String id(AccessibilityNodeInfo n) {String s=n.getViewIdResourceName();return s==null?"":s.toLowerCase(java.util.Locale.ROOT);}
    private static String str(CharSequence t) {return t==null?"":t.toString();}
    private int dp(float a) {return (int)(getResources().getDisplayMetrics().density*a+0.5f);}

    private void createOverlay() {
        overlay=new LinearLayout(this);overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.END);
        toggle=new Button(this);toggle.setText("✦ AI");toggle.setAllCaps(false);toggle.setTextSize(17);toggle.setTextColor(Color.WHITE);
        toggle.setBackground(shape(0xFF046C52,100,0xFFB3E6D1));
        LinearLayout.LayoutParams top=new LinearLayout.LayoutParams(dp(80),dp(54));top.gravity=Gravity.RIGHT;
        overlay.addView(toggle,top);
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(13),dp(12),dp(13),dp(13));
        panel.setBackground(shape(0xFFF8FFFC,18,0xFFA6D9C6));
        panelScroll=new ScrollView(this);panelScroll.setFillViewport(false);
        panelScroll.addView(panel,new android.widget.FrameLayout.LayoutParams(-1,-2));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(
            Math.min(dp(305),screenW-dp(18)),Math.min(dp(475),(int)(screenH*.65f)));
        pp.topMargin=dp(5);
        overlay.addView(panelScroll,pp);
        indicator=label(panel,"SR AI • WhatsApp",16,0xFF075C45,true);
        detected=label(panel,"Open a WhatsApp chat, then tap SCAN.",13,0xFF3A5349,false);
        state=label(panel,"Manual mode. Auto requires allowlisted chats.",12,0xFF688476,false);
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        panel.addView(actions,new LinearLayout.LayoutParams(-1,-2));
        Button scan=mini(actions,"SCAN",()->scan(true,false));
        mini(actions,"RETRY",()->{ if(shown!=null && prefs.consent() && prefs.hasKey()) {
            suggestions=null;requestAi(shown,false);
        }});
        friendlyBtn=mini(panel,"Friendly",()->chooseStyle("friendly"));
        politeBtn=mini(panel,"Polite",()->chooseStyle("polite"));
        professionalBtn=mini(panel,"Professional",()->chooseStyle("professional"));
        draft=new EditText(this);draft.setTextSize(14);draft.setMinLines(2);draft.setMaxLines(5);
        draft.setHint("AI reply appears here. You can edit it.");
        draft.setTextColor(0xFF213D33);draft.setBackground(shape(Color.WHITE,9,0xFFCBDDD4));
        draft.setPadding(dp(8),dp(6),dp(8),dp(6));
        panel.addView(draft,new LinearLayout.LayoutParams(-1,-2));
        draft.setOnFocusChangeListener((v,focused)-> {if(!focused)setOverlayFocusable(false);});
        mini(panel,"EDIT REPLY",()->{
            setOverlayFocusable(true);draft.requestFocus();
            InputMethodManager ime=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if(ime!=null)ime.showSoftInput(draft,InputMethodManager.SHOW_IMPLICIT);
        });
        mini(panel,"SEND IN WHATSAPP",()->{
            if(!sendIntoWhatsApp(draft.getText().toString(),false))
                Toast.makeText(this,"Could not send. Review status in panel.",Toast.LENGTH_SHORT).show();
            else showStatus("Send action triggered. Delivery is not verified.");
        });
        mini(panel,"CLOSE PANEL",()->setPanelOpen(false));
        setPanelOpen(false);
        layout=new WindowManager.LayoutParams(-2,-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,android.graphics.PixelFormat.TRANSLUCENT);
        layout.gravity=Gravity.TOP|Gravity.RIGHT;layout.x=dp(10);layout.y=dp(92);
        toggle.setOnClickListener(v->setPanelOpen(!panelOpen));
    }
    private GradientDrawable shape(int color,int radius,int stroke) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),stroke);return d;
    }
    private TextView label(LinearLayout parent,String text,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(color);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setPadding(dp(3),dp(5),dp(3),dp(5));parent.addView(v,new LinearLayout.LayoutParams(-1,-2));return v;
    }
    private Button mini(LinearLayout parent,String s,Runnable action) {
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(12);
        b.setTextColor(0xFF005B45);b.setBackground(shape(0xFFE4F5EC,10,0xFFC6DCCE));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(38));p.topMargin=dp(4);
        if(parent.getOrientation()==LinearLayout.HORIZONTAL){p.width=0;p.weight=1;p.leftMargin=dp(2);}
        parent.addView(b,p);b.setOnClickListener(v->action.run());return b;
    }
    private void setPanelOpen(boolean open) {
        panelOpen=open;panelScroll.setVisibility(open?View.VISIBLE:View.GONE);
        if(toggle!=null)toggle.setText(open?"✕ AI":"✦ AI");
        if(!open)setOverlayFocusable(false);
    }
    private void setOverlayFocusable(boolean focus) {
        if(layout==null||!overlayVisible)return;
        if(focus)layout.flags &=~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        else layout.flags|=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        try{wm.updateViewLayout(overlay,layout);}catch(Exception ignored){}
    }
    private void setOverlayVisible(boolean visible) {
        if(overlayVisible==visible||wm==null||overlay==null)return;
        try{
            if(visible)wm.addView(overlay,layout);
            else wm.removeView(overlay);
            overlayVisible=visible;
        }catch(Exception e){overlayVisible=false;}
    }
    private void showMessage(ChatMessage c) {
        detected.setText("Chat: "+c.chatTitle+"\nMessage: "+c.text);
        if(!panelOpen)setPanelOpen(true);
        draft.setText("");
    }
    private void showStatus(String status){if(state!=null)state.setText(status);}
    private void chooseStyle(String choice) {
        style=choice;
        if(suggestions!=null){
            draft.setText(suggestions.chosen(choice));
            prefs.setStyle(choice);
            showStatus("Ready: "+choice+" reply. Edit if needed.");
        }
    }
    private static final class ChatMessage {
        final String chatTitle,text,fingerprint;final boolean incoming,strong,chatTrusted;final int y;
        ChatMessage(String chat,String text,String fp,boolean incoming,boolean strong,boolean trusted,int y){
            this.chatTitle=chat;this.text=text;this.fingerprint=fp;this.incoming=incoming;
            this.strong=strong;this.chatTrusted=trusted;this.y=y;
        }
    }
}
