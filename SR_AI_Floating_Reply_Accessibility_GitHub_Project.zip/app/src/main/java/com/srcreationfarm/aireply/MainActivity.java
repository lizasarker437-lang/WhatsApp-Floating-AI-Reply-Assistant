package com.srcreationfarm.aireply;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.view.accessibility.AccessibilityManager;
import android.net.Uri;

/** Settings UI with an explicit disclosure + user opt-in. */
public final class MainActivity extends Activity {
    private Prefs prefs;
    private LinearLayout body;
    private TextView serviceStatus;
    private Switch activeSwitch, cloudSwitch, autoSwitch, rightSideSwitch;
    private EditText keyInput, namesInput;

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        prefs = new Prefs(this);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(244,248,247));
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20),dp(24),dp(20),dp(26));
        scroll.addView(body);
        setContentView(scroll);

        addTitle("SR AI Floating Reply", 27);
        addText("SR Creation Farm  •  Experimental Accessibility Version",14,0xFF217761);
        cardTitle("What this app accesses");
        addText("With Accessibility enabled, the app can read the text and control elements shown on your active WhatsApp screen. It creates a floating AI reply panel. In Auto mode it can press Send for approved chats. The AI request sends the detected message text to OpenAI using YOUR API key. Never enable for accounts or messages you are not authorized to access.",14,0xFF243E35);
        addText("Only visible, accessible text is scanned—not hidden chats, encrypted storage or other apps. No background WhatsApp monitoring when its screen is closed.",13,0xFF657770);
        cloudSwitch = addSwitch("I consent to share scanned chat text with OpenAI",prefs.consent(),v -> prefs.setConsent(v));
        activeSwitch = addSwitch("Enable floating assistant",prefs.enabled(),v -> prefs.setEnabled(v));
        serviceStatus = addText("Accessibility: checking…",14,0xFF1E6457);
        addButton("OPEN ACCESSIBILITY SETTINGS", () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        cardTitle("Reply modes");
        addText("Manual: AI prepares replies, you tap Send. Auto: AI sends a new incoming reply only when the chat title exactly matches your allowlist and safety checks pass. Default = Manual.",14,0xFF243E35);
        autoSwitch = addSwitch("AUTO REPLY (approved chats only)",prefs.auto(),enabled -> {
            if (enabled && (!prefs.consent() || !prefs.hasKey() || prefs.allowlist().trim().isEmpty())) {
                toast("Enable cloud consent, save an API key and add allowed chat names first.");
                autoSwitch.setChecked(false); return;
            }
            prefs.setAuto(enabled);
        });
        namesInput = addInput("Allowed chat titles, separated by comma / new line", prefs.allowlist(), false);
        addText("For example: Rahim, My Test Number. Auto mode requires an exact visible chat-header match. Do not add groups or untrusted chats.",12,0xFF687B72);
        addButton("SAVE ALLOWED CHATS", () -> {
            prefs.setAllowlist(namesInput.getText().toString().trim());
            if (prefs.allowlist().isEmpty()) { prefs.setAuto(false); autoSwitch.setChecked(false); }
            toast("Saved");
        });
        rightSideSwitch = addSwitch("Incoming bubble is on RIGHT (default LEFT)",prefs.incomingRight(),v -> prefs.setIncomingRight(v));
        cardTitle("AI settings");
        keyInput = addInput("OpenAI API key (your own account)", "", true);
        addText(prefs.hasKey() ? "An encrypted API key is saved on this device." : "No API key saved.", 12,0xFF687B72);
        addButton("SAVE API KEY", () -> {
            if (prefs.setApiKey(keyInput.getText().toString())) {keyInput.setText(""); toast("Key stored in Android Keystore encrypted storage");}
            else toast("Key could not be saved");
        });
        addButton("REMOVE SAVED API KEY", () -> {prefs.clearApiKey(); prefs.setAuto(false); autoSwitch.setChecked(false); toast("Key removed");});
        addText("AI provider calls may cost money. Network connection is required. Do not paste an API key into GitHub.",12,0xFF697C75);
        cardTitle("Developer");
        addText("Shahriar Rahman | SR Creation Farm\nVersion 1.0.0 • © 2026 SR Creation Farm",14,0xFF26433A);
        addButton("YOUTUBE  •  @SRCreation-farm", () -> open("https://www.youtube.com/@SRCreation-farm"));
        addButton("FACEBOOK  •  SR Creation Farm", () -> open("https://fb.com/srcreation.farm"));
    }

    @Override protected void onResume() {
        super.onResume();
        if (serviceStatus != null) {
            boolean running = false;
            AccessibilityManager mgr = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            for (AccessibilityServiceInfo s : mgr.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)) {
                if (s.getResolveInfo() != null && getPackageName().equals(s.getResolveInfo().serviceInfo.packageName)
                    && s.getResolveInfo().serviceInfo.name.endsWith("WhatsAppAccessibilityService")) {running = true; break;}
            }
            serviceStatus.setText(running ? "Accessibility service: ON ✓" : "Accessibility service: OFF – enable in Android Settings");
        }
    }
    private void open(String url) {startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}
    private int dp(float n) {return (int)(getResources().getDisplayMetrics().density*n+0.5f);}
    private void cardTitle(String s) {
        TextView t=addText(s,19,0xFF063C30); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)t.getLayoutParams();p.topMargin=dp(20);t.setLayoutParams(p);
    }
    private TextView addTitle(String s,int size) {TextView t=addText(s,size,0xFF083C31);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView addText(String s,int size,int color) {
        TextView text=new TextView(this);text.setText(s);text.setTextSize(size);text.setTextColor(color);
        text.setLineSpacing(dp(3),1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin=dp(10);body.addView(text,p);return text;
    }
    interface Change {void onChange(boolean v);}
    private Switch addSwitch(String s,boolean value,Change change) {
        Switch sw=new Switch(this);sw.setText(s);sw.setTextSize(15);sw.setTextColor(0xFF173D32);sw.setPadding(dp(4),dp(8),0,dp(8));
        sw.setChecked(value);sw.setOnCheckedChangeListener((button,checked) -> change.onChange(checked));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);body.addView(sw,p);return sw;
    }
    private EditText addInput(String hint,String current,boolean secret) {
        EditText e=new EditText(this);e.setHint(hint);e.setText(current);
        e.setSingleLine(secret);e.setTextSize(15);e.setPadding(dp(12),dp(12),dp(12),dp(12));
        if(secret)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        else e.setMinLines(2);
        GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(dp(12));bg.setStroke(dp(1),0xFFD0E0D8);e.setBackground(bg);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);body.addView(e,p);return e;
    }
    private void addButton(String s,Runnable action) {
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xFF087E62,0xFF135C49});bg.setCornerRadius(dp(12));b.setBackground(bg);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.bottomMargin=dp(10);body.addView(b,p);b.setOnClickListener(v -> action.run());
    }
    private void toast(String message) {Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
}
