package com.srcreationfarm.aireply;

public final class Suggestions {
    public final String friendly;
    public final String polite;
    public final String professional;
    public Suggestions(String friendly, String polite, String professional) {
        this.friendly = friendly;
        this.polite = polite;
        this.professional = professional;
    }
    public String chosen(String style) {
        switch (style) {
            case "professional": return professional;
            case "polite": return polite;
            default: return friendly;
        }
    }
}
