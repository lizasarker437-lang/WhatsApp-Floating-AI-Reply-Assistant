package com.srcreationfarm.aireply;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private final SharedPreferences prefs;
    private final Context context;
    public Prefs(Context context) {
        this.context = context.getApplicationContext();
        prefs = context.getSharedPreferences("sr_ai_reply_v1", Context.MODE_PRIVATE);
    }
    public boolean enabled() { return prefs.getBoolean("enabled", false); }
    public void setEnabled(boolean enabled) { prefs.edit().putBoolean("enabled", enabled).apply(); }
    public boolean auto() { return prefs.getBoolean("auto", false); }
    public void setAuto(boolean auto) { prefs.edit().putBoolean("auto", auto).apply(); }
    public boolean consent() { return prefs.getBoolean("consent", false); }
    public void setConsent(boolean consent) { prefs.edit().putBoolean("consent", consent).apply(); }
    public String allowlist() { return prefs.getString("allowlist", ""); }
    public void setAllowlist(String list) { prefs.edit().putString("allowlist", list).apply(); }
    public String style() { return prefs.getString("style", "friendly"); }
    public void setStyle(String style) { prefs.edit().putString("style", style).apply(); }
    public boolean incomingRight() {return prefs.getBoolean("incoming_right", false);}
    public void setIncomingRight(boolean value) {prefs.edit().putBoolean("incoming_right",value).apply();}
    public boolean hasKey() { return !apiKey().isEmpty(); }
    public String apiKey() {
        String value = prefs.getString("encrypted_api_key", "");
        return value.isEmpty() ? "" : SecureKey.decrypt(value);
    }
    public boolean setApiKey(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        String secured = SecureKey.encrypt(value.trim());
        if (secured == null || secured.isEmpty()) return false;
        return prefs.edit().putString("encrypted_api_key", secured).commit();
    }
    public void clearApiKey() { prefs.edit().remove("encrypted_api_key").apply(); }
}
