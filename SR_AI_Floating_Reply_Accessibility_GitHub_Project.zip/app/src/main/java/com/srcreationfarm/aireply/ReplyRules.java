package com.srcreationfarm.aireply;

import java.util.Locale;

/** Pure Java decision helpers; deliberately conservative for unsupervised sending. */
public final class ReplyRules {
    private ReplyRules() {}

    public static String normalize(String name) {
        return name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
    }

    public static boolean allowlisted(String csv, String sender) {
        String target = normalize(sender);
        if (target.isEmpty() || csv == null || csv.trim().isEmpty()) return false;
        for (String part : csv.split("[,;\\n]")) {
            if (target.equals(normalize(part))) return true;
        }
        return false;
    }

    public static boolean sensitive(String message) {
        if (message == null) return true;
        String s = message.toLowerCase(Locale.ROOT);
        String[] markers = {"otp", "one time password", "2fa", "verification code", "password",
            "passcode", "pin code", "bank", "account number", "bikash", "bkash", "nagad",
            "money", "transfer", "payment", "urgent", "emergency", "hospital",
            "ওটিপি", "পাসওয়ার্ড", "পাসওয়ার্ড", "পিন", "টাকা", "বিকাশ", "নগদ",
            "জরুরি", "হাসপাতাল", "কোড"};
        for (String marker : markers) if (s.contains(marker)) return true;
        return false;
    }

    public static boolean suitable(String message) {
        if (message == null) return false;
        String s = message.trim();
        if (s.isEmpty() || s.length() > 1200) return false;
        String lower = s.toLowerCase(Locale.ROOT);
        return !lower.contains("new messages") && !lower.contains("checking for new messages")
            && !lower.contains("নতুন মেসেজ");
    }
}
