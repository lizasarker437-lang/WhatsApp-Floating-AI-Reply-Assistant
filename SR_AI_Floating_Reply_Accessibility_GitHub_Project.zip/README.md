# SR AI Floating Reply — Experimental Android app

**Developer:** Shahriar Rahman • **Brand:** SR Creation Farm • **Version:** 1.0.0

Android 8+ Java project. It installs a user-controlled `AccessibilityService` that can **inspect only accessibility-exposed text of the WhatsApp screen currently open on the device**, and shows a floating AI reply panel. It cannot bypass Android protections or retrieve hidden/closed chats. WhatsApp UI changes may prevent detection.

## Setup

1. Unzip contents into a **new GitHub repository** (keep the hidden `.github` folder).
2. Open GitHub **Actions** → **Build SR AI Floating Reply APK** → **Run workflow** (or push to `main`).
3. Download `SR-AI-Floating-Reply-debug-apk` from workflow Artifacts. Install the debug APK on your own phone, permitting installations from that source as Android requests.
4. Launch app. Read disclosure, switch on **Enable floating assistant**, and explicitly consent if you want WhatsApp message text submitted to the AI provider.
5. Add your own **OpenAI API key** to Settings; it is encrypted at rest using Android Keystore, but direct client-side API requests are not suitable for production keys. No key is included in source or GitHub.
6. Android **Settings → Accessibility → Installed apps / Downloaded apps → SR AI Floating Reply → On**. You must authorize this manually; the app cannot turn it on for you.
7. Open a **text chat** in WhatsApp or WhatsApp Business. Tap **✦ AI** → **SCAN**; review the detected message and generated replies. Choose style; optionally edit; tap **SEND IN WHATSAPP**. Sending is attempted via accessible text composer and Send UI (not a confirmed delivery).
8. Auto mode requires cloud consent, a saved key, and exact allowed **chat header titles**. First launch or opened history is used as a baseline. New **incoming** messages may be answered automatically only if the UI identification succeeds and safety checks pass. Disabled by default. Keep initial experiments limited to your own test chats.

## Modes, safety and limitations

- Manual and Auto mode can be changed at any time. Auto defaults to OFF.
- Auto requires known WhatsApp message resource IDs, positively identified chat header, geometry indicating incoming bubble, exact allowlist title match, a 60-second per-chat cooldown, and excludes messages containing sensitive keywords. Group chats should **not** be added to the allowlist.
- Auto detection is based on UI changes **while WhatsApp is open**; no notification access, background scanning, WhatsApp database access, MediaProjection screenshots, or hidden chats.
- The UI can fail to expose text; updated WhatsApp versions may rename message IDs, chat IDs, or the composer/Send button. If the UI identifiers are unavailable, the manual SCAN includes a less certain fallback, which requires **user review** before sending.
- If the WhatsApp composer already contains text, the app refuses to overwrite it. Never send sensitive or confidential data to an AI service without appropriate permission.
- AI results can be inaccurate, and a click on the WhatsApp Send UI does **not** confirm message delivery.
- Providing an API key may incur provider costs; it must not be published in source control.
- No `isAccessibilityTool=true` claim, no Accessibility-granted bypass of Android security, and no hidden monitoring.
- Google Play distribution requires separate review of Accessibility and data disclosures. Do not assume this experimental design qualifies for publication.

## Build configuration

- `com.android.application` version `8.9.2`, Java 17, Gradle `8.11.1`, compile/target SDK 35, min SDK 26.
- GitHub workflow: `.github/workflows/build.yml` (also copied to root `build.yml` for convenience; GitHub **only** executes the `.github/workflows/` copy).
- Workflow uploads `app/build/outputs/apk/debug/app-debug.apk` as an artifact.

## Local verification notes

See `tests/check_project.py`. Static validation and isolated Java decision tests can be run without the Android SDK. **A full Android Gradle build and a real WhatsApp device test are required before the APK can be described as working**. This environment does not contain the Android SDK or Gradle, so no on-device success claim is made.

## Support links

- YouTube: https://www.youtube.com/@SRCreation-farm
- Facebook: https://fb.com/srcreation.farm
