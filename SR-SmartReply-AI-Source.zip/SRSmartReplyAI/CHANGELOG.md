# Changelog

## [1.0.0] - 2026-11-17
### Added
- Initial release of **SR SmartReply AI** by **Shahriar Rahman (SR Creation Farm)**.
- `WhatsAppAccessibilityService` with draggable `TYPE_ACCESSIBILITY_OVERLAY` floating button and expandable 3-option reply panel.
- Direct screen text scanner supporting `com.whatsapp` and `com.whatsapp.w4b` with recursive fallback traversal.
- `GeminiReplyClient` & `ReplyJsonParser` supporting Bangla, English, and Banglish + offline fallback replies.
- One-tap auto-insert and auto-send functionality (`ACTION_SET_TEXT` + `ACTION_CLICK`).
- 9 custom Material 3 themes (`Midnight Gold`, `Ocean Blue`, `Emerald Green`, `Royal Purple`, `Sunset Coral`, `Graphite Cyan`, `Rose Quartz`, `Arctic Mint`, `Light Day`) + System/Light/Dark appearance modes.
- Categorized `SettingsActivity`, searchable SQLite `HistoryActivity`, and `AboutActivity` with YouTube & Facebook links.
- Mobile-ready GitHub Actions workflow (`.github/workflows/build-apk.yml`).
