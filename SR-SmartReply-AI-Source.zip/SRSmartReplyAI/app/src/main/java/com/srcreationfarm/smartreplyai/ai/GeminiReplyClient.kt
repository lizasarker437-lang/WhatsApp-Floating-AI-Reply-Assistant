package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class GeminiReplyClient {

    suspend fun generateReplies(
        apiKey: String,
        messages: List<ChatMessage>,
        languagePreference: String
    ): ReplyOptions = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || messages.isEmpty()) {
            return@withContext ReplyJsonParser.buildSmartFallbackReplies(messages)
        }

        try {
            val conversationText = messages.joinToString("\n") { "${it.sender}: ${it.text}" }
            val prompt = buildPrompt(conversationText, languagePreference)

            val endpoint =
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
            val url = URL(endpoint)
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                connectTimeout = 12000
                readTimeout = 15000
                doOutput = true
            }

            val payload = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 350)
                    put("responseMimeType", "application/json")
                })
            }

            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val responseCode = connection.responseCode
            val stream = if (responseCode in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            }

            val responseBody = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use {
                it.readText()
            }
            connection.disconnect()

            if (responseCode !in 200..299) {
                return@withContext ReplyJsonParser.buildSmartFallbackReplies(messages)
            }

            val root = JSONObject(responseBody)
            val candidateText = root
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")

            ReplyJsonParser.parseGeminiResponse(candidateText)
        } catch (e: Exception) {
            ReplyJsonParser.buildSmartFallbackReplies(messages)
        }
    }

    private fun buildPrompt(conversationText: String, languagePreference: String): String {
        return """
You are a smart, human-like WhatsApp reply assistant.
Analyze the recent WhatsApp chat messages below and generate 3 natural, human-like reply options to the latest incoming message.

Language Instruction:
- User Preference: $languagePreference
- If preference is Auto: match the exact language and script of the incoming message (Bangla script -> natural Bangla; Banglish/Romanized Bengali -> natural Banglish; English -> natural English).
- Keep replies concise, natural, emotionally aware, and ready to send on WhatsApp.

Recent Chat Context:
$conversationText

Return ONLY a valid JSON object with exact keys:
{
  "friendly": "Warm, casual, natural friend-like reply",
  "polite": "Respectful, courteous, kind reply",
  "professional": "Clear, formal, polite workplace/business reply"
}
        """.trimIndent()
    }
}
