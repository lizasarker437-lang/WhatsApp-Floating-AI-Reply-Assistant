package com.srcreationfarm.smartreplyai.model

data class ReplyOptions(
    val friendly: String,
    val polite: String,
    val professional: String,
    val detectedLanguage: String = "Auto",
    val isOfflineFallback: Boolean = false
)
