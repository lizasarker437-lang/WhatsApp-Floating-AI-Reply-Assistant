package com.srcreationfarm.smartreplyai.ai

import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import org.json.JSONObject

object ReplyJsonParser {

    fun parseGeminiResponse(rawText: String): ReplyOptions {
        val cleaned = rawText
            .replace("```json", "", ignoreCase = true)
            .replace("```", "")
            .trim()

        val startIndex = cleaned.indexOf('{')
        val endIndex = cleaned.lastIndexOf('}')
        if (startIndex == -1 || endIndex == -1 || endIndex <= startIndex) {
            throw IllegalArgumentException("Invalid JSON boundaries in AI response")
        }

        val jsonStr = cleaned.substring(startIndex, endIndex + 1)
        val obj = JSONObject(jsonStr)

        val friendly = obj.optString("friendly", "").trim()
        val polite = obj.optString("polite", "").trim()
        val professional = obj.optString("professional", "").trim()

        if (friendly.isEmpty() && polite.isEmpty() && professional.isEmpty()) {
            throw IllegalArgumentException("Empty reply fields in JSON")
        }

        return ReplyOptions(
            friendly = friendly.ifEmpty { polite },
            polite = polite.ifEmpty { friendly },
            professional = professional.ifEmpty { polite }
        )
    }

    fun buildSmartFallbackReplies(messages: List<ChatMessage>): ReplyOptions {
        val lastIncoming = messages.lastOrNull { it.sender == "Incoming" }?.text
            ?: messages.lastOrNull()?.text
            ?: ""

        val hasBanglaScript = lastIncoming.any { it in '\u0980'..'\u09FF' }
        val lower = lastIncoming.lowercase()
        val isBanglish = !hasBanglaScript && listOf(
            "kemon", "ki", "kothay", "bhai", "vai", "ache", "achi", "korcho", "koro", "assalamu", "salam", "bhalo", "valo", "tumi", "apni"
        ).any { lower.contains(it) }

        return when {
            hasBanglaScript -> ReplyOptions(
                friendly = "ভালো আছি ভাই! তোমার কী অবস্থা?",
                polite = "জি আলহামদুলিল্লাহ, ভালো আছি। আপনি কেমন আছেন?",
                professional = "ধন্যবাদ মেসেজের জন্য। আমি বিষয়টি দেখে আপনাকে জানাচ্ছি।",
                detectedLanguage = "Bangla (Offline Fallback)",
                isOfflineFallback = true
            )
            isBanglish -> ReplyOptions(
                friendly = "Alhamdulillah bhalo achi! Tomar ki obostha?",
                polite = "Ji Alhamdulillah bhalo achi. Apni kemon achen?",
                professional = "Dhonnobad message er jonno. Ami dekhe apnake janacchi.",
                detectedLanguage = "Banglish (Offline Fallback)",
                isOfflineFallback = true
            )
            else -> ReplyOptions(
                friendly = "Doing great! How's everything going with you?",
                polite = "Thank you for reaching out! I'm doing well, how are you?",
                professional = "Thank you for your message. I will review this and get back to you shortly.",
                detectedLanguage = "English (Offline Fallback)",
                isOfflineFallback = true
            )
        }
    }
}
