package com.srcreationfarm.smartreplyai.service

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.srcreationfarm.smartreplyai.R
import com.srcreationfarm.smartreplyai.ai.GeminiReplyClient
import com.srcreationfarm.smartreplyai.data.ReplyDatabaseHelper
import com.srcreationfarm.smartreplyai.manager.SettingsManager
import com.srcreationfarm.smartreplyai.model.ChatMessage
import com.srcreationfarm.smartreplyai.model.ReplyHistoryItem
import com.srcreationfarm.smartreplyai.model.ReplyOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

class WhatsAppAccessibilityService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private lateinit var settingsManager: SettingsManager
    private lateinit var dbHelper: ReplyDatabaseHelper
    private val geminiClient = GeminiReplyClient()

    private var floatingView: View? = null
    private var windowParams: WindowManager.LayoutParams? = null

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var activeJob: Job? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var currentDetectedSnippet: String = ""
    private var currentReplies: ReplyOptions? = null

    companion object {
        @Volatile
        var isServiceRunning: Boolean = false
            private set

        private const val PKG_WHATSAPP = "com.whatsapp"
        private const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        settingsManager = SettingsManager.getInstance(this)
        dbHelper = ReplyDatabaseHelper(this)
        setupFloatingOverlay()
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun setupFloatingOverlay() {
        if (floatingView != null) return

        val view = LayoutInflater.from(this).inflate(R.layout.layout_floating_ai, null)
        floatingView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = settingsManager.getOrbX()
            y = settingsManager.getOrbY()
        }
        windowParams = params

        val orbButton = view.findViewById<View>(R.id.btnFloatingOrb)
        val panelContainer = view.findViewById<View>(R.id.panelReplyContainer)
        val btnClosePanel = view.findViewById<View>(R.id.btnClosePanel)
        val btnRegenerate = view.findViewById<View>(R.id.btnRegenerateReply)

        val cardFriendly = view.findViewById<View>(R.id.cardReplyFriendly)
        val cardPolite = view.findViewById<View>(R.id.cardReplyPolite)
        val cardProfessional = view.findViewById<View>(R.id.cardReplyProfessional)

        // Draggable Floating Orb + Click Detection
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        orbButton.setOnTouchListener { _, event ->
            val currentParams = windowParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = currentParams.x
                    initialY = currentParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (initialTouchX - event.rawX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    if (abs(deltaX) > 12 || abs(deltaY) > 12) {
                        isDragging = true
                    }
                    if (isDragging) {
                        currentParams.x = (initialX + deltaX).coerceAtLeast(0)
                        currentParams.y = (initialY + deltaY).coerceAtLeast(40)
                        try {
                            windowManager.updateViewLayout(view, currentParams)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isDragging) {
                        settingsManager.saveOrbPosition(currentParams.x, currentParams.y)
                    } else {
                        triggerHaptic()
                        if (panelContainer.visibility == View.VISIBLE) {
                            panelContainer.visibility = View.GONE
                        } else {
                            panelContainer.visibility = View.VISIBLE
                            scanAndGenerateReplies()
                        }
                    }
                    true
                }
                else -> false
            }
        }

        btnClosePanel.setOnClickListener {
            panelContainer.visibility = View.GONE
        }

        btnRegenerate.setOnClickListener {
            triggerHaptic()
            scanAndGenerateReplies()
        }

        // One-Tap Reply Selection & Long-Press Copy
        cardFriendly.setOnClickListener {
            currentReplies?.friendly?.let { reply ->
                handleReplySelected(reply, "Friendly")
            }
        }
        cardPolite.setOnClickListener {
            currentReplies?.polite?.let { reply ->
                handleReplySelected(reply, "Polite")
            }
        }
        cardProfessional.setOnClickListener {
            currentReplies?.professional?.let { reply ->
                handleReplySelected(reply, "Professional")
            }
        }

        cardFriendly.setOnLongClickListener {
            currentReplies?.friendly?.let { copyToClipboard(it) }
            true
        }
        cardPolite.setOnLongClickListener {
            currentReplies?.polite?.let { copyToClipboard(it) }
            true
        }
        cardProfessional.setOnLongClickListener {
            currentReplies?.professional?.let { copyToClipboard(it) }
            true
        }

        try {
            windowManager.addView(view, params)
            view.visibility = View.GONE
        } catch (_: Exception) {
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        val overlay = floatingView ?: return

        if (!settingsManager.isFloatingEnabled()) {
            overlay.visibility = View.GONE
            return
        }

        val isSupportedWhatsApp = pkg == PKG_WHATSAPP ||
                (pkg == PKG_WHATSAPP_BUSINESS && settingsManager.isWhatsAppBusinessEnabled())

        if (isSupportedWhatsApp) {
            if (overlay.visibility != View.VISIBLE) {
                overlay.visibility = View.VISIBLE
            }
        } else if (!pkg.startsWith("com.android.systemui")) {
            overlay.visibility = View.GONE
            overlay.findViewById<View>(R.id.panelReplyContainer)?.visibility = View.GONE
        }
    }

    private fun scanAndGenerateReplies() {
        val view = floatingView ?: return
        val tvDetected = view.findViewById<TextView>(R.id.tvDetectedMessage)
        val progress = view.findViewById<ProgressBar>(R.id.progressAiLoading)
        val tvFriendly = view.findViewById<TextView>(R.id.tvReplyFriendly)
        val tvPolite = view.findViewById<TextView>(R.id.tvReplyPolite)
        val tvProfessional = view.findViewById<TextView>(R.id.tvReplyProfessional)

        val messages = scanVisibleWhatsAppMessages(settingsManager.getContextDepth())
        if (messages.isEmpty()) {
            tvDetected.text = "No open chat messages detected. Open a WhatsApp conversation first."
            return
        }

        val latestIncoming = messages.lastOrNull { it.sender == "Incoming" }?.text
            ?: messages.last().text
        currentDetectedSnippet = latestIncoming
        tvDetected.text = "Message: $latestIncoming"

        progress.visibility = View.VISIBLE
        tvFriendly.text = "Generating..."
        tvPolite.text = "Generating..."
        tvProfessional.text = "Generating..."

        activeJob?.cancel()
        activeJob = serviceScope.launch {
            val options = geminiClient.generateReplies(
                apiKey = settingsManager.getApiKey(),
                messages = messages,
                languagePreference = settingsManager.getLanguagePreference()
            )
            currentReplies = options
            progress.visibility = View.GONE
            tvFriendly.text = options.friendly
            tvPolite.text = options.polite
            tvProfessional.text = options.professional

            if (options.isOfflineFallback) {
                tvDetected.text = "Offline/Demo Mode (Add Gemini API Key in Settings)"
            }
        }
    }

    private fun scanVisibleWhatsAppMessages(maxCount: Int): List<ChatMessage> {
        val rootNode = rootInActiveWindow ?: return emptyList()
        val screenWidth = resources.displayMetrics.widthPixels
        val results = mutableListOf<ChatMessage>()

        val viewIds = listOf(
            "com.whatsapp:id/message_text",
            "com.whatsapp.w4b:id/message_text"
        )

        var nodes: List<AccessibilityNodeInfo> = emptyList()
        for (id in viewIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                nodes = found
                break
            }
        }

        if (nodes.isNotEmpty()) {
            for (node in nodes.takeLast(maxCount)) {
                val text = node.text?.toString()?.trim() ?: continue
                if (text.isEmpty()) continue
                val rect = Rect()
                node.getBoundsInScreen(rect)
                val sender = if (rect.left < screenWidth / 3) "Incoming" else "Me"
                results.add(ChatMessage(sender, text))
            }
        } else {
            // Fallback recursive scan for message bubbles in middle screen area
            collectFallbackTextNodes(rootNode, screenWidth, resources.displayMetrics.heightPixels, results)
        }

        return results.takeLast(maxCount)
    }

    private fun collectFallbackTextNodes(
        node: AccessibilityNodeInfo?,
        screenWidth: Int,
        screenHeight: Int,
        out: MutableList<ChatMessage>
    ) {
        if (node == null) return
        val className = node.className?.toString() ?: ""
        if (className == "android.widget.TextView" && !node.isEditable) {
            val txt = node.text?.toString()?.trim() ?: ""
            if (txt.length >= 2 && !txt.matches(Regex("^\d{1,2}:\d{2}\s?(AM|PM|am|pm)?$"))) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.top > screenHeight / 7 && rect.bottom < (screenHeight * 0.88)) {
                    val sender = if (rect.left < screenWidth / 3) "Incoming" else "Me"
                    out.add(ChatMessage(sender, txt))
                }
            }
        }
        for (i in 0 until node.childCount) {
            collectFallbackTextNodes(node.getChild(i), screenWidth, screenHeight, out)
        }
    }

    private fun handleReplySelected(replyText: String, tone: String) {
        triggerHaptic()
        if (settingsManager.isSaveHistoryEnabled()) {
            dbHelper.insertReply(
                ReplyHistoryItem(
                    incomingSnippet = currentDetectedSnippet.ifEmpty { "WhatsApp Chat" },
                    selectedReply = replyText,
                    tone = tone,
                    timestamp = System.currentTimeMillis()
                )
            )
        }

        val inserted = insertTextIntoWhatsApp(replyText)
        if (inserted) {
            floatingView?.findViewById<View>(R.id.panelReplyContainer)?.visibility = View.GONE
            if (settingsManager.isAutoSendEnabled()) {
                mainHandler.postDelayed({
                    clickWhatsAppSendButton()
                }, 220L)
            }
        } else {
            copyToClipboard(replyText)
            Toast.makeText(this, "Copied to clipboard (Input box not focused)", Toast.LENGTH_SHORT).show()
        }
    }

    private fun insertTextIntoWhatsApp(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val entryIds = listOf("com.whatsapp:id/entry", "com.whatsapp.w4b:id/entry")

        var inputNode: AccessibilityNodeInfo? = null
        for (id in entryIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                inputNode = found.first()
                break
            }
        }

        if (inputNode == null) {
            inputNode = findFirstEditableNode(rootNode)
        }

        if (inputNode == null) return false

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findFirstEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun clickWhatsAppSendButton() {
        val rootNode = rootInActiveWindow ?: return
        val sendIds = listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")
        for (id in sendIds) {
            val found = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!found.isNullOrEmpty()) {
                found.first().performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return
            }
        }
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("SR SmartReply", text))
        Toast.makeText(this, "Reply copied!", Toast.LENGTH_SHORT).show()
    }

    private fun triggerHaptic() {
        if (!settingsManager.isHapticEnabled()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(30)
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onInterrupt() {
        isServiceRunning = false
    }

    override fun onDestroy() {
        isServiceRunning = false
        serviceScope.cancel()
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        floatingView = null
        super.onDestroy()
    }
}
