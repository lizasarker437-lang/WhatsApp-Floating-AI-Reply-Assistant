package com.srcreationfarm.smartreplyai

import com.srcreationfarm.smartreplyai.ai.ReplyJsonParser
import com.srcreationfarm.smartreplyai.model.ChatMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReplyJsonParserTest {

    @Test
    fun parseGeminiResponse_parsesCleanJson() {
        val sample = """
            {
              "friendly": "Bhalo achi bhai!",
              "polite": "Alhamdulillah bhalo achi, apni kemon achen?",
              "professional": "Thank you for your message. I will update you shortly."
            }
        """.trimIndent()

        val result = ReplyJsonParser.parseGeminiResponse(sample)
        assertEquals("Bhalo achi bhai!", result.friendly)
        assertEquals("Alhamdulillah bhalo achi, apni kemon achen?", result.polite)
        assertEquals("Thank you for your message. I will update you shortly.", result.professional)
    }

    @Test
    fun parseGeminiResponse_parsesMarkdownWrappedJson() {
        val sample = """
            ```json
            {
              "friendly": "হ্যাঁ অবশ্যই!",
              "polite": "জি অবশ্যই, আমি দেখছি।",
              "professional": "ধন্যবাদ, আমি বিষয়টি পর্যালোচনা করছি।"
            }
            ```
        """.trimIndent()

        val result = ReplyJsonParser.parseGeminiResponse(sample)
        assertEquals("হ্যাঁ অবশ্যই!", result.friendly)
        assertEquals("জি অবশ্যই, আমি দেখছি।", result.polite)
        assertEquals("ধন্যবাদ, আমি বিষয়টি পর্যালোচনা করছি।", result.professional)
    }

    @Test
    fun buildSmartFallbackReplies_detectsBanglaBanglishAndEnglish() {
        val bangla = ReplyJsonParser.buildSmartFallbackReplies(listOf(ChatMessage("Incoming", "কেমন আছেন ভাই?")))
        assertTrue(bangla.detectedLanguage.contains("Bangla"))

        val banglish = ReplyJsonParser.buildSmartFallbackReplies(listOf(ChatMessage("Incoming", "Kemon acho vai?")))
        assertTrue(banglish.detectedLanguage.contains("Banglish"))

        val english = ReplyJsonParser.buildSmartFallbackReplies(listOf(ChatMessage("Incoming", "Are you free today?")))
        assertTrue(english.detectedLanguage.contains("English"))
    }
}
