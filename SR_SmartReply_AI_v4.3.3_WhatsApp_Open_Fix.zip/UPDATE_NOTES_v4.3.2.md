# Version 4.3.2 — PIN unlock correction

- Removed blind Enter coordinate (78% width, 85% height), which could hit Delete.
- No more double input per digit (ACTION_CLICK followed by physical tap).
- No second complete PIN entry after the first attempt.
- Automatic PIN-only entry is the default on fresh installs.
- Existing users: switch off **Press Enter after PIN** in Settings to select PIN-only behavior.
- When Enter is enabled, only a verified visible Enter/OK key is tapped; no blind fallback.
- Some Android devices may block accessibility PIN entry or require Enter.
- No physical-device test performed.
