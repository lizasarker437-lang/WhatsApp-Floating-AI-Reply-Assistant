# v4.3.3 — Unlock → WhatsApp → incoming sender chat

- Foreground UnlockWakeActivity opens WhatsApp only after Android reports keyguard dismissed.
- Accessibility service waits up to 9 seconds for PIN unlock completion and up to 5 seconds for WhatsApp foreground.
- Selects the notification sender among configured contact names/numbers instead of always the first configured target.
- Existing notification target filter and in-chat target filter retained.
- Existing no-blind-Delete-tap PIN behavior retained.
- Android may block background launches on some OEM/OS versions; real-device checks required.
- Ensure Notification Access, Accessibility, Auto Reply, target filter and screen overlay are enabled.
