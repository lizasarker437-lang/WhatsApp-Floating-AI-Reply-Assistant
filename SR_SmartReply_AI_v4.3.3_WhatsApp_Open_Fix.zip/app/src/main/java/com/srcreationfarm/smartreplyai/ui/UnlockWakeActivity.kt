package com.srcreationfarm.smartreplyai.ui

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

/** Visible above keyguard. Once PIN succeeds, launches WhatsApp from a foreground Activity. */
class UnlockWakeActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_WHATSAPP_PACKAGE = "sr.whatsapp_package"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var didLaunch = false
    private val checkUnlockedRunnable = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed) return
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isKeyguardLocked) {
                launchAfterUnlock()
            } else {
                handler.postDelayed(this, 200L)
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        handler.postDelayed({
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && km.isKeyguardLocked) {
                km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                    override fun onDismissSucceeded() { launchAfterUnlock() }
                    override fun onDismissCancelled() { /* PIN UI remains under user control */ }
                    override fun onDismissError() { /* poll instead */ }
                })
            }
        }, 180L)
        handler.postDelayed(checkUnlockedRunnable, 400L)
        handler.postDelayed({ if (!isFinishing) finish() }, 13000L)
    }

    private fun launchAfterUnlock() {
        if (didLaunch || isFinishing) return
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isKeyguardLocked) return
        didLaunch = true
        val requested = intent?.getStringExtra(EXTRA_WHATSAPP_PACKAGE)
        val pkg = if (requested == "com.whatsapp.w4b") "com.whatsapp.w4b" else "com.whatsapp"
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(launchIntent)
            }
        } catch (_: Exception) { /* accessibility service will perform fallback launch */ }
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
