package com.srcreationfarm.smartreplyai.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.srcreationfarm.smartreplyai.manager.SettingsManager

class WhatsAppNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile
        var isListenerConnected: Boolean = false
            private set

        private const val PKG_WHATSAPP = "com.whatsapp"
        private const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        isListenerConnected = true
    }

    override fun onListenerDisconnected() {
        isListenerConnected = false
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.isOngoing) return
        val pkg = sbn.packageName ?: return

        val settings = SettingsManager.getInstance(this)
        if (!settings.isFullAutoReplyEnabled()) return

        val isSupportedWhatsApp = pkg == PKG_WHATSAPP ||
                (pkg == PKG_WHATSAPP_BUSINESS && settings.isWhatsAppBusinessEnabled())
        if (!isSupportedWhatsApp) return

        val extras = sbn.notification?.extras ?: return
        val rawTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val rawText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""

        // Ignore summary notifications like "WhatsApp" or "2 new messages" or "Checking for new messages"
        if (rawTitle.isEmpty() || rawText.isEmpty()) return
        val lowerTitle = rawTitle.lowercase()
        val lowerText = rawText.lowercase()
        if (lowerTitle == "whatsapp" || lowerTitle == "whatsapp business") return
        if (lowerText.contains("new messages") || lowerText.contains("checking for new messages")) return

        // Clean sender title (strip group/unread count suffixes if any, e.g., "SR (2 messages)" -> "SR")
        val senderName = rawTitle.replace(Regex("\\s*\\(\\d+\\s+messages?\\)$", RegexOption.IGNORE_CASE), "").trim()

        // If Target Contact Filter is enabled, verify that either the notification sender matches OR we want to search the target contact
        if (settings.isTargetFilterEnabled() && settings.getTargetContactQuery().isNotEmpty()) {
            if (!settings.isChatAllowedByTargetFilter(senderName)) {
                return
            }
        }

        // Delegate to WhatsAppAccessibilityService to wake screen, unlock PIN, open WhatsApp, find contact, and auto-reply!
        WhatsAppAccessibilityService.onIncomingWhatsAppNotification(
            context = applicationContext,
            packageName = pkg,
            senderTitle = senderName,
            messageText = rawText,
            contentIntent = sbn.notification?.contentIntent
        )
    }
}
