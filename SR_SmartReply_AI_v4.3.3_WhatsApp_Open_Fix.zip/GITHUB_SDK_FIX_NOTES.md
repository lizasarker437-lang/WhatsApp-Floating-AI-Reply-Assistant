# SDK workflow fix

Previous workflow failed in `android-actions/setup-android@v3` when attempting to install the obsolete SDK `tools` package.

Replacement workflow uses the preinstalled GitHub Ubuntu runner Android SDK, locates sdkmanager in cmdline-tools, and installs Android platform 34 / build-tools 34.0.0 without obsolete `tools`.

Upload source ZIP at repository root and copy the separate workflow to `.github/workflows/build.yml`, or extract the source at repository root.

This is source-level/static validation only; an actual GitHub-hosted build must still be run.
