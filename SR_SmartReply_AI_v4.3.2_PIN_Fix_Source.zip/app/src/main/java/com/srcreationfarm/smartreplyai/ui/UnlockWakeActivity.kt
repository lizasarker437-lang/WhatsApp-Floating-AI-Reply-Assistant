package com.srcreationfarm.smartreplyai.ui

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity

class UnlockWakeActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val checkUnlockedRunnable = object : Runnable {
        override fun run() {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isKeyguardLocked) {
                finish()
            } else {
                handler.postDelayed(this, 250L)
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            }
            window.addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )

            // Wait 180ms for window attachment, then request Keyguard PIN pad bouncer
            handler.postDelayed({
                try {
                    val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && km.isKeyguardLocked) {
                        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                            override fun onDismissSucceeded() {
                                finish()
                            }
                            override fun onDismissCancelled() {
                                // Keep alive briefly if swipe fallback is running
                            }
                            override fun onDismissError() {
                            }
                        })
                    }
                } catch (_: Exception) {
                }
            }, 180L)

            handler.postDelayed(checkUnlockedRunnable, 400L)
        } catch (_: Exception) {
        }

        // Safety timeout: finish after 7.5 seconds so it never hangs
        handler.postDelayed({
            if (!isFinishing) {
                finish()
            }
        }, 7500L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
